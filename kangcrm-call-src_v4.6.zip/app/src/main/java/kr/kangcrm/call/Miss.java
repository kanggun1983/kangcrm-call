package kr.kangcrm.call;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 📵 v4.6 부재 재연락 (명함 문자) — 영업 전화를 안 받은 고객
 *  · 결과 창에서 '연락한 이유'와 '언제 보낼까요'를 고르면 통화 기록에 missReason · missWhen 으로 올림
 *  · 강CRM(V228)이 그 시각에 매장 폰으로 (광고) 문자 + 고객 전용 명함 링크를 보냄
 *  · 보내는 시각 계산은 강CRM missAtFor 와 같게 (h2 = 2시간 뒤 · e19 = 오늘 저녁 7시 · m10 = 내일 오전 10시 · 저녁 9시~아침 8시면 아침 9시)
 */
final class Miss {
    private Miss() {}

    static final String[] REASONS_DEFAULT = {"기변 혜택 안내", "약정 만료 안내", "요금 상담", "견적 안내", "이벤트 안내"};
    static final String[] WHEN_CODES = {"h2", "e19", "m10", "none"};
    static final String[] WHEN_LABELS = {"2시간 뒤", "오늘 저녁 7시", "내일 오전 10시", "보내지 않기"};
    static final String DEFAULT_PHRASE = "안내드릴 게 있어서";
    static final String TPL_DEFAULT = "{이름}님, {매장} {담당자}입니다.\n{연락이유} 전화드렸는데 연결이 안 됐어요.\n아래 명함에서 편하신 방법을 눌러 주세요 👇\n{명함}";
    static final String TPL_V222 = "{이름}님, {매장} {담당자}입니다 😊\n전화드렸는데 연결이 안 돼서 문자 남겨요. 편하실 때 전화나 답장 주시면 바로 도와드릴게요!";
    static final String OPTOUT_DEFAULT = "수신거부: 이 번호로 '거부'라고 답장 주세요";

    /** 강CRM 설정 → 자동 안내 → 📵 부재 고객 자동 연락 이 켜져 있나 */
    static boolean on(JSONObject cfg) {
        return cfg != null && cfg.optBoolean("smsAutoMissOn", false);
    }

    /** 연락 이유 목록 (강CRM 설정 · 없으면 기본 5개 · 12개까지) */
    static List<String> reasons(JSONObject cfg) {
        List<String> out = new ArrayList<>();
        JSONArray a = cfg == null ? null : cfg.optJSONArray("smsMissReasons");
        if (a != null) {
            for (int i = 0; i < a.length() && out.size() < 12; i++) {
                String s = a.optString(i, "").replaceAll("\\s+", " ").trim();
                if (!s.isEmpty() && !"null".equals(s) && !out.contains(s)) out.add(s);
            }
        }
        if (out.isEmpty()) for (String s : REASONS_DEFAULT) out.add(s);
        return out;
    }

    /** '약정 만료 안내' → '약정 만료 안내드리려고' (이미 '…려고' · '…어서'면 그대로) */
    static String phrase(String label) {
        String t = label == null ? "" : label.replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) return "";
        return t.endsWith("려고") || t.endsWith("어서") ? t : t + "드리려고";
    }

    /** 기본 보내는 때 (설정 smsMissDays 가 h2 · e19 · m10 이면 그것 · 아니면 오늘 저녁 7시) · 저녁 7시가 지났으면 내일 오전 10시 */
    static String defWhen(JSONObject cfg, long baseMs) {
        String v = cfg == null ? "" : cfg.optString("smsMissDays", "");
        String w = "h2".equals(v) || "e19".equals(v) || "m10".equals(v) ? v : "e19";
        if ("e19".equals(w) && !eveningOk(baseMs)) w = "m10";
        return w;
    }

    /** '오늘 저녁 7시'를 고를 수 있나 (통화한 시각이 저녁 7시 전) */
    static boolean eveningOk(long baseMs) {
        Calendar b = cal(baseMs);
        return b.get(Calendar.HOUR_OF_DAY) < 19;
    }

    /** 저녁 9시 ~ 아침 8시 → 아침 9시 */
    static long quiet(long ms) {
        Calendar d = cal(ms);
        int h = d.get(Calendar.HOUR_OF_DAY);
        if (h >= 21) {
            d.add(Calendar.DAY_OF_MONTH, 1);
            return at(d, 9);
        }
        if (h < 8) return at(d, 9);
        return ms;
    }

    /** 보낼 시각 (강CRM missAtFor 와 같음) · none 등은 0 */
    static long atFor(String code, long baseMs) {
        Calendar b = cal(baseMs);
        if ("h2".equals(code)) return quiet(baseMs + 2L * 3600L * 1000L);
        if ("e19".equals(code)) {
            if (b.get(Calendar.HOUR_OF_DAY) >= 19) {
                b.add(Calendar.DAY_OF_MONTH, 1);
                return at(b, 10);
            }
            return at(b, 19);
        }
        if ("m10".equals(code)) {
            b.add(Calendar.DAY_OF_MONTH, 1);
            return at(b, 10);
        }
        return 0;
    }

    /** '오늘 오후 7:00' · '내일 오전 10:00' · '10/27 오전 9:00' */
    static String whenText(long at, long now) {
        if (at <= 0) return "";
        Calendar a = cal(at), n = cal(now);
        long dd = Facts.daysBetween(day(n), day(a));
        String d = dd == 0 ? "오늘" : (dd == 1 ? "내일" : (a.get(Calendar.MONTH) + 1) + "/" + a.get(Calendar.DAY_OF_MONTH));
        int h = a.get(Calendar.HOUR_OF_DAY), m = a.get(Calendar.MINUTE);
        return d + " " + (h < 12 ? "오전" : "오후") + " " + (h % 12 == 0 ? 12 : h % 12) + String.format(Locale.US, ":%02d", m);
    }

    /** 저장 버튼 글자 */
    static String saveLabel(String code, long baseMs, long now) {
        if (code == null || code.isEmpty() || "none".equals(code)) return "강CRM에 저장 · 문자 안 보냄";
        return "강CRM에 저장 · " + whenText(atFor(code, baseMs), now) + " 문자";
    }

    private static final Pattern CONTRACT_LEFT = Pattern.compile("^📄.*끝 \\(D-(\\d+)\\)");

    /**
     * 미리 고를 연락 이유 (결과 창의 📋 개통 정보 줄에서)
     *  · 약정이 60일 안에 끝남 → '약정 만료 안내' · 🔔 기변 시기 → '기변 혜택 안내' (목록에 있을 때만)
     * @return {이유, 설명} · 없으면 {"", ""}
     */
    static String[] suggest(List<Facts.Line> lines, List<String> reasons) {
        int left = -1;
        boolean gibyun = false;
        for (Facts.Line l : lines) {
            Matcher m = CONTRACT_LEFT.matcher(l.text);
            if (m.find()) {
                int v = Integer.parseInt(m.group(1));
                if (left < 0 || v < left) left = v;
            }
            if (l.text.startsWith("🔔 기변 시기")) gibyun = true;
        }
        if (left >= 0 && left <= 60 && reasons.contains("약정 만료 안내"))
            return new String[]{"약정 만료 안내", "약정이 " + left + "일 뒤에 끝나서 '약정 만료 안내'를 미리 골랐어요"};
        if (gibyun && reasons.contains("기변 혜택 안내"))
            return new String[]{"기변 혜택 안내", "기변 시기라 '기변 혜택 안내'를 미리 골랐어요"};
        return new String[]{"", ""};
    }

    /** 이 고객에게는 광고 문자가 안 감 (광고 수신 거부 · 연락 원치 않음 · 고객거부) */
    static boolean denied(JSONObject d) {
        if (d == null) return false;
        return truthy(d.opt("marketingDeny")) || truthy(d.opt("missOptOut")) || "고객거부".equals(d.optString("salesStatus", ""));
    }

    private static boolean truthy(Object v) {
        if (v instanceof Boolean) return (Boolean) v;
        String s = v == null || v == JSONObject.NULL ? "" : String.valueOf(v).trim();
        return "true".equals(s) || "Y".equals(s) || "1".equals(s);
    }

    /**
     * 보낼 문자 미리 보기 (강CRM missText 와 같은 모양 · 링크 자리는 '(고객 전용 명함 링크)')
     *  cfg: smsTplMiss · smsStoreName · smsPromoOptout
     */
    static String preview(JSONObject cfg, String name, String staff, String phrase) {
        String tpl = cfg == null ? "" : cfg.optString("smsTplMiss", "");
        if (tpl.trim().isEmpty() || tpl.trim().equals(TPL_V222)) tpl = TPL_DEFAULT;
        String store = cfg == null ? "" : cfg.optString("smsStoreName", "").trim();
        if (store.isEmpty()) store = "매장";
        String opt = cfg == null ? "" : cfg.optString("smsPromoOptout", "").trim();
        if (opt.isEmpty()) opt = OPTOUT_DEFAULT;
        String ph = phrase == null || phrase.trim().isEmpty() ? DEFAULT_PHRASE : phrase.trim();
        String nm = name == null || name.trim().isEmpty() ? "고객" : name.trim();
        String st = staff == null ? "" : staff.trim();
        boolean hasOpt = tpl.contains("{수신거부}");
        String t = tpl;
        if (st.isEmpty()) t = t.replaceAll("\\s?\\{담당자\\}", "");
        t = t.replace("{이름}", nm).replace("{매장}", store).replace("{담당자}", st)
                .replace("{연락이유}", ph).replace("{명함}", "(고객 전용 명함 링크)").replace("{수신거부}", opt);
        t = t.replaceAll("\\{[^{}\\n]{1,8}\\}", "").replaceAll("\\n{3,}", "\n\n").trim();
        if (!t.startsWith("(광고)")) t = "(광고) " + t;
        if (!hasOpt) t = t + "\n" + opt;
        return t;
    }

    // ── 날짜 ──
    private static Calendar cal(long ms) {
        Calendar c = Calendar.getInstance();
        c.setTimeInMillis(ms);
        return c;
    }

    private static long at(Calendar c, int hour) {
        Calendar x = (Calendar) c.clone();
        x.set(Calendar.HOUR_OF_DAY, hour);
        x.set(Calendar.MINUTE, 0);
        x.set(Calendar.SECOND, 0);
        x.set(Calendar.MILLISECOND, 0);
        return x.getTimeInMillis();
    }

    private static Calendar day(Calendar c) {
        Calendar x = (Calendar) c.clone();
        x.set(Calendar.HOUR_OF_DAY, 0);
        x.set(Calendar.MINUTE, 0);
        x.set(Calendar.SECOND, 0);
        x.set(Calendar.MILLISECOND, 0);
        return x;
    }
}
