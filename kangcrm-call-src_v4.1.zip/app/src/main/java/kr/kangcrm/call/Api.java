package kr.kangcrm.call;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

/** 강CRM(파이어베이스) 주고받기 — 라이브러리 없이 REST로 (연결할 때 받은 로그인 정보로) */
final class Api {
    private Api() {}

    static final class ApiError extends Exception {
        final int code;

        ApiError(int code, String msg) {
            super(msg);
            this.code = code;
        }
    }

    static String FS_BASE = "https://firestore.googleapis.com";   // (시험용으로만 바꿈)

    static String docsUrl(Context c) {
        return FS_BASE + "/v1/projects/" + Store.get(c, "pid") + "/databases/(default)/documents";
    }

    // ── 로그인 표 (1시간마다 새로) ──────────────────────────
    static synchronized String idToken(Context c, boolean force) throws Exception {
        String t = Store.get(c, "idt");
        long exp = Store.getLong(c, "idexp");
        if (!force && !t.isEmpty() && System.currentTimeMillis() < exp - 120000L) return t;
        if (!Store.paired(c)) throw new ApiError(401, "강CRM과 아직 연결 안 됐어요");
        String body = "grant_type=refresh_token&refresh_token=" + URLEncoder.encode(Store.get(c, "rt"), "UTF-8");
        String url = "https://securetoken.googleapis.com/v1/token?key=" + URLEncoder.encode(Store.get(c, "key"), "UTF-8");
        JSONObject r = request(c, "POST", url, body, "application/x-www-form-urlencoded", null);
        String nt = r.optString("id_token", "");
        if (nt.isEmpty()) nt = r.optString("access_token", "");
        if (nt.isEmpty()) throw new ApiError(401, "로그인 표를 못 받았어요");
        long sec = 3600L;
        try {
            sec = Long.parseLong(r.optString("expires_in", "3600"));
        } catch (Exception ignore) {
            sec = 3600L;
        }
        Store.put(c, "idt", nt);
        Store.putLong(c, "idexp", System.currentTimeMillis() + sec * 1000L);
        String nrt = r.optString("refresh_token", "");
        if (!nrt.isEmpty()) Store.put(c, "rt", nrt);
        return nt;
    }

    static JSONObject request(Context c, String method, String url, String body, String ctype, String token) throws Exception {
        return request(c, method, url, body, ctype, token, 15000);
    }

    static JSONObject request(Context c, String method, String url, String body, String ctype, String token, int readMs) throws Exception {
        return request(c, method, url, body, ctype, token, readMs, 0);
    }

    private static JSONObject request(Context c, String method, String url, String body, String ctype, String token, int readMs, int hops) throws Exception {
        HttpURLConnection h = (HttpURLConnection) new URL(url).openConnection();
        try {
            h.setRequestMethod(method);
            h.setConnectTimeout(10000);
            h.setReadTimeout(readMs);
            h.setUseCaches(false);
            h.setInstanceFollowRedirects(false);   // 앱스 스크립트는 결과를 다른 주소로 넘겨줌 → 아래에서 GET으로
            String origin = Store.get(c, "origin");
            if (!origin.isEmpty()) h.setRequestProperty("Referer", origin + "/");   // 웹 키에 사이트 제한이 있어도 되게
            if (token != null) h.setRequestProperty("Authorization", "Bearer " + token);
            if (body != null) {
                byte[] b = body.getBytes(StandardCharsets.UTF_8);
                h.setDoOutput(true);
                h.setRequestProperty("Content-Type", ctype + "; charset=utf-8");
                h.setFixedLengthStreamingMode(b.length);
                OutputStream o = h.getOutputStream();
                try {
                    o.write(b);
                } finally {
                    o.close();
                }
            }
            int code = h.getResponseCode();
            if (code >= 300 && code < 400 && hops < 5) {
                String loc = h.getHeaderField("Location");
                if (loc != null && !loc.isEmpty()) {
                    String next = new URL(new URL(url), loc).toString();
                    boolean same = new URL(next).getHost().equals(new URL(url).getHost());
                    return request(c, "GET", next, null, null, same ? token : null, readMs, hops + 1);
                }
            }
            InputStream in = code >= 400 ? h.getErrorStream() : h.getInputStream();
            String s = in == null ? "" : readAll(in);
            if (code >= 400) {
                String msg = s;
                try {
                    Object e = new JSONObject(s).opt("error");
                    if (e instanceof JSONObject) msg = ((JSONObject) e).optString("message", s);
                    else if (e instanceof String) msg = (String) e;
                } catch (Exception ignore) {
                    msg = s;
                }
                throw new ApiError(code, msg == null ? ("오류 " + code) : msg);
            }
            String t = s.trim();
            if (t.isEmpty()) return new JSONObject();
            if (t.startsWith("[")) {
                JSONObject w = new JSONObject();
                w.put("list", new JSONArray(t));
                return w;
            }
            return new JSONObject(t);
        } finally {
            h.disconnect();
        }
    }

    static String readAll(InputStream in) throws Exception {
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n;
        try {
            while ((n = in.read(buf)) > 0) bo.write(buf, 0, n);
        } finally {
            in.close();
        }
        return new String(bo.toByteArray(), StandardCharsets.UTF_8);
    }

    /** 파이어스토어 요청 (로그인 표가 만료됐으면 한 번 새로 받아서 다시) */
    static JSONObject fs(Context c, String method, String pathOrUrl, String body) throws Exception {
        String url = pathOrUrl.startsWith("https://") || pathOrUrl.startsWith("http://") ? pathOrUrl : docsUrl(c) + "/" + pathOrUrl;
        String tok = idToken(c, false);
        try {
            return request(c, method, url, body, "application/json", tok);
        } catch (ApiError e) {
            if (e.code != 401) throw e;
            tok = idToken(c, true);
            return request(c, method, url, body, "application/json", tok);
        }
    }

    // ── 파이어스토어 값 ↔ 보통 JSON ─────────────────────────
    static Object fromValue(JSONObject v) throws JSONException {
        if (v == null) return JSONObject.NULL;
        if (v.has("stringValue")) return v.optString("stringValue", "");
        if (v.has("integerValue")) return v.optString("integerValue", "0");
        if (v.has("doubleValue")) return v.optDouble("doubleValue", 0);
        if (v.has("booleanValue")) return v.optBoolean("booleanValue", false);
        if (v.has("timestampValue")) return v.optString("timestampValue", "");
        if (v.has("mapValue")) {
            JSONObject o = new JSONObject();
            JSONObject mv = v.optJSONObject("mapValue");
            JSONObject f = mv == null ? null : mv.optJSONObject("fields");
            if (f != null) {
                Iterator<String> it = f.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    o.put(k, fromValue(f.optJSONObject(k)));
                }
            }
            return o;
        }
        if (v.has("arrayValue")) {
            JSONArray a = new JSONArray();
            JSONObject av = v.optJSONObject("arrayValue");
            JSONArray vals = av == null ? null : av.optJSONArray("values");
            if (vals != null) {
                for (int i = 0; i < vals.length(); i++) a.put(fromValue(vals.optJSONObject(i)));
            }
            return a;
        }
        return JSONObject.NULL;
    }

    static JSONObject toValue(Object o) throws JSONException {
        JSONObject v = new JSONObject();
        if (o == null || o == JSONObject.NULL) {
            v.put("nullValue", JSONObject.NULL);
        } else if (o instanceof Boolean) {
            v.put("booleanValue", ((Boolean) o).booleanValue());
        } else if (o instanceof Integer || o instanceof Long) {
            v.put("integerValue", String.valueOf(o));
        } else if (o instanceof Number) {
            v.put("doubleValue", ((Number) o).doubleValue());
        } else if (o instanceof JSONObject) {
            JSONObject m = (JSONObject) o;
            JSONObject f = new JSONObject();
            Iterator<String> it = m.keys();
            while (it.hasNext()) {
                String k = it.next();
                f.put(k, toValue(m.opt(k)));
            }
            v.put("mapValue", new JSONObject().put("fields", f));
        } else {
            v.put("stringValue", String.valueOf(o));
        }
        return v;
    }

    static JSONObject docToPlain(JSONObject d) throws JSONException {
        JSONObject out = new JSONObject();
        JSONObject f = d.optJSONObject("fields");
        if (f != null) {
            Iterator<String> it = f.keys();
            while (it.hasNext()) {
                String k = it.next();
                out.put(k, fromValue(f.optJSONObject(k)));
            }
        }
        String name = d.optString("name", "");
        int i = name.lastIndexOf('/');
        out.put("id", i >= 0 ? name.substring(i + 1) : name);
        return out;
    }

    // ── 고객 찾기 (번호 = 문서 번호 · 아니면 번호 칸으로) ─────────
    static JSONObject findCustomer(Context c, String digits) throws Exception {
        if (digits == null || digits.length() < 9) return null;
        JSONObject cu = null;
        try {
            cu = docToPlain(fs(c, "GET", "smart_customers/" + digits, null));
        } catch (ApiError e) {
            if (e.code != 404) throw e;
        }
        if (cu == null) {
            JSONObject filter = new JSONObject()
                    .put("field", new JSONObject().put("fieldPath", "phone"))
                    .put("op", "EQUAL")
                    .put("value", new JSONObject().put("stringValue", Fmt.phone(digits)));
            JSONObject sq = new JSONObject()
                    .put("from", new JSONArray().put(new JSONObject().put("collectionId", "smart_customers")))
                    .put("where", new JSONObject().put("fieldFilter", filter))
                    .put("limit", 1);
            JSONObject r = fs(c, "POST", docsUrl(c) + ":runQuery", new JSONObject().put("structuredQuery", sq).toString());
            JSONArray list = r.optJSONArray("list");
            if (list != null) {
                for (int i = 0; i < list.length(); i++) {
                    JSONObject it = list.optJSONObject(i);
                    if (it != null && it.optJSONObject("document") != null) {
                        cu = docToPlain(it.optJSONObject("document"));
                        break;
                    }
                }
            }
        }
        if (cu == null) return null;
        Object del = cu.opt("deletedAt");
        if (del != null && del != JSONObject.NULL && !String.valueOf(del).isEmpty()) return null;   // 휴지통 고객
        return cu;
    }

    /** 직원 계정 ↔ 이름 (담당자 계정 찾기용 · 6시간 기억) */
    static JSONObject staffByEmail(Context c) {
        long at = Store.getLong(c, "sbeAt");
        String cached = Store.get(c, "sbe");
        if (!cached.isEmpty() && System.currentTimeMillis() - at < 6L * 3600L * 1000L) {
            try {
                return new JSONObject(cached);
            } catch (Exception ignore) {
                // 아래에서 새로
            }
        }
        try {
            JSONObject s = docToPlain(fs(c, "GET", "smart_global/settings?mask.fieldPaths=staffByEmail", null));
            JSONObject m = s.optJSONObject("staffByEmail");
            if (m == null) m = new JSONObject();
            Store.put(c, "sbe", m.toString());
            Store.putLong(c, "sbeAt", System.currentTimeMillis());
            return m;
        } catch (Exception e) {
            try {
                return cached.isEmpty() ? new JSONObject() : new JSONObject(cached);
            } catch (Exception e2) {
                return new JSONObject();
            }
        }
    }

    static String managerEmailFor(Context c, String managerName) {
        if (managerName == null || managerName.trim().isEmpty()) return "";
        JSONObject m = staffByEmail(c);
        Iterator<String> it = m.keys();
        while (it.hasNext()) {
            String em = it.next();
            if (Fmt.sameStaff(m.optString(em, ""), managerName)) return em;
        }
        return "";
    }

    /** 통화 기록 한 건 올리기 (같은 번호로 이미 있으면 올린 것으로) */
    static void createCallLog(Context c, JSONObject log) throws Exception {
        JSONObject fields = new JSONObject();
        Iterator<String> it = log.keys();
        while (it.hasNext()) {
            String k = it.next();
            if ("id".equals(k) || k.startsWith("_")) continue;
            fields.put(k, toValue(log.opt(k)));
        }
        String id = log.optString("id");
        String stash = Store.get(c, "rec:" + id);   // 🎙 녹음이 먼저 올라갔으면 같이
        JSONObject rec = null;
        if (!stash.isEmpty()) {
            try {
                rec = new JSONObject(stash);
                Iterator<String> rk = rec.keys();
                while (rk.hasNext()) {
                    String k = rk.next();
                    fields.put(k, toValue(rec.opt(k)));
                }
            } catch (JSONException ignore) {
                rec = null;
            }
        }
        try {
            fs(c, "POST", docsUrl(c) + "/call_logs?documentId=" + URLEncoder.encode(id, "UTF-8"), new JSONObject().put("fields", fields).toString());
        } catch (ApiError e) {
            if (e.code != 409) throw e;   // 이미 올라감
            if (rec != null) patchCallLog(c, id, rec);
        }
        if (rec != null) Store.put(c, "rec:" + id, "");
    }

    /** 이미 올라간 통화 기록에 몇 칸 더하기 (기록이 아직 없으면 오류) — PATCH 대신 commit(POST) */
    static void patchCallLog(Context c, String id, JSONObject add) throws Exception {
        JSONObject fields = new JSONObject();
        JSONArray paths = new JSONArray();
        Iterator<String> it = add.keys();
        while (it.hasNext()) {
            String k = it.next();
            fields.put(k, toValue(add.opt(k)));
            paths.put(k);
        }
        String name = "projects/" + Store.get(c, "pid") + "/databases/(default)/documents/call_logs/" + id;
        JSONObject w = new JSONObject()
                .put("update", new JSONObject().put("name", name).put("fields", fields))
                .put("updateMask", new JSONObject().put("fieldPaths", paths))
                .put("currentDocument", new JSONObject().put("exists", true));
        fs(c, "POST", docsUrl(c) + ":commit", new JSONObject().put("writes", new JSONArray().put(w)).toString());
    }

    /** 📋 v4 이 폰 통화 기록들 한 번에 (AI 제목 · 요약 · 녹음 · 결과) — 없는 건 빠짐 */
    static java.util.Map<String, JSONObject> callLogsById(Context c, java.util.List<String> ids) throws Exception {
        java.util.Map<String, JSONObject> out = new java.util.HashMap<>();
        if (ids.isEmpty()) return out;
        String base = "projects/" + Store.get(c, "pid") + "/databases/(default)/documents/call_logs/";
        JSONArray names = new JSONArray();
        for (String id : ids) names.put(base + id);
        JSONArray mask = new JSONArray();
        for (String f : new String[]{"aiTitle", "aiSummary", "aiNext", "aiState", "recFileId", "recSize", "result", "resultKey", "memo", "nextKind", "nextDate", "applied"}) mask.put(f);
        JSONObject r = fs(c, "POST", docsUrl(c) + ":batchGet", new JSONObject().put("documents", names).put("mask", new JSONObject().put("fieldPaths", mask)).toString());
        JSONArray list = r.optJSONArray("list");
        if (list == null) return out;
        for (int i = 0; i < list.length(); i++) {
            JSONObject it = list.optJSONObject(i);
            JSONObject f = it == null ? null : it.optJSONObject("found");
            if (f == null) continue;
            JSONObject d = docToPlain(f);
            out.put(d.optString("id"), d);
        }
        return out;
    }

    // ── 🕘 v3 이 고객의 지난 통화 (팝업 · 결과 창 한 줄) ──
    private static JSONObject eq(String field, String v) throws JSONException {
        return new JSONObject().put("fieldFilter", new JSONObject()
                .put("field", new JSONObject().put("fieldPath", field))
                .put("op", "EQUAL")
                .put("value", new JSONObject().put("stringValue", v)));
    }

    private static JSONArray logsWhere(Context c, JSONObject where) throws Exception {
        JSONObject sq = new JSONObject()
                .put("from", new JSONArray().put(new JSONObject().put("collectionId", "call_logs")))
                .put("where", where)
                .put("limit", 40);
        JSONObject r = fs(c, "POST", docsUrl(c) + ":runQuery", new JSONObject().put("structuredQuery", sq).toString());
        JSONArray out = new JSONArray();
        JSONArray list = r.optJSONArray("list");
        if (list == null) return out;
        for (int i = 0; i < list.length(); i++) {
            JSONObject it = list.optJSONObject(i);
            if (it != null && it.optJSONObject("document") != null) out.put(docToPlain(it.optJSONObject("document")));
        }
        return out;
    }

    private static JSONObject and(JSONObject a, JSONObject b) throws JSONException {
        return new JSONObject().put("compositeFilter", new JSONObject().put("op", "AND").put("filters", new JSONArray().put(a).put(b)));
    }

    /** 이 고객 통화 기록 (👑 대표는 전부 · 직원은 내가 받은 것 + 내 담당 고객 것 — 보안 규칙과 같게) */
    static JSONArray callLogsFor(Context c, String customerId) throws Exception {
        String me = Store.get(c, "email");
        if (!"own".equals(Store.get(c, "lcMode"))) {
            try {
                JSONArray all = logsWhere(c, eq("customerId", customerId));
                Store.put(c, "lcMode", "all");
                return all;
            } catch (ApiError e) {
                if (e.code != 403) throw e;
                Store.put(c, "lcMode", "own");
            }
        }
        JSONArray out = new JSONArray();
        java.util.Set<String> seen = new java.util.HashSet<>();
        for (String f : new String[]{"uploader", "managerEmail"}) {
            JSONArray part;
            try {
                part = logsWhere(c, and(eq("customerId", customerId), eq(f, me)));
            } catch (ApiError e) {
                if (e.code == 403) continue;
                throw e;
            }
            for (int i = 0; i < part.length(); i++) {
                JSONObject x = part.optJSONObject(i);
                if (x != null && seen.add(x.optString("id"))) out.put(x);
            }
        }
        return out;
    }

    /** 서류 백업 설정 (업로드 창구 주소 · 비밀번호 · 방식) — 1시간 기억 */
    static JSONObject driveCfg(Context c) throws Exception {
        long at = Store.getLong(c, "dcfgAt");
        String cached = Store.get(c, "dcfg");
        if (!cached.isEmpty() && System.currentTimeMillis() - at < 3600L * 1000L) {
            try {
                return new JSONObject(cached);
            } catch (JSONException ignore) {
                // 아래에서 새로
            }
        }
        JSONObject s = docToPlain(fs(c, "GET", "smart_global/settings?mask.fieldPaths=driveScriptUrl&mask.fieldPaths=driveSecret&mask.fieldPaths=driveMode&mask.fieldPaths=crmHref", null));
        Store.put(c, "dcfg", s.toString());
        Store.putLong(c, "dcfgAt", System.currentTimeMillis());
        return s;
    }
}
