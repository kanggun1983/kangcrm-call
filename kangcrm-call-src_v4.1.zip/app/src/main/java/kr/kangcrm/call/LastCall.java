package kr.kangcrm.call;

import android.content.Context;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.TimeZone;

/** 🕘 v3 '지난 통화 한 줄' — 다시 전화 온 고객과 바로 이어서 얘기하게 (AI 제목 · 다음 할 일) */
final class LastCall {
    private LastCall() {}

    private static final Map<String, String> CACHE = new HashMap<>();
    private static final Map<String, Long> AT = new HashMap<>();

    static long ms(String iso) {
        if (iso == null || iso.length() < 19) return 0;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.US);
            f.setTimeZone(TimeZone.getTimeZone("UTC"));
            Date d = f.parse(iso.substring(0, 19));
            return d == null ? 0 : d.getTime();
        } catch (Exception e) {
            return 0;
        }
    }

    static String when(long t) {
        return new SimpleDateFormat("M/d", Locale.KOREA).format(new Date(t));
    }

    static boolean connected(JSONObject l) {
        String d = l.optString("direction");
        return ("in".equals(d) || "out".equals(d)) && l.optLong("durationSec", 0) > 0;
    }

    static String titleOf(JSONObject l) {
        String t = l.optString("aiTitle", "").trim();
        if (!t.isEmpty()) return t;
        JSONArray s = l.optJSONArray("aiSummary");
        if (s != null && s.length() > 0 && !s.optString(0, "").trim().isEmpty()) return s.optString(0).trim();
        String r = l.optString("result", "").trim(), m = l.optString("memo", "").replaceAll("\\s+", " ").trim();
        String x = r + (m.isEmpty() ? "" : (r.isEmpty() ? "" : " - ") + m);
        if (!x.isEmpty()) return x.length() > 60 ? x.substring(0, 60) + "…" : x;
        String dur = Fmt.dur(l.optLong("durationSec", 0));
        return dur.isEmpty() ? "통화" : "통화 " + dur;
    }

    /** 통화 기록 목록 → 한 줄 (없으면 "") · excludeId = 방금 끝난 통화 */
    static String line(JSONArray logs, String excludeId) {
        if (logs == null) return "";
        JSONObject last = null;
        long lastAt = 0;
        for (int i = 0; i < logs.length(); i++) {
            JSONObject l = logs.optJSONObject(i);
            if (l == null || l.optString("id").equals(excludeId) || !connected(l)) continue;
            long t = ms(l.optString("startedAt"));
            if (t > lastAt) {
                lastAt = t;
                last = l;
            }
        }
        int missed = 0;
        long missedLast = 0;
        for (int i = 0; i < logs.length(); i++) {
            JSONObject l = logs.optJSONObject(i);
            if (l == null || l.optString("id").equals(excludeId) || connected(l)) continue;
            long t = ms(l.optString("startedAt"));
            if (t > lastAt) {
                missed++;
                missedLast = Math.max(missedLast, t);
            }
        }
        if (last == null) return missed > 0 ? "🕘 통화한 적은 없고 부재중 " + missed + "번 (마지막 " + when(missedLast) + ")" : "";
        StringBuilder b = new StringBuilder("🕘 지난 통화 ").append(when(lastAt)).append(" · ").append(titleOf(last));
        if (missed > 0) b.append(" · 그 뒤 부재 ").append(missed).append("번");
        String next = last.optString("aiNext", "").trim();
        if (!next.isEmpty()) b.append("\n➡️ ").append(next);
        else if (!last.optString("nextDate", "").isEmpty()) b.append("\n➡️ 다음 ").append("visit".equals(last.optString("nextKind")) ? "방문 " : "연락 ").append(Fmt.md(last.optString("nextDate")));
        return b.toString();
    }

    /** 강CRM에서 읽어서 한 줄 (10분 기억 · 인터넷이 안 되면 "") — 백그라운드에서 부르기 */
    static String fetch(Context c, String customerId, String excludeId) {
        if (customerId == null || customerId.isEmpty()) return "";
        synchronized (CACHE) {
            Long at = AT.get(customerId);
            if (excludeId == null && at != null && System.currentTimeMillis() - at < 10 * 60 * 1000L) return CACHE.get(customerId);
        }
        try {
            String s = line(Api.callLogsFor(c, customerId), excludeId);
            synchronized (CACHE) {
                CACHE.put(customerId, s);
                AT.put(customerId, System.currentTimeMillis());
            }
            return s;
        } catch (Exception e) {
            Log.w("KC", "lastCall", e);
            return "";
        }
    }
}
