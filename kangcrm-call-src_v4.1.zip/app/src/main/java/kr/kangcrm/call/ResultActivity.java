package kr.kangcrm.call;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** 전화를 끊으면 뜨는 '통화 결과' 창 → 강CRM 연락 기록 · 약속으로 */
public class ResultActivity extends Activity {
    // 강CRM의 '통화 결과'와 같은 버튼 (영업상태도 똑같이 바뀜)
    private static final String[] KEYS = {"done", "interest", "visit", "refuse"};
    private static final String[] RESULTS = {"통화 완료", "관심 있음", "방문약속", "거부"};
    private static final String[] ICONS = {"✅", "🙂", "🏪", "🙅"};
    // ✍️ v3 빠른 메모 (누르면 메모 칸에 붙음)
    private static final String[] QUICK = {"견적 문자 보냄", "가족과 상의", "재연락 요청", "방문 예정", "기변 문의", "요금 문의", "부재 · 문자 남김", "명함 보냄"};
    private static final String[] HINTS = {
            "영업상태는 그대로 두고 통화 기록만 남겨요.",
            "영업상태가 '가망고객'으로 바뀌어요.",
            "영업상태가 '방문약속'으로 바뀌어요. 날짜를 고르면 방문 약속으로 잡혀요.",
            "영업상태가 '고객거부'로 바뀌고 타겟 목록에서 빠져요."};

    private JSONObject log;
    private boolean test;
    private String result = "", resultKey = "";
    private TextView hint;
    private String nextDate = "";
    private EditText memo;
    private TextView dateBtn;
    private final List<Button> resultBtns = new ArrayList<>();
    private boolean saving;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        load(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        load(intent);
        build();
    }

    private void load(Intent i) {
        test = i != null && i.getBooleanExtra("test", false);
        try {
            log = new JSONObject(i == null ? "{}" : i.getStringExtra("log"));
        } catch (Exception e) {
            log = new JSONObject();
        }
        result = "";
        resultKey = "";
        nextDate = "";
        saving = false;
    }

    private void build() {
        resultBtns.clear();
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.setFillViewport(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, Ui.dp(this, 24), p, Ui.dp(this, 24));
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String dir = log.optString("direction");
        String head = "in".equals(dir) ? "📲 받은 전화" : "📞 건 전화";
        String dur = Fmt.dur(log.optLong("durationSec", 0));
        box.addView(Ui.text(this, head + (dur.isEmpty() ? "" : " · " + dur) + (test ? " · 시험" : ""), 15, Ui.INDIGO, true));

        LinearLayout who = Ui.card(this);
        who.addView(Ui.text(this, log.optString("customerName", "고객"), 24, Ui.INK, true));
        who.addView(Ui.text(this, Fmt.phone(log.optString("phone")), 15, Ui.GRAY, false));
        String l2 = log.optString("_line2");
        if (!l2.isEmpty()) who.addView(Ui.text(this, l2, 15, Ui.INK, true));
        String l3 = log.optString("_line3");
        if (!l3.isEmpty()) who.addView(Ui.text(this, l3, 14, Ui.GRAY, false));
        for (Facts.Line f : Facts.fromJson(log.optString("_facts"))) {   // 📋 v3 개통 · 할부 · 약정 · 기변 시기
            int col = f.tone == Facts.ALERT ? Ui.RED : (f.tone == Facts.WARN ? Color.parseColor("#B45309") : Ui.INK);
            TextView ft = Ui.text(this, f.text, 14, col, f.tone != Facts.NORMAL);
            ft.setPadding(0, Ui.dp(this, 2), 0, 0);
            who.addView(ft);
        }
        String m0 = log.optString("_memo");
        if (!m0.isEmpty()) {
            TextView mt = Ui.text(this, "📝 " + m0, 14, Ui.GRAY, false);
            mt.setMaxLines(2);
            mt.setPadding(0, Ui.dp(this, 4), 0, 0);
            who.addView(mt);
        }
        String last = log.optString("_last");
        if (!last.isEmpty()) {   // 🕘 v3 지난 통화
            TextView lt = Ui.text(this, last, 14, Ui.INK, false);
            lt.setBackground(Ui.round(Color.parseColor("#EEF2FF"), 0, 10, this));
            int lp = Ui.dp(this, 10);
            lt.setPadding(lp, Ui.dp(this, 8), lp, Ui.dp(this, 8));
            who.addView(lt, Ui.full(this, 8));
        }
        box.addView(who, Ui.full(this, 10));

        box.addView(Ui.text(this, "통화 결과", 15, Ui.INK, true), Ui.full(this, 18));
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 2; r++) {
            LinearLayout row = Ui.row(this);
            for (int k = 0; k < 2; k++) {
                final int idx = r * 2 + k;
                final Button bt = Ui.button(this, ICONS[idx] + " " + RESULTS[idx], false);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pick(idx);
                    }
                });
                resultBtns.add(bt);
                row.addView(bt, Ui.weight(this, k == 0 ? 0 : 8));
            }
            grid.addView(row, Ui.full(this, r == 0 ? 6 : 8));
        }
        box.addView(grid);
        hint = Ui.text(this, "결과를 고르면 강CRM 영업상태와 연락 기록에 바로 반영돼요.", 13, Ui.GRAY, false);
        box.addView(hint, Ui.full(this, 8));

        box.addView(Ui.text(this, "메모", 15, Ui.INK, true), Ui.full(this, 18));
        memo = new EditText(this);
        memo.setHint("예: 견적 보내드림 · 목요일 오전에 다시 연락");
        memo.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        memo.setMinLines(3);
        memo.setGravity(Gravity.TOP | Gravity.START);
        memo.setTextSize(16);
        memo.setTextColor(Ui.INK);
        memo.setBackground(Ui.round(Color.WHITE, Color.parseColor("#D1D5DB"), 12, this));
        int mp = Ui.dp(this, 12);
        memo.setPadding(mp, mp, mp, mp);
        box.addView(memo, Ui.full(this, 6));
        LinearLayout chips = new LinearLayout(this);   // ✍️ v3 빠른 메모
        chips.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < QUICK.length; r += 4) {
            LinearLayout row = Ui.row(this);
            for (int k = r; k < Math.min(r + 4, QUICK.length); k++) {
                final String q = QUICK[k];
                Button ch = Ui.button(this, q, false);
                ch.setTextSize(13);
                ch.setMinHeight(Ui.dp(this, 40));
                ch.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
                ch.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String cur = memo.getText().toString().trim();
                        if (cur.contains(q)) return;
                        memo.setText(cur.isEmpty() ? q : cur + " · " + q);
                        memo.setSelection(memo.getText().length());
                    }
                });
                row.addView(ch, Ui.weight(this, k == r ? 0 : 6));
            }
            chips.addView(row, Ui.full(this, 6));
        }
        box.addView(chips);

        box.addView(Ui.text(this, "다음 연락일 (선택 · 방문약속이면 방문 날짜)", 15, Ui.INK, true), Ui.full(this, 18));
        dateBtn = Ui.button(this, "📅 날짜 고르기", false);
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickDate();
            }
        });
        box.addView(dateBtn, Ui.full(this, 6));

        Button save = Ui.button(this, "강CRM에 저장", true);
        save.setMinHeight(Ui.dp(this, 56));
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSave(false);
            }
        });
        box.addView(save, Ui.full(this, 24));

        Button skip = Ui.button(this, "결과 없이 기록만", false);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSave(true);
            }
        });
        box.addView(skip, Ui.full(this, 8));

        TextView note = Ui.text(this, "저장하면 강CRM 고객카드의 연락 기록에 들어가요. 날짜를 고르면 약속 달력에도 들어가요. 통화 기록은 👑 대표와 이 고객 담당자만 봐요.", 13, Ui.GRAY, false);
        box.addView(note, Ui.full(this, 14));

        setContentView(sv);
    }

    private void pick(int idx) {
        result = RESULTS[idx];
        resultKey = KEYS[idx];
        if (hint != null) hint.setText(HINTS[idx]);
        for (int i = 0; i < resultBtns.size(); i++) {
            Button bt = resultBtns.get(i);
            boolean on = i == idx;
            bt.setTextColor(on ? Color.WHITE : Ui.INK);
            bt.setBackground(Ui.round(on ? Ui.INDIGO : Color.WHITE, on ? 0 : Color.parseColor("#D1D5DB"), 12, this));
        }
        if ("visit".equals(resultKey) && nextDate.isEmpty()) pickDate();
    }

    private void pickDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        DatePickerDialog d = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int y, int m, int day) {
                nextDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, day);
                dateBtn.setText("📅 " + Fmt.md(nextDate) + " · 바꾸려면 누르기");
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        d.show();
    }

    private void doSave(boolean skipResult) {
        if (saving) return;
        saving = true;
        try {
            String m = memo.getText().toString().trim();
            log.put("result", skipResult ? "" : result);
            log.put("resultKey", skipResult ? "" : resultKey);
            log.put("memo", skipResult ? "" : m);
            String kind = "";
            if (!skipResult && !nextDate.isEmpty()) kind = "visit".equals(resultKey) ? "visit" : "call";
            log.put("nextKind", kind);
            log.put("nextDate", kind.isEmpty() ? "" : nextDate);
            log.put("at", Fmt.iso(System.currentTimeMillis()));
        } catch (Exception e) {
            saving = false;
            Toast.makeText(this, "저장하지 못했어요", Toast.LENGTH_SHORT).show();
            return;
        }
        Notifs.cancelResult(this);
        if (test) {
            Toast.makeText(this, "시험이라 저장하지 않았어요 (" + (skipResult ? "결과 없음" : result) + ")", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        final JSONObject toSave = log;
        final android.content.Context app = getApplicationContext();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                final boolean ok = CallFlow.save(app, toSave);
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(app, ok ? "강CRM에 저장했어요" : "인터넷이 안 돼서 나중에 올려요", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        finish();
    }

    @Override
    public void onBackPressed() {
        doSave(true);   // 뒤로 가도 통화한 건 기록 (결과 없이)
    }
}
