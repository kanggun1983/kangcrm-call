package kr.kangcrm.call;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * v4 첫 화면 — 강CRM처럼 맨 아래 고정 메뉴
 *  📞 통화 기록 (오늘 요약 · 받은/건/부재 거르기 · 날짜별 · 누르면 한 건 화면)
 *  🎙 녹음 (켜고 끄기 · 와이파이 · 통화마다 올림/기다림/못 찾음)
 *  ⚙️ 설정 (강CRM 연결 · 권한 · 시험해 보기)
 */
public class MainActivity extends Activity {
    static final String T_CALLS = "calls", T_REC = "rec", T_SET = "set";
    static final int AMBER = Color.parseColor("#B45309");
    static final Map<String, JSONObject> SRV = new HashMap<>();   // 강CRM 통화 기록 (AI 제목 · 녹음 · 결과)
    static final Map<String, List<Facts.Line>> FACTS = new HashMap<>();
    private static long srvAt;

    private String tab = T_CALLS, filter = "all", detailId = null;
    private FrameLayout content;
    private ScrollView curScroll;
    private String curKey = "";
    private final ImageView[] navIcons = new ImageView[3];
    private final TextView[] navLabels = new TextView[3];
    private static final String[] NAV_KEYS = {T_CALLS, T_REC, T_SET};
    private String checkMsg = "", recFind = "";
    private EditText testNum;
    private boolean resumed;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (handlePair(getIntent())) tab = T_SET;
        buildShell();
        render(false);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (handlePair(intent)) {
            tab = T_SET;
            detailId = null;
        }
        render(false);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        render(true);
        final Context app = getApplicationContext();
        if (Store.paired(app)) RecBackup.flush(app);
        if (Store.paired(app) && Store.arr(app, "queue").length() > 0) {
            CallFlow.EX.execute(new Runnable() {
                @Override
                public void run() {
                    final int n = CallFlow.flushQueue(app);
                    if (n > 0) CallFlow.H.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(app, "못 올린 통화 기록 " + n + "건을 올렸어요", Toast.LENGTH_SHORT).show();
                            if (resumed) render(true);
                        }
                    });
                }
            });
        }
        fetchServer(false);
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
    }

    @Override
    public void onBackPressed() {
        if (detailId != null) {
            detailId = null;
            render(false);
        } else if (!T_CALLS.equals(tab)) {
            tab = T_CALLS;
            render(false);
        } else {
            super.onBackPressed();
        }
    }

    // ── 강CRM(크롬)의 [이 폰을 전화 앱과 연결] → kangcrmcall://pair?d=… ──
    private boolean handlePair(Intent i) {
        if (i == null || i.getData() == null) return false;
        Uri u = i.getData();
        if (!"kangcrmcall".equals(u.getScheme()) || !"pair".equals(u.getHost())) return false;
        try {
            String d = u.getQueryParameter("d");
            if (d == null) throw new IllegalArgumentException("no data");
            byte[] raw = Base64.decode(d, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            JSONObject j = new JSONObject(new String(raw, StandardCharsets.UTF_8));
            String rt = j.optString("rt"), key = j.optString("key"), pid = j.optString("pid");
            if (rt.isEmpty() || key.isEmpty() || pid.isEmpty()) throw new IllegalArgumentException("missing");
            Store.unpair(this);
            Store.put(this, "rt", rt);
            Store.put(this, "key", key);
            Store.put(this, "pid", pid);
            Store.put(this, "origin", j.optString("origin"));
            Store.put(this, "href", j.optString("href"));   // v4 강CRM 주소 (고객카드 열기)
            Store.put(this, "email", j.optString("email"));
            Store.put(this, "staff", j.optString("staff"));
            Store.put(this, "st", "IDLE");
            i.setData(null);
            checkMsg = "연결 확인 중…";
            check();
        } catch (Exception e) {
            checkMsg = "❌ 연결 정보를 읽지 못했어요. 강CRM에서 다시 눌러 주세요.";
        }
        return true;
    }

    /** 로그인 표 받기 + 직원 목록 읽기로 연결 확인 */
    private void check() {
        final Context app = getApplicationContext();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                String msg;
                try {
                    Api.idToken(app, true);
                    Store.putLong(app, "sbeAt", 0);
                    JSONObject m = Api.staffByEmail(app);
                    msg = "✅ 강CRM과 연결됐어요" + (m.length() > 0 ? " (직원 " + m.length() + "명)" : "");
                } catch (Api.ApiError e) {
                    msg = e.code == 400 || e.code == 401 || e.code == 403
                            ? "❌ 로그인이 만료됐거나 권한이 없어요. 강CRM에서 [이 폰을 전화 앱과 연결]을 다시 눌러 주세요. (" + e.code + ")"
                            : "❌ 연결 확인 실패: " + e.getMessage();
                } catch (Exception e) {
                    msg = "❌ 인터넷을 확인해 주세요 (" + e.getClass().getSimpleName() + ")";
                }
                final String fm = msg;
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        checkMsg = fm;
                        if (resumed) render(true);
                    }
                });
            }
        });
    }

    /** 강CRM에서 이 폰 통화들의 AI 제목 · 녹음 · 결과 받아오기 (30초에 한 번) */
    private void fetchServer(boolean force) {
        final Context app = getApplicationContext();
        if (!Store.paired(app) || (!force && System.currentTimeMillis() - srvAt < 30000L)) return;
        srvAt = System.currentTimeMillis();
        final List<String> ids = new ArrayList<>();
        JSONArray a = Store.arr(app, "recent");
        for (int i = 0; i < a.length() && ids.size() < 60; i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && o.optBoolean("ok") && !o.optString("id").isEmpty()) ids.add(o.optString("id"));
        }
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                boolean changed = false;
                try {
                    Map<String, JSONObject> m = Api.callLogsById(app, ids);
                    synchronized (SRV) {
                        SRV.putAll(m);
                    }
                    changed = !m.isEmpty();
                } catch (Exception e) {
                    android.util.Log.w("KC", "srv", e);
                }
                try {
                    String h = Api.driveCfg(app).optString("crmHref", "");
                    if (!h.isEmpty()) Store.put(app, "crmHref", h);
                } catch (Exception ignore) {
                    // 나중에
                }
                if (changed) CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        if (resumed) render(true);
                    }
                });
            }
        });
    }

    // ── 화면 틀: 위 = 내용 (스크롤) · 아래 = 고정 메뉴 ──
    private void buildShell() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        content = new FrameLayout(this);
        root.addView(content, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        View line = new View(this);
        line.setBackgroundColor(Ui.LINE);
        root.addView(line, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 1)));
        LinearLayout nav = new LinearLayout(this);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(Color.WHITE);
        String[] labels = {"통화 기록", "녹음", "설정"};
        int[] icons = {R.drawable.nv_phone, R.drawable.nv_mic, R.drawable.nv_set};
        for (int i = 0; i < 3; i++) {
            final String key = NAV_KEYS[i];
            LinearLayout it = new LinearLayout(this);
            it.setOrientation(LinearLayout.VERTICAL);
            it.setGravity(Gravity.CENTER);
            it.setContentDescription(labels[i]);
            ImageView iv = new ImageView(this);
            iv.setImageResource(icons[i]);
            LinearLayout.LayoutParams ilp = new LinearLayout.LayoutParams(Ui.dp(this, 26), Ui.dp(this, 26));
            ilp.gravity = Gravity.CENTER_HORIZONTAL;
            it.addView(iv, ilp);
            // 강CRM처럼 그림 바로 밑에 메뉴 이름 (가운데)
            TextView tv = Ui.text(this, labels[i], 13, Ui.GRAY, false);
            tv.setGravity(Gravity.CENTER);
            tv.setSingleLine(true);
            tv.setPadding(0, Ui.dp(this, 4), 0, 0);
            LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tlp.gravity = Gravity.CENTER_HORIZONTAL;
            it.addView(tv, tlp);
            it.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tab = key;
                    detailId = null;
                    render(false);
                    if (T_CALLS.equals(key)) fetchServer(false);
                }
            });
            navIcons[i] = iv;
            navLabels[i] = tv;
            nav.addView(it, new LinearLayout.LayoutParams(0, Ui.dp(this, 64), 1f));
        }
        root.addView(nav, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 64)));
        setContentView(root);
    }

    private void updateNav() {
        for (int i = 0; i < 3; i++) {
            boolean on = NAV_KEYS[i].equals(tab);
            int col = on ? Ui.INDIGO : Ui.GRAY;
            navIcons[i].setColorFilter(col);
            navLabels[i].setTextColor(col);
            navLabels[i].setTypeface(android.graphics.Typeface.DEFAULT, on ? android.graphics.Typeface.BOLD : android.graphics.Typeface.NORMAL);
        }
    }

    /** 지금 탭(또는 통화 한 건)을 다시 그림 · keep = 같은 화면이면 스크롤 위치 그대로 */
    private void render(boolean keep) {
        if (content == null) return;
        String key = detailId != null ? "d:" + detailId : tab + ":" + filter;
        final int y = keep && key.equals(curKey) && curScroll != null ? curScroll.getScrollY() : 0;
        content.removeAllViews();
        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        page.setPadding(p, Ui.dp(this, 20), p, Ui.dp(this, detailId != null ? 88 : 24));
        sv.addView(page, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        content.addView(sv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        if (detailId != null) buildDetail(page);
        else if (T_REC.equals(tab)) buildRec(page);
        else if (T_SET.equals(tab)) buildSet(page);
        else buildCalls(page);
        curScroll = sv;
        curKey = key;
        if (y > 0) {
            final ScrollView fs = sv;
            sv.post(new Runnable() {
                @Override
                public void run() {
                    fs.scrollTo(0, y);
                }
            });
        }
        updateNav();
    }

    // ── 작은 조각 ──
    private ImageView icon(int res, int color, int sizeDp) {
        ImageView iv = new ImageView(this);
        iv.setImageResource(res);
        iv.setColorFilter(color);
        iv.setLayoutParams(new LinearLayout.LayoutParams(Ui.dp(this, sizeDp), Ui.dp(this, sizeDp)));
        return iv;
    }

    private TextView chip(String s, int fg, int bg) {
        TextView t = Ui.text(this, s, 11, fg, true);
        t.setBackground(Ui.round(bg, 0, 6, this));
        t.setPadding(Ui.dp(this, 6), Ui.dp(this, 2), Ui.dp(this, 6), Ui.dp(this, 2));
        return t;
    }

    private LinearLayout.LayoutParams wrapLeft(int leftDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = Ui.dp(this, leftDp);
        return lp;
    }

    private View divider() {
        View v = new View(this);
        v.setBackgroundColor(Color.parseColor("#F3F4F6"));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 1));
        lp.leftMargin = Ui.dp(this, 14);
        lp.rightMargin = Ui.dp(this, 14);
        v.setLayoutParams(lp);
        return v;
    }

    private LinearLayout plainCard() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(Ui.round(Color.WHITE, Ui.LINE, 16, this));
        return l;
    }

    private void header(LinearLayout page, int iconRes, String title, View right) {
        LinearLayout h = Ui.row(this);
        if (iconRes != 0) {
            ImageView ic = icon(iconRes, Ui.INDIGO, 24);
            ((LinearLayout.LayoutParams) ic.getLayoutParams()).rightMargin = Ui.dp(this, 8);
            h.addView(ic);
        }
        h.addView(Ui.text(this, title, 22, Ui.INK, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (right != null) h.addView(right);
        page.addView(h);
    }

    static long startMs(JSONObject o) {
        long t = LastCall.ms(o.optString("startedAt"));
        return t > 0 ? t : o.optLong("at");
    }

    static String ampm(long t) {
        Date d = new Date(t);
        int h = Integer.parseInt(new SimpleDateFormat("H", Locale.US).format(d));
        return (h < 12 ? "오전 " : "오후 ") + (h % 12 == 0 ? 12 : h % 12) + new SimpleDateFormat(":mm", Locale.US).format(d);
    }

    static String dayLabel(long t) {
        String ymd = Fmt.ymd(t), today = Fmt.ymd(System.currentTimeMillis()), yest = Fmt.ymd(System.currentTimeMillis() - 86400000L);
        String body = new SimpleDateFormat("M. d. EEEE", Locale.KOREA).format(new Date(t));
        return (ymd.equals(today) ? "오늘 " : (ymd.equals(yest) ? "어제 " : "")) + body;
    }

    static boolean bad(JSONObject o) {
        String d = o.optString("direction");
        return "missed".equals(d) || "noanswer".equals(d);
    }

    JSONObject srv(String id) {
        synchronized (SRV) {
            return SRV.get(id);
        }
    }

    boolean recOk(String id) {
        JSONObject s = srv(id);
        if (s != null && !s.optString("recFileId", "").isEmpty()) return true;
        JSONObject l = RecBackup.logOf(this, id);
        return l != null && "ok".equals(l.optString("state"));
    }

    String aiTitle(String id) {
        JSONObject s = srv(id);
        if (s == null) return "";
        String t = s.optString("aiTitle", "").trim();
        if (!t.isEmpty()) return t;
        JSONArray a = s.optJSONArray("aiSummary");
        return a != null && a.length() > 0 ? a.optString(0, "") : "";
    }

    static String dirLabel(JSONObject o) {
        String d = o.optString("direction"), dur = Fmt.dur(o.optLong("dur", 0));
        if ("missed".equals(d)) return "부재중 (못 받음)";
        if ("noanswer".equals(d)) return "건 전화 · 안 받음";
        return ("in".equals(d) ? "받은 전화" : "건 전화") + (dur.isEmpty() ? "" : " · " + dur);
    }

    // ═══ 📞 통화 기록 ═══
    private void buildCalls(LinearLayout page) {
        boolean paired = Store.paired(this);
        TextView pill = Ui.text(this, paired ? "● 강CRM 연결됨" : "● 연결 안 됨", 12, paired ? Ui.GREEN : Ui.RED, true);
        pill.setBackground(Ui.round(Color.parseColor(paired ? "#ECFDF5" : "#FEF2F2"), 0, 99, this));
        pill.setPadding(Ui.dp(this, 10), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4));
        header(page, R.drawable.nv_phone, "고객 통화", pill);
        String staff = Store.get(this, "staff");
        page.addView(Ui.text(this, (staff.isEmpty() ? "" : staff + " · ") + "이 폰의 강CRM 고객 통화만 보여요", 12, Ui.GRAY, false), Ui.full(this, 4));
        if (!paired) {
            LinearLayout cd = Ui.card(this);
            cd.addView(Ui.text(this, "아직 강CRM과 연결 안 됐어요. 아래 메뉴의 [설정]에서 연결해 주세요.", 15, Ui.INK, false));
            Button go = Ui.button(this, "설정으로", true);
            go.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    tab = T_SET;
                    render(false);
                }
            });
            cd.addView(go, Ui.full(this, 10));
            page.addView(cd, Ui.full(this, 14));
            return;
        }
        JSONArray a = Store.arr(this, "recent");
        String today = Fmt.ymd(System.currentTimeMillis());
        int nAll = 0, nMiss = 0, nRec = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !Fmt.ymd(startMs(o)).equals(today)) continue;
            nAll++;
            if (bad(o)) nMiss++;
            if (recOk(o.optString("id"))) nRec++;
        }
        int nFail = Store.arr(this, "queue").length();
        LinearLayout stats = Ui.row(this);
        stats.setBackground(Ui.round(Color.WHITE, Ui.LINE, 16, this));
        stats.setPadding(Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6), Ui.dp(this, 12));
        String[] sl = {"오늘 통화", "부재중", "녹음 올림", "못 올림"};
        int[] sv = {nAll, nMiss, nRec, nFail};
        int[] sc = {Ui.INK, nMiss > 0 ? Ui.RED : Ui.INK, Ui.GREEN, nFail > 0 ? Ui.RED : Ui.INK};
        for (int k = 0; k < 4; k++) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            col.addView(Ui.text(this, String.valueOf(sv[k]), 20, sc[k], true));
            col.addView(Ui.text(this, sl[k], 11, Ui.GRAY, false));
            stats.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }
        page.addView(stats, Ui.full(this, 12));
        if (nFail > 0) {
            Button retry = Ui.button(this, "못 올린 기록 " + nFail + "건 다시 올리기", false);
            retry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onResume();
                }
            });
            page.addView(retry, Ui.full(this, 8));
        }

        LinearLayout chips = Ui.row(this);
        String[] fk = {"all", "in", "out", "miss"};
        String[] fl = {"전체", "받은 전화", "건 전화", "부재중"};
        for (int k = 0; k < 4; k++) {
            final String key = fk[k];
            boolean on = key.equals(filter);
            Button b = Ui.button(this, fl[k], on);
            b.setTextSize(13);
            b.setMinHeight(Ui.dp(this, 36));
            b.setBackground(Ui.round(on ? Ui.INDIGO : Color.WHITE, on ? 0 : Color.parseColor("#D1D5DB"), 99, this));
            b.setPadding(Ui.dp(this, 12), 0, Ui.dp(this, 12), 0);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    filter = key;
                    render(false);
                }
            });
            chips.addView(b, wrapLeft(k == 0 ? 0 : 6));
        }
        page.addView(chips, Ui.full(this, 12));

        String day = "";
        LinearLayout group = null;
        int shown = 0;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !match(o)) continue;
            long t = startMs(o);
            String d = Fmt.ymd(t);
            if (!d.equals(day) || group == null) {
                day = d;
                TextView dh = Ui.text(this, dayLabel(t), 12, Ui.GRAY, true);
                dh.setPadding(Ui.dp(this, 4), 0, 0, 0);
                page.addView(dh, Ui.full(this, 14));
                group = plainCard();
                page.addView(group, Ui.full(this, 6));
            } else {
                group.addView(divider());
            }
            group.addView(callRow(o));
            shown++;
        }
        if (shown == 0) {
            page.addView(Ui.text(this, a.length() == 0 ? "아직 없어요. 강CRM 고객과 통화하면 여기에 남아요." : "이 조건에 맞는 통화가 없어요.", 14, Ui.GRAY, false), Ui.full(this, 18));
        }
    }

    private boolean match(JSONObject o) {
        String d = o.optString("direction");
        if ("in".equals(filter)) return "in".equals(d);
        if ("out".equals(filter)) return "out".equals(d) || "noanswer".equals(d);
        if ("miss".equals(filter)) return bad(o);
        return true;
    }

    private View callRow(final JSONObject o) {
        final String id = o.optString("id");
        String d = o.optString("direction");
        boolean bad = bad(o), in = "in".equals(d);
        LinearLayout row = Ui.row(this);
        row.setGravity(Gravity.TOP);
        row.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
        FrameLayout circ = new FrameLayout(this);
        circ.setBackground(Ui.round(Color.parseColor(bad ? "#FEF2F2" : (in ? "#ECFDF5" : "#EEF2FF")), 0, 18, this));
        ImageView ic = icon("missed".equals(d) ? R.drawable.ic_miss : (in ? R.drawable.ic_in : R.drawable.ic_out), bad ? Ui.RED : (in ? Ui.GREEN : Color.parseColor("#4338CA")), 18);
        circ.addView(ic, new FrameLayout.LayoutParams(Ui.dp(this, 18), Ui.dp(this, 18), Gravity.CENTER));
        row.addView(circ, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 36)));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        clp.leftMargin = Ui.dp(this, 12);
        row.addView(col, clp);

        LinearLayout l1 = Ui.row(this);
        l1.addView(Ui.text(this, o.optString("name", "고객"), 16, Ui.INK, true));
        String mgr = o.optString("mgr");
        if (!mgr.isEmpty()) l1.addView(Ui.text(this, "담당 " + Fmt.managerKey(mgr), 12, Ui.GRAY, false), wrapLeft(6));
        l1.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
        l1.addView(Ui.text(this, ampm(startMs(o)), 12, Ui.GRAY, false));
        col.addView(l1);

        LinearLayout l2 = Ui.row(this);
        l2.addView(Ui.text(this, dirLabel(o), 13, bad ? Ui.RED : Color.parseColor("#374151"), bad));
        JSONObject s = srv(id);
        String result = s != null && !s.optString("result", "").isEmpty() ? s.optString("result") : o.optString("result");
        String next = s != null && s.has("nextDate") ? s.optString("nextDate") : o.optString("nextDate");
        if (!result.isEmpty() && !bad) l2.addView(chip(result + (next.isEmpty() ? "" : " " + Fmt.md(next)), Color.parseColor("#3730A3"), Color.parseColor("#EEF2FF")), wrapLeft(6));
        col.addView(l2, Ui.full(this, 2));

        String st = "";
        int sc = Ui.GRAY;
        JSONObject lg = RecBackup.logOf(this, id);
        String ls = lg == null ? "" : lg.optString("state");
        if (!o.optBoolean("ok", true)) {
            st = "강CRM에 아직 못 올림 · 인터넷이 되면 올려요";
            sc = Ui.RED;
        } else if (recOk(id)) {
            String ai = aiTitle(id);
            st = "✓ 녹음 올림" + (ai.isEmpty() ? "" : " · " + ai);
            sc = Ui.GREEN;
        } else if ("find".equals(ls) || "wait".equals(ls) || "retry".equals(ls)) {
            st = "wait".equals(ls) ? "녹음 기다리는 중 · 와이파이가 되면 올려요" : "녹음 올리는 중";
            sc = AMBER;
        } else if ("nf".equals(ls)) {
            st = "녹음 파일을 못 찾았어요";
            sc = AMBER;
        } else if ("missed".equals(d)) {
            st = "강CRM 오늘 할 일에 콜백으로 들어가요";
            sc = AMBER;
        }
        if (!st.isEmpty()) {
            TextView t3 = Ui.text(this, st, 12, sc, false);
            t3.setMaxLines(1);
            t3.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(t3, Ui.full(this, 2));
        }
        row.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailId = id;
                render(false);
                loadFacts(o);
            }
        });
        return row;
    }

    // ═══ 📋 통화 한 건 ═══
    private JSONObject recentById(String id) {
        JSONArray a = Store.arr(this, "recent");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && id.equals(o.optString("id"))) return o;
        }
        return null;
    }

    /** 고객 폰 정보를 지금 기준으로 다시 (강CRM에서 · 10분 기억) */
    private void loadFacts(final JSONObject o) {
        final Context app = getApplicationContext();
        final String id = o.optString("id"), ph = o.optString("phone");
        if (ph.isEmpty()) return;
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject cu = CallFlow.lookup(app, ph);
                if (cu == null) return;
                List<Facts.Line> f = Facts.of(cu);
                synchronized (FACTS) {
                    FACTS.put(id, f);
                }
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        if (resumed && id.equals(detailId)) render(true);
                    }
                });
            }
        });
    }

    private void buildDetail(LinearLayout page) {
        final JSONObject o = recentById(detailId);
        LinearLayout top = Ui.row(this);
        LinearLayout back = new LinearLayout(this);
        back.setGravity(Gravity.CENTER);
        back.setContentDescription("통화 기록으로");
        back.addView(icon(R.drawable.ic_back, Color.parseColor("#374151"), 22));
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                detailId = null;
                render(false);
            }
        });
        top.addView(back, new LinearLayout.LayoutParams(Ui.dp(this, 44), Ui.dp(this, 44)));
        top.addView(Ui.text(this, "통화 한 건", 17, Ui.INK, true));
        page.addView(top);
        if (o == null) {
            page.addView(Ui.text(this, "이 통화를 찾지 못했어요.", 15, Ui.GRAY, false), Ui.full(this, 12));
            return;
        }
        final String id = o.optString("id"), phone = o.optString("phone"), cid = o.optString("customerId");
        JSONObject s = srv(id);
        boolean bad = bad(o), in = "in".equals(o.optString("direction"));

        LinearLayout c1 = Ui.card(this);
        LinearLayout nm = Ui.row(this);
        nm.addView(Ui.text(this, o.optString("name", "고객"), 24, Ui.INK, true));
        String mgr = o.optString("mgr"), status = o.optString("status");
        String sub = (mgr.isEmpty() ? "" : "담당 " + Fmt.managerKey(mgr)) + (status.isEmpty() ? "" : (mgr.isEmpty() ? "" : " · ") + status);
        if (!sub.isEmpty()) nm.addView(Ui.text(this, sub, 13, Ui.GRAY, false), wrapLeft(8));
        c1.addView(nm);
        String l3 = o.optString("line3");
        c1.addView(Ui.text(this, Fmt.phone(phone) + (l3.isEmpty() ? "" : " · " + l3), 14, Ui.GRAY, false), Ui.full(this, 2));
        LinearLayout dr = Ui.row(this);
        int dc = bad ? Ui.RED : (in ? Ui.GREEN : Color.parseColor("#4338CA"));
        dr.addView(icon("missed".equals(o.optString("direction")) ? R.drawable.ic_miss : (in ? R.drawable.ic_in : R.drawable.ic_out), dc, 16));
        dr.addView(Ui.text(this, dirLabel(o), 14, dc, true), wrapLeft(6));
        dr.addView(Ui.text(this, new SimpleDateFormat("M. d.(E) ", Locale.KOREA).format(new Date(startMs(o))) + ampm(startMs(o)), 13, Ui.GRAY, false), wrapLeft(8));
        c1.addView(dr, Ui.full(this, 8));
        page.addView(c1, Ui.full(this, 8));

        String result = s != null && !s.optString("result", "").isEmpty() ? s.optString("result") : o.optString("result");
        String memo = s != null && !s.optString("memo", "").isEmpty() ? s.optString("memo") : o.optString("memo");
        String next = s != null && s.has("nextDate") ? s.optString("nextDate") : o.optString("nextDate");
        String nk = s != null && s.has("nextKind") ? s.optString("nextKind") : o.optString("nextKind");
        if (!result.isEmpty() || !memo.isEmpty() || !next.isEmpty()) {
            LinearLayout c2 = Ui.card(this);
            c2.addView(Ui.text(this, "통화 결과", 12, Ui.GRAY, true));
            LinearLayout rr = Ui.row(this);
            if (!result.isEmpty()) {
                TextView b = chip(result, Color.parseColor("#3730A3"), Color.parseColor("#EEF2FF"));
                b.setTextSize(13);
                rr.addView(b);
            }
            if (!next.isEmpty()) rr.addView(Ui.text(this, "다음 " + ("visit".equals(nk) ? "방문 " : "연락 ") + Fmt.md(next), 13, Color.parseColor("#374151"), false), wrapLeft(result.isEmpty() ? 0 : 8));
            c2.addView(rr, Ui.full(this, 6));
            if (!memo.isEmpty()) c2.addView(Ui.text(this, memo, 14, Ui.INK, false), Ui.full(this, 6));
            page.addView(c2, Ui.full(this, 10));
        }

        List<Facts.Line> facts;
        synchronized (FACTS) {
            facts = FACTS.get(id);
        }
        if (facts == null) facts = Facts.fromJson(o.optString("facts"));
        if (!facts.isEmpty()) {
            LinearLayout c3 = Ui.card(this);
            c3.addView(Ui.text(this, "폰 정보", 12, Ui.GRAY, true));
            for (Facts.Line f : facts) {
                int col = f.tone == Facts.ALERT ? Ui.RED : (f.tone == Facts.WARN ? AMBER : Ui.INK);
                c3.addView(Ui.text(this, f.text, 14, col, f.tone != Facts.NORMAL), Ui.full(this, 4));
            }
            page.addView(c3, Ui.full(this, 10));
        }

        if (!bad) {
            LinearLayout c4 = Ui.card(this);
            JSONObject lg = RecBackup.logOf(this, id);
            if (recOk(id)) {
                long size = s != null && s.optLong("recSize", 0) > 0 ? s.optLong("recSize") : (lg == null ? 0 : lg.optLong("size", 0));
                c4.addView(Ui.text(this, "🎙 녹음 올림 · 대표님 드라이브" + (size > 0 ? String.format(Locale.US, " · %.1fMB", size / 1048576.0) : ""), 13, Ui.GREEN, true));
                String title = s == null ? "" : s.optString("aiTitle", "");
                JSONArray sum = s == null ? null : s.optJSONArray("aiSummary");
                if (!title.isEmpty()) c4.addView(Ui.text(this, title, 15, Ui.INK, true), Ui.full(this, 6));
                if (sum != null) for (int i = 0; i < Math.min(3, sum.length()); i++) c4.addView(Ui.text(this, "· " + sum.optString(i), 13, Color.parseColor("#374151"), false), Ui.full(this, 2));
                String nx = s == null ? "" : s.optString("aiNext", "");
                if (!nx.isEmpty()) c4.addView(Ui.text(this, "➡️ " + nx, 13, Ui.INK, false), Ui.full(this, 4));
                if (title.isEmpty() && sum == null) c4.addView(Ui.text(this, "AI 요약 · 대본은 강CRM 고객카드 → 연락 탭에서 봐요 (AI 키가 있는 폰에서 만들어져요)", 13, Ui.GRAY, false), Ui.full(this, 6));
            } else {
                String m = lg == null ? "녹음 없음 (통화 자동 녹음이 꺼져 있거나 아직 찾는 중)" : lg.optString("msg");
                c4.addView(Ui.text(this, m, 13, AMBER, false));
            }
            page.addView(c4, Ui.full(this, 10));
        }

        // 아래 고정 버튼 (다시 걸기 · 문자 · 강CRM 카드)
        LinearLayout bar = Ui.row(this);
        bar.setBackgroundColor(Ui.BG);
        bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        Button call = Ui.button(this, "다시 걸기", true);
        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + phone)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "전화 앱을 열 수 없어요", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Button sms = Ui.button(this, "문자", false);
        sms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:" + phone)));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "문자 앱을 열 수 없어요", Toast.LENGTH_SHORT).show();
                }
            }
        });
        Button crm = Ui.button(this, "강CRM 카드", false);
        crm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCrm(cid.isEmpty() ? phone : cid);
            }
        });
        bar.addView(call, Ui.weight(this, 0));
        bar.addView(sms, Ui.weight(this, 8));
        bar.addView(crm, Ui.weight(this, 8));
        content.addView(bar, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
    }

    /** 강CRM에서 이 고객카드 열기 (강CRM V224 · ?cust=고객번호) */
    static String crmUrl(Context c, String custId) {
        String h = Store.get(c, "href");
        if (h.isEmpty()) h = Store.get(c, "crmHref");
        if (h.isEmpty() || custId == null || custId.isEmpty()) return "";
        try {
            return h + (h.contains("?") ? "&" : "?") + "cust=" + URLEncoder.encode(custId, "UTF-8");
        } catch (Exception e) {
            return "";
        }
    }

    private void openCrm(String custId) {
        String u = crmUrl(this, custId);
        if (u.isEmpty()) {
            Toast.makeText(this, "강CRM 주소를 아직 몰라요 · 대표님 폰에서 강CRM(V224)을 한 번 열거나 [이 폰을 전화 앱과 연결]을 다시 눌러 주세요", Toast.LENGTH_LONG).show();
            fetchServer(true);
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(u)));
        } catch (Exception e) {
            Toast.makeText(this, "브라우저를 열 수 없어요", Toast.LENGTH_SHORT).show();
        }
    }

    // ═══ 🎙 녹음 ═══
    private void buildRec(LinearLayout page) {
        header(page, R.drawable.nv_mic, "통화 녹음 백업", null);
        page.addView(Ui.text(this, "강CRM 고객 통화 녹음만 골라 대표님 드라이브 '강CRM 녹음'에 올려요 · 지우지 않고 보관", 12, Ui.GRAY, false), Ui.full(this, 4));

        String st = Store.get(this, "recStatus");
        long stAt = Store.getLong(this, "recStatusAt");
        if (!st.isEmpty()) {
            boolean ok = st.startsWith("✅"), warn = st.startsWith("⚠️") || st.startsWith("⬜");
            TextView sv = Ui.text(this, (stAt > 0 ? Fmt.hm(stAt) + "  " : "") + st, 14, ok ? Color.parseColor("#065F46") : (warn ? Color.parseColor("#92400E") : Ui.INK), true);
            sv.setBackground(Ui.round(Color.parseColor(ok ? "#ECFDF5" : (warn ? "#FFFBEB" : "#FFFFFF")), Color.parseColor(ok ? "#A7F3D0" : (warn ? "#FDE68A" : "#E5E7EB")), 16, this));
            sv.setPadding(Ui.dp(this, 14), Ui.dp(this, 12), Ui.dp(this, 14), Ui.dp(this, 12));
            page.addView(sv, Ui.full(this, 12));
        }
        if (!RecBackup.canRead(this)) {
            LinearLayout pr = Ui.row(this);
            pr.addView(Ui.text(this, "녹음 파일 읽기 권한이 없어요", 14, Ui.RED, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            Button al = Ui.button(this, "허용", true);
            al.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    requestPermissions(new String[]{RecBackup.readPerm()}, 3);
                }
            });
            pr.addView(al);
            page.addView(pr, Ui.full(this, 10));
        }

        LinearLayout tg = plainCard();
        tg.setPadding(Ui.dp(this, 14), Ui.dp(this, 4), Ui.dp(this, 14), Ui.dp(this, 4));
        tg.addView(toggleRow("녹음 백업", "", RecBackup.on(this), new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Store.put(MainActivity.this, "recOn", on ? "1" : "0");
            }
        }));
        tg.addView(divider());
        tg.addView(toggleRow("와이파이에서만 올리기", "데이터로는 모아 두고 와이파이가 되면 올려요", RecBackup.wifiOnly(this), new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton b, boolean on) {
                Store.put(MainActivity.this, "recWifi", on ? "1" : "0");
                RecBackup.flush(getApplicationContext());
            }
        }));
        page.addView(tg, Ui.full(this, 10));

        int waiting = Store.arr(this, "recq").length();
        LinearLayout lh = Ui.row(this);
        lh.addView(Ui.text(this, "최근 녹음" + (waiting > 0 ? " · 기다리는 것 " + waiting + "건" : ""), 12, Ui.GRAY, true), new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (waiting > 0) {
            Button now = Ui.button(this, "지금 올리기", false);
            now.setTextSize(13);
            now.setMinHeight(Ui.dp(this, 36));
            now.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecBackup.flush(getApplicationContext());
                    Toast.makeText(MainActivity.this, "올리는 중이에요 · 잠시 뒤 다시 열어 보세요", Toast.LENGTH_SHORT).show();
                }
            });
            lh.addView(now);
        }
        page.addView(lh, Ui.full(this, 16));

        JSONArray logs = Store.arr(this, "recLog");
        if (logs.length() == 0) {
            page.addView(Ui.text(this, "아직 없어요. 강CRM 고객과 통화하면 녹음을 찾아서 올려요.", 14, Ui.GRAY, false), Ui.full(this, 8));
        } else {
            LinearLayout lc = plainCard();
            for (int i = 0; i < Math.min(20, logs.length()); i++) {
                JSONObject e = logs.optJSONObject(i);
                if (e == null) continue;
                if (i > 0) lc.addView(divider());
                LinearLayout r = Ui.row(this);
                r.setPadding(Ui.dp(this, 14), Ui.dp(this, 11), Ui.dp(this, 14), Ui.dp(this, 11));
                LinearLayout cl = new LinearLayout(this);
                cl.setOrientation(LinearLayout.VERTICAL);
                cl.addView(Ui.text(this, e.optString("name", "고객"), 15, Ui.INK, true));
                long t0 = e.optLong("t0", e.optLong("upd"));
                String dur = Fmt.dur(e.optLong("dur", 0));
                long size = e.optLong("size", 0);
                String sub = new SimpleDateFormat("M/d ", Locale.KOREA).format(new Date(t0)) + ampm(t0) + (dur.isEmpty() ? "" : " · " + dur) + (size > 0 ? String.format(Locale.US, " · %.1fMB", size / 1048576.0) : "");
                cl.addView(Ui.text(this, sub, 12, Ui.GRAY, false));
                r.addView(cl, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                String state = e.optString("state");
                String lab;
                int fg, bg;
                if ("ok".equals(state)) {
                    lab = "올림";
                    fg = Ui.GREEN;
                    bg = Color.parseColor("#ECFDF5");
                } else if ("find".equals(state) || "wait".equals(state) || "retry".equals(state)) {
                    lab = "기다리는 중";
                    fg = Color.parseColor("#92400E");
                    bg = Color.parseColor("#FFFBEB");
                } else if ("nf".equals(state)) {
                    lab = "못 찾음";
                    fg = Ui.RED;
                    bg = Color.parseColor("#FEF2F2");
                } else {
                    lab = "못 올림";
                    fg = Ui.RED;
                    bg = Color.parseColor("#FEF2F2");
                }
                TextView ch = chip(lab, fg, bg);
                ch.setTextSize(12);
                r.addView(ch);
                lc.addView(r);
            }
            page.addView(lc, Ui.full(this, 6));
        }
        if (!recFind.isEmpty()) page.addView(Ui.text(this, recFind, 13, recFind.startsWith("✅") ? Ui.GREEN : AMBER, false), Ui.full(this, 10));

        LinearLayout btns = Ui.row(this);
        Button findBtn = Ui.button(this, "최근 녹음 파일 보기", false);
        findBtn.setTextSize(14);
        findBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkRecordings();
            }
        });
        Button callSet = Ui.button(this, "전화 설정 열기", false);
        callSet.setTextSize(14);
        callSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent("android.telecom.action.SHOW_CALL_SETTINGS"));
                    Toast.makeText(MainActivity.this, "'통화 녹음' → '통화 자동 녹음' 켜기 → '모든 통화'", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "전화 앱 → ⋮ → 설정 → 통화 녹음에서 켜 주세요", Toast.LENGTH_LONG).show();
                }
            }
        });
        btns.addView(findBtn, Ui.weight(this, 0));
        btns.addView(callSet, Ui.weight(this, 8));
        page.addView(btns, Ui.full(this, 14));
        page.addView(Ui.text(this, "에이닷 녹음도 이름에 번호가 있으면 자동으로 찾아요. 안 되면 에이닷 녹음 화면 [공유] → '강CRM 전화'.", 12, Ui.GRAY, false), Ui.full(this, 10));
    }

    private View toggleRow(String title, String sub, boolean on, CompoundButton.OnCheckedChangeListener l) {
        LinearLayout r = Ui.row(this);
        r.setMinimumHeight(Ui.dp(this, 52));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(Ui.text(this, title, 15, Ui.INK, true));
        if (!sub.isEmpty()) tx.addView(Ui.text(this, sub, 12, Ui.GRAY, false));
        r.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        Switch sw = new Switch(this);
        sw.setChecked(on);
        sw.setContentDescription(title);
        sw.setOnCheckedChangeListener(l);
        r.addView(sw);
        return r;
    }

    /** 최근 3일 녹음 파일 (녹음 앱이 어디에 저장하는지 확인용) */
    private void checkRecordings() {
        if (!RecBackup.canRead(this)) {
            requestPermissions(new String[]{RecBackup.readPerm()}, 3);
            return;
        }
        final Context app = getApplicationContext();
        recFind = "찾는 중…";
        render(true);
        RecBackup.REC_EX.execute(new Runnable() {
            @Override
            public void run() {
                final java.util.List<RecBackup.Found> all = RecBackup.recentAudio(app, 3, 15);
                int calls = 0;
                final StringBuilder b = new StringBuilder();
                for (RecBackup.Found f : all) {
                    if (f.score > 0) calls++;
                    b.append(f.score > 0 ? "✅ " : "⬜ ").append(Fmt.hm(f.added * 1000L)).append(" · ").append(f.path.isEmpty() ? "(폴더 모름)" : f.path)
                            .append("\n     ").append(f.name).append(String.format(Locale.US, " · %.1fMB", f.size / 1048576.0)).append("\n");
                }
                final String m = all.isEmpty()
                        ? "⚠️ 최근 3일 녹음 파일이 이 앱에서 하나도 안 보여요. 녹음 앱(에이닷 등)이 자기 앱 안에만 저장하는 거예요 → 녹음 화면의 [공유] → '강CRM 전화'로 붙여 주세요."
                        : (calls > 0 ? "✅ 통화 녹음으로 보이는 파일 " + calls + "개 · 자동으로 올려요" : "⚠️ 오디오 파일은 있는데 통화 녹음으로 보이는 게 없어요 · 이 화면을 캡처해서 보내 주시면 그 폴더도 찾게 고쳐요");
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        recFind = m;
                        if (resumed) render(true);
                        if (!all.isEmpty()) {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("최근 3일 녹음 파일 (✅ = 통화 녹음으로 찾는 것)")
                                    .setMessage(m + "\n\n" + b)
                                    .setPositiveButton("확인", null)
                                    .show();
                        }
                    }
                });
            }
        });
    }

    // ═══ ⚙️ 설정 ═══
    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void buildSet(LinearLayout page) {
        header(page, 0, "설정", Ui.text(this, "강CRM 전화 v" + CallFlow.appVer(this), 12, Ui.GRAY, false));

        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "강CRM 연결", 15, Ui.INK, true));
        TextView pairText;
        if (Store.paired(this)) {
            String staff = Store.get(this, "staff");
            pairText = Ui.text(this, "연결된 계정: " + Store.get(this, "email") + (staff.isEmpty() ? "" : " (" + staff + ")") + (checkMsg.isEmpty() ? "" : "\n" + checkMsg), 13, checkMsg.startsWith("❌") ? Ui.RED : Ui.GREEN, false);
        } else {
            pairText = Ui.text(this, (checkMsg.isEmpty() ? "" : checkMsg + "\n") + "아직 연결 안 됐어요.\n이 폰의 크롬에서 강CRM을 열고 → 설정 → 🔌 연결 → 📞 강CRM 전화 앱 → [이 폰을 전화 앱과 연결]을 누르세요.", 13, checkMsg.startsWith("❌") ? Ui.RED : Ui.GRAY, false);
        }
        c1.addView(pairText, Ui.full(this, 6));
        LinearLayout r1 = Ui.row(this);
        Button chk = Ui.button(this, "연결 확인", false);
        chk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Store.paired(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "먼저 강CRM에서 [이 폰을 전화 앱과 연결]을 눌러 주세요", Toast.LENGTH_LONG).show();
                    return;
                }
                checkMsg = "연결 확인 중…";
                render(true);
                check();
            }
        });
        Button off = Ui.button(this, "연결 끊기", false);
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage("이 폰과 강CRM 연결을 끊을까요?\n전화가 와도 고객 카드가 안 떠요.")
                        .setPositiveButton("끊기", (d, w) -> {
                            Store.unpair(MainActivity.this);
                            checkMsg = "";
                            render(true);
                        })
                        .setNegativeButton("취소", null)
                        .show();
            }
        });
        r1.addView(chk, Ui.weight(this, 0));
        r1.addView(off, Ui.weight(this, 8));
        c1.addView(r1, Ui.full(this, 10));
        page.addView(c1, Ui.full(this, 12));

        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "권한", 15, Ui.INK, true));
        boolean phone = has(Manifest.permission.READ_PHONE_STATE) && has(Manifest.permission.READ_CALL_LOG);
        addPerm(c2, "전화 · 통화 기록 (필수)", phone, new Runnable() {
            @Override
            public void run() {
                requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG}, 1);
            }
        });
        addPerm(c2, "다른 앱 위에 표시 (필수 · 고객 카드)", Settings.canDrawOverlays(this), new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            }
        });
        if (Build.VERSION.SDK_INT >= 33) {
            addPerm(c2, "알림 (결과 남기기 · 부재중)", has(Manifest.permission.POST_NOTIFICATIONS), new Runnable() {
                @Override
                public void run() {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
                }
            });
        }
        addPerm(c2, "녹음 파일 읽기 (통화 녹음 백업)", RecBackup.canRead(this), new Runnable() {
            @Override
            public void run() {
                requestPermissions(new String[]{RecBackup.readPerm()}, 3);
            }
        });
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean batt = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        addPerm(c2, "배터리 절전 예외 (권장)", batt, new Runnable() {
            @Override
            public void run() {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            }
        });
        c2.addView(Ui.text(this, "삼성 폰: 설정 → 배터리 → 백그라운드 사용 제한 → '절전 예외 앱'에 강CRM 전화를 넣어 두면 더 잘 떠요.", 12, Ui.GRAY, false), Ui.full(this, 8));
        page.addView(c2, Ui.full(this, 10));

        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "시험해 보기", 15, Ui.INK, true));
        c3.addView(Ui.text(this, "강CRM에 있는 고객 번호를 넣고 [카드 띄우기] → 전화 올 때 뜨는 카드가 8초 동안 보여요.", 12, Ui.GRAY, false), Ui.full(this, 4));
        String prev = testNum == null ? "" : testNum.getText().toString();
        testNum = new EditText(this);
        testNum.setHint("010-0000-0000");
        testNum.setText(prev);
        testNum.setInputType(InputType.TYPE_CLASS_PHONE);
        testNum.setTextSize(16);
        testNum.setBackground(Ui.round(Color.WHITE, Color.parseColor("#D1D5DB"), 12, this));
        int tp = Ui.dp(this, 12);
        testNum.setPadding(tp, tp, tp, tp);
        c3.addView(testNum, Ui.full(this, 8));
        LinearLayout r3 = Ui.row(this);
        Button pop = Ui.button(this, "카드 띄우기", true);
        pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testPopup(false);
            }
        });
        Button res = Ui.button(this, "결과 창 보기", false);
        res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testPopup(true);
            }
        });
        r3.addView(pop, Ui.weight(this, 0));
        r3.addView(res, Ui.weight(this, 8));
        c3.addView(r3, Ui.full(this, 8));
        page.addView(c3, Ui.full(this, 10));
    }

    private void addPerm(LinearLayout box, String label, boolean ok, final Runnable ask) {
        LinearLayout r = Ui.row(this);
        r.setMinimumHeight(Ui.dp(this, 36));
        if (ok) r.addView(icon(R.drawable.ic_check, Ui.GREEN, 18));
        TextView t = Ui.text(this, (ok ? "" : "⬜ ") + label, 14, ok ? Ui.INK : Ui.RED, !ok);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tl.leftMargin = Ui.dp(this, ok ? 8 : 0);
        r.addView(t, tl);
        if (!ok) {
            Button b = Ui.button(this, "허용", true);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ask.run();
                }
            });
            r.addView(b);
        }
        box.addView(r, Ui.full(this, 4));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        render(true);
    }

    private void testPopup(final boolean resultScreen) {
        final Context app = getApplicationContext();
        final String num = Fmt.digits(testNum.getText().toString());
        if (!Store.paired(app)) {
            Toast.makeText(this, "먼저 강CRM과 연결해 주세요", Toast.LENGTH_LONG).show();
            return;
        }
        if (num.length() < 9) {
            Toast.makeText(this, "번호를 넣어 주세요", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!resultScreen && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'다른 앱 위에 표시'를 먼저 허용해 주세요", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "강CRM에서 찾는 중…", Toast.LENGTH_SHORT).show();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                String err = "";
                JSONObject cu = null;
                try {
                    cu = Api.findCustomer(app, num);
                } catch (Api.ApiError e) {
                    err = "❌ " + e.code + " " + e.getMessage();
                } catch (Exception e) {
                    err = "❌ 인터넷을 확인해 주세요";
                }
                final JSONObject fc = cu;
                final String fe = err;
                JSONObject log = null;
                if (fc != null && resultScreen) {
                    try {
                        log = CallFlow.baseLog(app, new Cust(fc), num, "in", System.currentTimeMillis() - 95000L, 95);
                        log.put("_last", LastCall.fetch(app, fc.optString("id"), null));
                    } catch (Exception ignore) {
                        log = null;
                    }
                }
                final JSONObject fl = log;
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!fe.isEmpty()) {
                            Toast.makeText(app, fe, Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (fc == null) {
                            Toast.makeText(app, "강CRM 고객이 아니에요 (이런 번호는 카드가 안 떠요)", Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (resultScreen && fl != null) {
                            startActivity(new Intent(MainActivity.this, ResultActivity.class).putExtra("log", fl.toString()).putExtra("test", true));
                        } else {
                            Overlay.show(app, new Cust(fc), num, "시험", 8000);
                            CallFlow.EX.execute(new Runnable() {   // 🕘 지난 통화도
                                @Override
                                public void run() {
                                    String id = fc.optString("id");
                                    Overlay.setLast(id, LastCall.fetch(app, id, null));
                                }
                            });
                        }
                    }
                });
            }
        });
    }
}
