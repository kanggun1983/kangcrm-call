package kr.kangcrm.call;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 전화 받는 화면 위에 뜨는 강CRM 고객 카드 (끌어서 옮기기 · ✕로 닫기) */
final class Overlay {
    private Overlay() {}

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static View shown;
    private static WindowManager shownWm;
    private static Runnable autoHide;
    private static TextView lastView;   // 🕘 v3 지난 통화 (나중에 채움)
    private static String shownId = "";

    static boolean can(Context c) {
        return Settings.canDrawOverlays(c);
    }

    static void show(final Context ctx, final Cust cu, final String number, final String kind, final long autoHideMs) {
        final Context c = ctx.getApplicationContext();
        H.post(new Runnable() {
            @Override
            public void run() {
                try {
                    showNow(c, cu, number, kind, autoHideMs);
                } catch (Throwable t) {
                    Log.w("KC", "overlay", t);
                }
            }
        });
    }

    static void hide() {
        H.post(new Runnable() {
            @Override
            public void run() {
                hideNow();
            }
        });
    }

    private static void hideNow() {
        if (autoHide != null) {
            H.removeCallbacks(autoHide);
            autoHide = null;
        }
        if (shown != null && shownWm != null) {
            try {
                shownWm.removeView(shown);
            } catch (Throwable ignore) {
                // 이미 사라짐
            }
        }
        shown = null;
        shownWm = null;
        lastView = null;
        shownId = "";
    }

    /** 🕘 지난 통화 한 줄을 지금 떠 있는 카드에 (같은 고객일 때만) */
    static void setLast(final String custId, final String text) {
        H.post(new Runnable() {
            @Override
            public void run() {
                if (lastView == null || text == null || text.isEmpty() || !custId.equals(shownId)) return;
                lastView.setText(text);
                lastView.setVisibility(View.VISIBLE);
            }
        });
    }

    static int toneColor(int tone) {
        return tone == Facts.ALERT ? Color.parseColor("#FCA5A5") : (tone == Facts.WARN ? Color.parseColor("#FDE68A") : Color.parseColor("#E0E7FF"));
    }

    private static void showNow(final Context c, Cust cu, String number, String kind, long autoHideMs) {
        if (!can(c)) return;
        hideNow();
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        final FrameLayout root = new FrameLayout(c);
        int side = Ui.dp(c, 12);
        root.setPadding(side, 0, side, 0);

        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.round(Color.parseColor("#1E1B4B"), Color.parseColor("#4338CA"), 20, c));
        int p = Ui.dp(c, 16);
        card.setPadding(p, Ui.dp(c, 12), p, p);
        card.setElevation(Ui.dp(c, 8));

        LinearLayout head = Ui.row(c);
        TextView tag = Ui.text(c, "📞 강CRM 고객 · " + kind, 13, Color.parseColor("#C7D2FE"), true);
        head.addView(tag, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = Ui.text(c, "✕", 20, Color.parseColor("#C7D2FE"), true);
        close.setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 4), 0);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideNow();
            }
        });
        head.addView(close);
        card.addView(head);

        TextView name = Ui.text(c, cu.name(), 24, Color.WHITE, true);
        name.setPadding(0, Ui.dp(c, 4), 0, 0);
        card.addView(name);
        String l2 = cu.line2();
        if (!l2.isEmpty()) card.addView(Ui.text(c, l2, 15, Color.parseColor("#E0E7FF"), true));
        String l3 = cu.line3();
        if (!l3.isEmpty()) card.addView(Ui.text(c, l3, 14, Color.parseColor("#C7D2FE"), false));
        for (Facts.Line f : Facts.of(cu.d)) {   // 📋 v3 개통 · 할부 · 약정 · 기변 시기 · 생일 · 미비서류
            TextView ft = Ui.text(c, f.text, 13, toneColor(f.tone), f.tone != Facts.NORMAL);
            ft.setPadding(0, Ui.dp(c, 1), 0, 0);
            card.addView(ft);
        }
        String l4 = cu.line4();
        if (!l4.isEmpty()) card.addView(Ui.text(c, l4, 14, Color.parseColor("#FDE68A"), false));
        TextView last = Ui.text(c, "", 13, Color.parseColor("#E0E7FF"), false);
        last.setMaxLines(3);
        last.setBackground(Ui.round(Color.parseColor("#27235E"), 0, 10, c));
        last.setPadding(Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6));
        last.setVisibility(View.GONE);
        card.addView(last, Ui.full(c, 6));
        String memo = cu.memo();
        if (!memo.isEmpty()) {
            TextView m = Ui.text(c, "📝 " + memo, 14, Color.WHITE, false);
            m.setMaxLines(2);
            m.setBackground(Ui.round(Color.parseColor("#312E81"), 0, 10, c));
            m.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
            LinearLayout.LayoutParams mlp = Ui.full(c, 8);
            card.addView(m, mlp);
        }
        root.addView(card, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        long savedY = Store.getLong(c, "ovY");
        lp.y = savedY > 0 ? (int) savedY : Ui.dp(c, 150);

        card.setOnTouchListener(new View.OnTouchListener() {
            float downY;
            int startY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = e.getRawY();
                        startY = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.y = Math.max(0, startY + Math.round(e.getRawY() - downY));
                        try {
                            wm.updateViewLayout(root, lp);
                        } catch (Throwable ignore) {
                            // 닫힘
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Store.putLong(c, "ovY", lp.y);
                        return true;
                    default:
                        return false;
                }
            }
        });

        wm.addView(root, lp);
        shown = root;
        shownWm = wm;
        lastView = last;
        shownId = cu.id();
        if (autoHideMs > 0) {
            autoHide = new Runnable() {
                @Override
                public void run() {
                    hideNow();
                }
            };
            H.postDelayed(autoHide, autoHideMs);
        }
    }
}
