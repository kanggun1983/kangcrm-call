package kr.kangcrm.call;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/** 글자 모양 맞추기 (번호 · 시간 · 직원 이름) */
final class Fmt {
    private Fmt() {}

    /** 숫자만 · +82 10… → 010… */
    static String digits(String s) {
        if (s == null) return "";
        StringBuilder b = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= '0' && ch <= '9') b.append(ch);
        }
        String d = b.toString();
        if (d.startsWith("82") && d.length() >= 11) d = "0" + d.substring(2);
        return d;
    }

    /** 01012345678 → 010-1234-5678 (강CRM 번호 칸 모양) */
    static String phone(String d) {
        if (d == null) return "";
        if (d.length() == 11) return d.substring(0, 3) + "-" + d.substring(3, 7) + "-" + d.substring(7);
        if (d.length() == 10 && d.startsWith("02")) return d.substring(0, 2) + "-" + d.substring(2, 6) + "-" + d.substring(6);
        if (d.length() == 10) return d.substring(0, 3) + "-" + d.substring(3, 6) + "-" + d.substring(6);
        if (d.length() == 9 && d.startsWith("02")) return d.substring(0, 2) + "-" + d.substring(2, 5) + "-" + d.substring(5);
        return d;
    }

    private static final String TITLE_RE = "\\s*(과장|대리|사원|주임|팀장|점장|실장|부장|차장|매니저|선임|책임|대표|님)$";

    static String managerKey(String n) {
        String v = n == null ? "" : n.trim().replaceAll("\\s+", " ");
        String prev;
        do {
            prev = v;
            v = v.replaceAll(TITLE_RE, "").trim();
        } while (!v.equals(prev));
        return v;
    }

    /** '임호규'와 '호규 과장'은 같은 사람 (강CRM과 같은 규칙) */
    static boolean sameStaff(String a, String b) {
        String x = managerKey(a).replace(" ", "");
        String y = managerKey(b).replace(" ", "");
        if (x.isEmpty() || y.isEmpty()) return false;
        return x.equals(y) || (x.length() >= 2 && y.length() >= 2 && (x.endsWith(y) || y.endsWith(x)));
    }

    static String iso(long ms) {
        SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'", Locale.US);
        f.setTimeZone(TimeZone.getTimeZone("UTC"));
        return f.format(new Date(ms));
    }

    static String ymd(long ms) {
        return new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(new Date(ms));
    }

    static String hm(long ms) {
        return new SimpleDateFormat("M/d HH:mm", Locale.US).format(new Date(ms));
    }

    static String dur(long sec) {
        if (sec <= 0) return "";
        if (sec < 60) return sec + "초";
        return (sec / 60) + "분 " + (sec % 60) + "초";
    }

    /** 2026-10-25 → 10/25 */
    static String md(String ymd) {
        if (ymd == null || ymd.length() < 10) return ymd == null ? "" : ymd;
        try {
            return Integer.parseInt(ymd.substring(5, 7)) + "/" + Integer.parseInt(ymd.substring(8, 10));
        } catch (Exception e) {
            return ymd;
        }
    }

    static String newId() {
        String t = Long.toString(System.currentTimeMillis(), 36);
        String r = Long.toString((long) (Math.random() * 2176782336L), 36);
        return "c" + t + r;
    }
}
