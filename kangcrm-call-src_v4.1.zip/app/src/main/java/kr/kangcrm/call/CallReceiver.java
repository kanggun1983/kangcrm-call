package kr.kangcrm.call;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.telephony.TelephonyManager;
import android.util.Log;

/** 전화 상태가 바뀔 때 (폰이 알려줌) → 통화 확인 서비스로 넘김 */
public class CallReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context ctx, Intent in) {
        if (in == null || !TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(in.getAction())) return;
        if (!Store.paired(ctx)) return;
        String state = in.getStringExtra(TelephonyManager.EXTRA_STATE);
        if (state == null) return;
        @SuppressWarnings("deprecation")
        String num = in.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);
        final String n = num == null ? "" : num;
        Intent s = new Intent(ctx, CallService.class).putExtra("state", state).putExtra("num", n);
        try {
            ctx.startForegroundService(s);
        } catch (Throwable t) {
            // 폰이 서비스를 막으면 여기서 바로 (최대 10초)
            Log.w("KC", "service blocked", t);
            final PendingResult pr = goAsync();
            CallFlow.onState(ctx.getApplicationContext(), state, n, new Runnable() {
                @Override
                public void run() {
                    try {
                        pr.finish();
                    } catch (Throwable ignore) {
                        // 이미 끝남
                    }
                }
            });
        }
    }
}
