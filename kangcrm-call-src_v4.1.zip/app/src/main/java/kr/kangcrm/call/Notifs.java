package kr.kangcrm.call;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;

/** 알림 (통화 확인 중 · 결과 남기기 · 부재중) */
final class Notifs {
    private Notifs() {}

    static final int ID_RUN = 1, ID_RESULT = 2, ID_MISSED = 3;

    static NotificationManager nm(Context c) {
        return (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    static void ensure(Context c) {
        NotificationManager n = nm(c);
        if (n == null) return;
        if (n.getNotificationChannel("run") == null) {
            NotificationChannel a = new NotificationChannel("run", "통화 확인 중", NotificationManager.IMPORTANCE_MIN);
            a.setShowBadge(false);
            n.createNotificationChannel(a);
        }
        if (n.getNotificationChannel("call") == null) {
            NotificationChannel b = new NotificationChannel("call", "통화 결과 · 부재중", NotificationManager.IMPORTANCE_HIGH);
            n.createNotificationChannel(b);
        }
    }

    static Notification running(Context c) {
        ensure(c);
        return new Notification.Builder(c, "run")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("강CRM 전화")
                .setContentText("통화를 확인하고 있어요")
                .setOngoing(true)
                .build();
    }

    static void result(Context c, JSONObject log) {
        ensure(c);
        NotificationManager n = nm(c);
        if (n == null) return;
        Intent i = new Intent(c, ResultActivity.class)
                .putExtra("log", log.toString())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, ID_RESULT, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification nf = new Notification.Builder(c, "call")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("📞 통화 결과 남기기 · " + log.optString("customerName"))
                .setContentText("눌러서 결과 · 메모 · 다음 약속을 남겨요")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        n.notify(ID_RESULT, nf);
    }

    static void cancelResult(Context c) {
        NotificationManager n = nm(c);
        if (n != null) n.cancel(ID_RESULT);
    }

    static void missed(Context c, JSONObject log) {
        ensure(c);
        NotificationManager n = nm(c);
        if (n == null) return;
        Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + log.optString("phone")))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, ID_MISSED, dial, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean noAnswer = "noanswer".equals(log.optString("direction"));
        Notification nf = new Notification.Builder(c, "call")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle((noAnswer ? "📞 안 받음 · " : "📵 부재중 · ") + log.optString("customerName"))
                .setContentText("강CRM 연락 기록에 남겼어요 · 누르면 다시 걸기")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        n.notify(ID_MISSED, nf);
    }
}
