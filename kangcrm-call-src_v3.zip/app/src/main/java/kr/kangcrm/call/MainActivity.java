package kr.kangcrm.call;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.InputType;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.charset.StandardCharsets;

/** 첫 화면: 강CRM 연결 · 권한 · 시험 · 최근 통화 */
public class MainActivity extends Activity {
    private TextView pairText;
    private LinearLayout permBox, recentBox;
    private TextView recText;
    private Button recOnBtn, recWifiBtn;
    private String recFind = "";
    private EditText testNum;
    private String checkMsg = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        handlePair(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handlePair(intent);
        refresh();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
        final Context app = getApplicationContext();
        if (Store.paired(app)) RecBackup.flush(app);
        if (Store.paired(app) && Store.arr(app, "queue").length() > 0) {
            CallFlow.EX.execute(new Runnable() {
                @Override
                public void run() {
                    final int n = CallFlow.flushQueue(app);
                    if (n > 0) CallFlow.H.post(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(app, "못 올린 통화 기록 " + n + "건을 올렸어요", Toast.LENGTH_SHORT).show();
                            refresh();
                        }
                    });
                }
            });
        }
    }

    // ── 강CRM(크롬)의 [이 폰을 전화 앱과 연결] → kangcrmcall://pair?d=… ──
    private void handlePair(Intent i) {
        if (i == null || i.getData() == null) return;
        Uri u = i.getData();
        if (!"kangcrmcall".equals(u.getScheme()) || !"pair".equals(u.getHost())) return;
        try {
            String d = u.getQueryParameter("d");
            if (d == null) throw new IllegalArgumentException("no data");
            byte[] raw = Base64.decode(d, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING);
            JSONObject j = new JSONObject(new String(raw, StandardCharsets.UTF_8));
            String rt = j.optString("rt"), key = j.optString("key"), pid = j.optString("pid");
            if (rt.isEmpty() || key.isEmpty() || pid.isEmpty()) throw new IllegalArgumentException("missing");
            Store.unpair(this);
            Store.put(this, "rt", rt);
            Store.put(this, "key", key);
            Store.put(this, "pid", pid);
            Store.put(this, "origin", j.optString("origin"));
            Store.put(this, "email", j.optString("email"));
            Store.put(this, "staff", j.optString("staff"));
            Store.put(this, "st", "IDLE");
            i.setData(null);
            checkMsg = "연결 확인 중…";
            check();
        } catch (Exception e) {
            checkMsg = "❌ 연결 정보를 읽지 못했어요. 강CRM에서 다시 눌러 주세요.";
        }
    }

    /** 로그인 표 받기 + 직원 목록 읽기로 연결 확인 */
    private void check() {
        final Context app = getApplicationContext();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                String msg;
                try {
                    Api.idToken(app, true);
                    Store.putLong(app, "sbeAt", 0);
                    JSONObject m = Api.staffByEmail(app);
                    msg = "✅ 강CRM과 연결됐어요" + (m.length() > 0 ? " (직원 " + m.length() + "명)" : "");
                } catch (Api.ApiError e) {
                    msg = e.code == 400 || e.code == 401 || e.code == 403
                            ? "❌ 로그인이 만료됐거나 권한이 없어요. 강CRM에서 [이 폰을 전화 앱과 연결]을 다시 눌러 주세요. (" + e.code + ")"
                            : "❌ 연결 확인 실패: " + e.getMessage();
                } catch (Exception e) {
                    msg = "❌ 인터넷을 확인해 주세요 (" + e.getClass().getSimpleName() + ")";
                }
                final String fm = msg;
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        checkMsg = fm;
                        refresh();
                    }
                });
            }
        });
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, Ui.dp(this, 20), p, Ui.dp(this, 32));
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        box.addView(Ui.text(this, "📞 강CRM 전화", 24, Ui.INK, true));
        box.addView(Ui.text(this, "전화가 오면 강CRM 고객인지 바로 띄우고, 끊으면 결과·메모를 강CRM에 남겨요. v" + CallFlow.appVer(this), 14, Ui.GRAY, false));

        // ① 연결
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "① 강CRM 연결", 16, Ui.INK, true));
        pairText = Ui.text(this, "", 14, Ui.GRAY, false);
        c1.addView(pairText, Ui.full(this, 6));
        LinearLayout r1 = Ui.row(this);
        Button chk = Ui.button(this, "연결 확인", false);
        chk.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Store.paired(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "먼저 강CRM에서 [이 폰을 전화 앱과 연결]을 눌러 주세요", Toast.LENGTH_LONG).show();
                    return;
                }
                checkMsg = "연결 확인 중…";
                refresh();
                check();
            }
        });
        Button off = Ui.button(this, "연결 끊기", false);
        off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new AlertDialog.Builder(MainActivity.this)
                        .setMessage("이 폰과 강CRM 연결을 끊을까요?\n전화가 와도 고객 카드가 안 떠요.")
                        .setPositiveButton("끊기", (d, w) -> {
                            Store.unpair(MainActivity.this);
                            checkMsg = "";
                            refresh();
                        })
                        .setNegativeButton("취소", null)
                        .show();
            }
        });
        r1.addView(chk, Ui.weight(this, 0));
        r1.addView(off, Ui.weight(this, 8));
        c1.addView(r1, Ui.full(this, 10));
        box.addView(c1, Ui.full(this, 14));

        // ② 권한
        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "② 권한 (처음 한 번)", 16, Ui.INK, true));
        permBox = new LinearLayout(this);
        permBox.setOrientation(LinearLayout.VERTICAL);
        c2.addView(permBox);
        c2.addView(Ui.text(this, "삼성 폰: 설정 → 배터리 → 백그라운드 사용 제한 → '절전 예외 앱'에 강CRM 전화를 넣어 두면 더 잘 떠요.", 13, Ui.GRAY, false), Ui.full(this, 10));
        box.addView(c2, Ui.full(this, 12));

        // 🎙 통화 녹음 백업 (v2)
        LinearLayout cr = Ui.card(this);
        cr.addView(Ui.text(this, "🎙 통화 녹음 백업", 16, Ui.INK, true));
        cr.addView(Ui.text(this, "통화 녹음 파일을 강CRM 고객 통화만 골라 대표님 구글 드라이브 '강CRM 녹음' 폴더에 올려요. 강CRM 고객카드에서 ▶ 듣기 · 🤖 AI 요약 · 대본. (지우지 않고 계속 보관)\n에이닷처럼 파일이 안 보이는 녹음 앱은 녹음 화면의 [공유] → '강CRM 전화'를 누르면 그 통화에 붙어요.", 13, Ui.GRAY, false), Ui.full(this, 4));
        recText = Ui.text(this, "", 14, Ui.INK, false);
        cr.addView(recText, Ui.full(this, 8));
        LinearLayout rr = Ui.row(this);
        recOnBtn = Ui.button(this, "", false);
        recOnBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Store.put(MainActivity.this, "recOn", RecBackup.on(MainActivity.this) ? "0" : "1");
                refresh();
            }
        });
        recWifiBtn = Ui.button(this, "", false);
        recWifiBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Store.put(MainActivity.this, "recWifi", RecBackup.wifiOnly(MainActivity.this) ? "0" : "1");
                refresh();
                RecBackup.flush(getApplicationContext());
            }
        });
        rr.addView(recOnBtn, Ui.weight(this, 0));
        rr.addView(recWifiBtn, Ui.weight(this, 8));
        cr.addView(rr, Ui.full(this, 8));
        LinearLayout rr2 = Ui.row(this);
        Button findBtn = Ui.button(this, "최근 녹음 파일 보기", false);
        findBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                checkRecordings();
            }
        });
        Button callSet = Ui.button(this, "전화 설정 열기", false);
        callSet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent("android.telecom.action.SHOW_CALL_SETTINGS"));
                    Toast.makeText(MainActivity.this, "'통화 녹음' → '통화 자동 녹음' 켜기 → '모든 통화'", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "전화 앱 → ⋮ → 설정 → 통화 녹음에서 켜 주세요", Toast.LENGTH_LONG).show();
                }
            }
        });
        rr2.addView(findBtn, Ui.weight(this, 0));
        rr2.addView(callSet, Ui.weight(this, 8));
        cr.addView(rr2, Ui.full(this, 8));
        box.addView(cr, Ui.full(this, 12));

        // ③ 시험
        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "③ 시험해 보기", 16, Ui.INK, true));
        c3.addView(Ui.text(this, "강CRM에 있는 고객 번호를 넣고 [카드 띄우기] → 전화 올 때 뜨는 카드가 8초 동안 보여요.", 13, Ui.GRAY, false), Ui.full(this, 4));
        testNum = new EditText(this);
        testNum.setHint("010-0000-0000");
        testNum.setInputType(InputType.TYPE_CLASS_PHONE);
        testNum.setTextSize(17);
        testNum.setBackground(Ui.round(Color.WHITE, Color.parseColor("#D1D5DB"), 12, this));
        int tp = Ui.dp(this, 12);
        testNum.setPadding(tp, tp, tp, tp);
        c3.addView(testNum, Ui.full(this, 8));
        LinearLayout r3 = Ui.row(this);
        Button pop = Ui.button(this, "카드 띄우기", true);
        pop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testPopup(false);
            }
        });
        Button res = Ui.button(this, "결과 창 보기", false);
        res.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                testPopup(true);
            }
        });
        r3.addView(pop, Ui.weight(this, 0));
        r3.addView(res, Ui.weight(this, 8));
        c3.addView(r3, Ui.full(this, 8));
        box.addView(c3, Ui.full(this, 12));

        // ④ 최근 통화
        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, "④ 최근 강CRM 고객 통화 (이 폰)", 16, Ui.INK, true));
        recentBox = new LinearLayout(this);
        recentBox.setOrientation(LinearLayout.VERTICAL);
        c4.addView(recentBox);
        box.addView(c4, Ui.full(this, 12));

        setContentView(sv);
        refresh();
    }

    private boolean has(String perm) {
        return checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED;
    }

    private void refresh() {
        if (pairText == null) return;
        if (Store.paired(this)) {
            String staff = Store.get(this, "staff");
            pairText.setText("연결된 계정: " + Store.get(this, "email") + (staff.isEmpty() ? "" : " (" + staff + ")") + (checkMsg.isEmpty() ? "" : "\n" + checkMsg));
            pairText.setTextColor(checkMsg.startsWith("❌") ? Ui.RED : Ui.GREEN);
        } else {
            pairText.setText((checkMsg.isEmpty() ? "" : checkMsg + "\n") + "아직 연결 안 됐어요.\n이 폰의 크롬에서 강CRM을 열고 → 설정 → 🔌 연결 → 📞 강CRM 전화 앱 → [이 폰을 전화 앱과 연결]을 누르세요.");
            pairText.setTextColor(checkMsg.startsWith("❌") ? Ui.RED : Ui.GRAY);
        }

        permBox.removeAllViews();
        boolean phone = has(Manifest.permission.READ_PHONE_STATE) && has(Manifest.permission.READ_CALL_LOG);
        addPerm("전화 · 통화 기록 (필수)", phone, new Runnable() {
            @Override
            public void run() {
                requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG}, 1);
            }
        });
        addPerm("다른 앱 위에 표시 (필수 · 고객 카드)", Settings.canDrawOverlays(this), new Runnable() {
            @Override
            public void run() {
                startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            }
        });
        if (Build.VERSION.SDK_INT >= 33) {
            addPerm("알림 (결과 남기기 · 부재중)", has(Manifest.permission.POST_NOTIFICATIONS), new Runnable() {
                @Override
                public void run() {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 2);
                }
            });
        }
        addPerm("녹음 파일 읽기 (통화 녹음 백업)", RecBackup.canRead(this), new Runnable() {
            @Override
            public void run() {
                requestPermissions(new String[]{RecBackup.readPerm()}, 3);
            }
        });
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean batt = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        addPerm("배터리 절전 예외 (권장)", batt, new Runnable() {
            @Override
            public void run() {
                try {
                    startActivity(new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:" + getPackageName())));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                }
            }
        });

        if (recText != null) {
            boolean on = RecBackup.on(this), wifi = RecBackup.wifiOnly(this);
            int rq = Store.arr(this, "recq").length();
            String st = Store.get(this, "recStatus");
            long stAt = Store.getLong(this, "recStatusAt");
            StringBuilder sb = new StringBuilder();
            sb.append(on ? "켜짐" : "꺼짐 (녹음을 올리지 않아요)");
            if (on && wifi) sb.append(" · 와이파이에서만");
            if (on && !RecBackup.canRead(this)) sb.append("\n⬜ ② 권한에서 '녹음 파일 읽기'를 허용해 주세요");
            if (rq > 0) sb.append("\n⏳ 올릴 녹음 ").append(rq).append("건");
            if (!st.isEmpty()) sb.append("\n").append(stAt > 0 ? Fmt.hm(stAt) + " " : "").append(st);
            if (!recFind.isEmpty()) sb.append("\n").append(recFind);
            recText.setText(sb.toString());
            recText.setTextColor(on ? Ui.INK : Ui.GRAY);
            recOnBtn.setText(on ? "녹음 백업 끄기" : "녹음 백업 켜기");
            recWifiBtn.setText(wifi ? "와이파이에서만: 켬" : "와이파이에서만: 끔");
            recWifiBtn.setEnabled(on);
        }

        recentBox.removeAllViews();
        JSONArray a = Store.arr(this, "recent");
        int q = Store.arr(this, "queue").length();
        if (a.length() == 0) recentBox.addView(Ui.text(this, "아직 없어요. 강CRM 고객과 통화하면 여기에 남아요.", 13, Ui.GRAY, false), Ui.full(this, 6));
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            String d = o.optString("direction");
            String icon = "in".equals(d) ? "📲" : ("missed".equals(d) ? "📵" : "📞");
            String r = o.optString("result");
            String line = icon + " " + Fmt.hm(o.optLong("at")) + " · " + o.optString("name") + (r.isEmpty() ? "" : " · " + r) + (o.optBoolean("ok") ? "  ✅" : "  ⏳ 못 올림");
            recentBox.addView(Ui.text(this, line, 14, o.optBoolean("ok") ? Ui.INK : Ui.RED, false), Ui.full(this, 6));
        }
        if (q > 0) {
            Button retry = Ui.button(this, "못 올린 기록 " + q + "건 다시 올리기", false);
            retry.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onResume();
                }
            });
            recentBox.addView(retry, Ui.full(this, 8));
        }
    }

    /** 최근 7일 통화 녹음 파일이 있는지 (자동 녹음이 켜져 있는지 확인용) */
    private void checkRecordings() {
        if (!RecBackup.canRead(this)) {
            requestPermissions(new String[]{RecBackup.readPerm()}, 3);
            return;
        }
        final Context app = getApplicationContext();
        recFind = "찾는 중…";
        refresh();
        RecBackup.REC_EX.execute(new Runnable() {
            @Override
            public void run() {
                final java.util.List<RecBackup.Found> all = RecBackup.recentAudio(app, 3, 15);   // 🔎 v3 녹음 앱이 어디에 저장하는지
                int calls = 0;
                final StringBuilder b = new StringBuilder();
                for (RecBackup.Found f : all) {
                    if (f.score > 0) calls++;
                    b.append(f.score > 0 ? "✅ " : "⬜ ").append(Fmt.hm(f.added * 1000L)).append(" · ").append(f.path.isEmpty() ? "(폴더 모름)" : f.path)
                            .append("\n     ").append(f.name).append(String.format(java.util.Locale.US, " · %.1fMB", f.size / 1048576.0)).append("\n");
                }
                final String m = all.isEmpty()
                        ? "⚠️ 최근 3일 녹음 파일이 이 앱에서 하나도 안 보여요. 녹음 앱(에이닷 등)이 자기 앱 안에만 저장하는 거예요 → 녹음 화면의 [공유] → '강CRM 전화'로 붙여 주세요."
                        : (calls > 0 ? "✅ 통화 녹음으로 보이는 파일 " + calls + "개 · 자동으로 올려요" : "⚠️ 오디오 파일은 있는데 통화 녹음으로 보이는 게 없어요 · 이 화면을 캡처해서 보내 주시면 그 폴더도 찾게 고쳐요");
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        recFind = m;
                        refresh();
                        if (!all.isEmpty()) {
                            new AlertDialog.Builder(MainActivity.this)
                                    .setTitle("최근 3일 녹음 파일 (✅ = 통화 녹음으로 찾는 것)")
                                    .setMessage(m + "\n\n" + b)
                                    .setPositiveButton("확인", null)
                                    .show();
                        }
                    }
                });
            }
        });
    }

    private void addPerm(String label, boolean ok, final Runnable ask) {
        LinearLayout r = Ui.row(this);
        TextView t = Ui.text(this, (ok ? "✅ " : "⬜ ") + label, 15, ok ? Ui.INK : Ui.RED, !ok);
        r.addView(t, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        if (!ok) {
            Button b = Ui.button(this, "허용", true);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    ask.run();
                }
            });
            r.addView(b);
        }
        permBox.addView(r, Ui.full(this, 8));
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        refresh();
    }

    private void testPopup(final boolean resultScreen) {
        final Context app = getApplicationContext();
        final String num = Fmt.digits(testNum.getText().toString());
        if (!Store.paired(app)) {
            Toast.makeText(this, "먼저 강CRM과 연결해 주세요", Toast.LENGTH_LONG).show();
            return;
        }
        if (num.length() < 9) {
            Toast.makeText(this, "번호를 넣어 주세요", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!resultScreen && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'다른 앱 위에 표시'를 먼저 허용해 주세요", Toast.LENGTH_LONG).show();
            return;
        }
        Toast.makeText(this, "강CRM에서 찾는 중…", Toast.LENGTH_SHORT).show();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                String err = "";
                JSONObject cu = null;
                try {
                    cu = Api.findCustomer(app, num);
                } catch (Api.ApiError e) {
                    err = "❌ " + e.code + " " + e.getMessage();
                } catch (Exception e) {
                    err = "❌ 인터넷을 확인해 주세요";
                }
                final JSONObject fc = cu;
                final String fe = err;
                JSONObject log = null;
                if (fc != null && resultScreen) {
                    try {
                        log = CallFlow.baseLog(app, new Cust(fc), num, "in", System.currentTimeMillis() - 95000L, 95);
                        log.put("_last", LastCall.fetch(app, fc.optString("id"), null));
                    } catch (Exception ignore) {
                        log = null;
                    }
                }
                final JSONObject fl = log;
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        if (!fe.isEmpty()) {
                            Toast.makeText(app, fe, Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (fc == null) {
                            Toast.makeText(app, "강CRM 고객이 아니에요 (이런 번호는 카드가 안 떠요)", Toast.LENGTH_LONG).show();
                            return;
                        }
                        if (resultScreen && fl != null) {
                            startActivity(new Intent(MainActivity.this, ResultActivity.class).putExtra("log", fl.toString()).putExtra("test", true));
                        } else {
                            Overlay.show(app, new Cust(fc), num, "시험", 8000);
                            CallFlow.EX.execute(new Runnable() {   // 🕘 v3 지난 통화도
                                @Override
                                public void run() {
                                    String id = fc.optString("id");
                                    Overlay.setLast(id, LastCall.fetch(app, id, null));
                                }
                            });
                        }
                    }
                });
            }
        });
    }
}
