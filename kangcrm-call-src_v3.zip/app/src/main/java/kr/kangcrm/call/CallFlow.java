package kr.kangcrm.call;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Handler;
import android.os.Looper;
import android.provider.CallLog;
import android.telephony.TelephonyManager;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 전화 상태 흐름 — 울림(수신) / 통화(받음·발신) / 끊김
 *  · 울리거나 걸면: 강CRM 고객인지 찾아서 카드 띄우기 (고객이 아니면 아무것도 안 함)
 *  · 끊기면: 통화 기록(번호·종류·시간)을 보고 → 받은·건 통화는 결과 창 / 부재중·안 받음은 바로 기록
 */
final class CallFlow {
    private CallFlow() {}

    static final ExecutorService EX = Executors.newSingleThreadExecutor();
    static final Handler H = new Handler(Looper.getMainLooper());
    private static final Map<String, JSONObject> CACHE = new HashMap<>();
    private static final Map<String, Long> CACHE_AT = new HashMap<>();
    private static final JSONObject NONE = new JSONObject();

    static boolean idle(Context c) {
        String st = Store.get(c, "st");
        return (st.isEmpty() || "IDLE".equals(st)) && Store.getLong(c, "busy") == 0;
    }

    static void onState(final Context c, final String state, final String rawNum, final Runnable done) {
        final String num = Fmt.digits(rawNum);
        final long now = System.currentTimeMillis();
        String st0 = Store.get(c, "st");
        if (!st0.isEmpty() && !"IDLE".equals(st0) && now - Store.getLong(c, "stAt") > 3L * 3600L * 1000L) st0 = "IDLE";   // 끊김 신호를 놓쳐 멈춰 있던 상태
        final String last = st0;
        Store.putLong(c, "stAt", now);

        if (TelephonyManager.EXTRA_STATE_RINGING.equals(state)) {
            if (!"RINGING".equals(last)) {
                Store.put(c, "st", "RINGING");
                Store.put(c, "dir", "in");
                Store.putLong(c, "t0", now);
                Store.put(c, "num", "");
                Store.put(c, "ans", "");
            }
            if (!num.isEmpty() && !num.equals(Store.get(c, "num"))) {
                Store.put(c, "num", num);
                lookupAndShow(c, num, "전화 오는 중", done);
                return;
            }
            done.run();
            return;
        }

        if (TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state)) {
            boolean fresh = false;
            if ("RINGING".equals(last)) {
                Store.put(c, "ans", "1");   // 받음
            } else if (!"OFFHOOK".equals(last)) {
                fresh = true;               // 거는 전화
                Store.put(c, "dir", "out");
                Store.putLong(c, "t0", now);
                Store.put(c, "num", "");
                Store.put(c, "ans", "1");
            }
            Store.put(c, "st", "OFFHOOK");
            if (!num.isEmpty() && !num.equals(Store.get(c, "num"))) {
                Store.put(c, "num", num);
                lookupAndShow(c, num, fresh || "out".equals(Store.get(c, "dir")) ? "거는 중" : "통화 중", done);
                return;
            }
            done.run();
            return;
        }

        if (TelephonyManager.EXTRA_STATE_IDLE.equals(state)) {
            if (last.isEmpty() || "IDLE".equals(last)) {   // 같은 신호가 두 번 오거나, 앱을 막 깐 뒤
                done.run();
                return;
            }
            Store.put(c, "st", "IDLE");
            Store.putLong(c, "busy", 1);
            Overlay.hide();
            H.postDelayed(new Runnable() {
                @Override
                public void run() {
                    EX.execute(new Runnable() {
                        @Override
                        public void run() {
                            try {
                                endOfCall(c);
                            } catch (Throwable t) {
                                Log.w("KC", "endOfCall", t);
                            } finally {
                                Store.putLong(c, "busy", 0);
                                H.post(done);
                            }
                        }
                    });
                }
            }, 1500);
            return;
        }
        done.run();
    }

    private static void lookupAndShow(final Context c, final String num, final String kind, final Runnable done) {
        EX.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    JSONObject cu = lookup(c, num);
                    if (cu != null && Overlay.can(c) && !"IDLE".equals(Store.get(c, "st")) && num.equals(Store.get(c, "num"))) {
                        Overlay.show(c, new Cust(cu), num, kind, 0);
                        String id = cu.optString("id");
                        Overlay.setLast(id, LastCall.fetch(c, id, null));   // 🕘 v3 지난 통화 (카드를 먼저 띄우고 채움)
                    }
                } catch (Throwable t) {
                    Log.w("KC", "lookup", t);
                } finally {
                    H.post(done);
                }
            }
        });
    }

    /** 강CRM 고객 찾기 (10분 기억 · 인터넷이 안 되면 기억한 것) */
    static JSONObject lookup(Context c, String num) {
        if (num == null || num.length() < 9) return null;
        synchronized (CACHE) {
            Long at = CACHE_AT.get(num);
            if (at != null && System.currentTimeMillis() - at < 10 * 60 * 1000L) {
                JSONObject v = CACHE.get(num);
                return v == NONE ? null : v;
            }
        }
        try {
            JSONObject cu = Api.findCustomer(c, num);
            synchronized (CACHE) {
                CACHE.put(num, cu == null ? NONE : cu);
                CACHE_AT.put(num, System.currentTimeMillis());
            }
            if (cu != null) Store.put(c, "lastCust", cu.toString());
            return cu;
        } catch (Exception e) {
            Log.w("KC", "findCustomer", e);
            try {
                String s = Store.get(c, "lastCust");
                if (!s.isEmpty()) {
                    JSONObject j = new JSONObject(s);
                    if (num.equals(j.optString("id")) || num.equals(Fmt.digits(j.optString("phone")))) return j;
                }
            } catch (Exception ignore) {
                // 없음
            }
            return null;
        }
    }

    private static final class Rec {
        String number = "";
        int type;
        long duration;
        long date;
    }

    /** 방금 끝난 통화 (폰 통화 기록에서 · 몇 번 기다려 봄) */
    private static Rec latestCall(Context c, long t0) {
        if (c.checkSelfPermission(Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) return null;
        long now = System.currentTimeMillis();
        long from = t0 > 0 ? t0 - 120000L : now - 15 * 60 * 1000L;
        for (int attempt = 0; attempt < 4; attempt++) {
            Cursor cur = null;
            try {
                cur = c.getContentResolver().query(CallLog.Calls.CONTENT_URI,
                        new String[]{CallLog.Calls.NUMBER, CallLog.Calls.TYPE, CallLog.Calls.DURATION, CallLog.Calls.DATE},
                        null, null, CallLog.Calls.DATE + " DESC");
                if (cur != null && cur.moveToFirst()) {
                    long date = cur.getLong(3);
                    if (date >= from && date <= now + 60000L) {
                        Rec r = new Rec();
                        String n = cur.getString(0);
                        r.number = n == null ? "" : n;
                        r.type = cur.getInt(1);
                        r.duration = cur.getLong(2);
                        r.date = date;
                        return r;
                    }
                }
            } catch (Throwable t) {
                Log.w("KC", "calllog", t);
                return null;
            } finally {
                if (cur != null) cur.close();
            }
            try {
                Thread.sleep(1200);
            } catch (InterruptedException ie) {
                return null;
            }
        }
        return null;
    }

    private static void endOfCall(Context c) throws Exception {
        String dir = Store.get(c, "dir");
        String num = Store.get(c, "num");
        boolean ans = "1".equals(Store.get(c, "ans"));
        long t0 = Store.getLong(c, "t0");
        long now = System.currentTimeMillis();
        String type;
        long dur;

        Rec r = latestCall(c, t0);
        if (r != null) {
            if (!r.number.isEmpty()) num = r.number;
            dur = r.duration;
            t0 = r.date;
            if (r.type == CallLog.Calls.INCOMING_TYPE) type = "in";
            else if (r.type == CallLog.Calls.OUTGOING_TYPE) type = dur > 0 ? "out" : "noanswer";
            else if (r.type == CallLog.Calls.MISSED_TYPE || r.type == CallLog.Calls.REJECTED_TYPE || r.type == CallLog.Calls.BLOCKED_TYPE) type = "missed";
            else type = "in".equals(dir) ? "in" : "out";
        } else {
            type = "in".equals(dir) ? (ans ? "in" : "missed") : "out";
            dur = ans && t0 > 0 ? Math.max(0, (now - t0) / 1000L) : 0;
        }
        num = Fmt.digits(num);
        Store.put(c, "dir", "");
        Store.put(c, "ans", "");
        if (num.length() < 9) return;

        JSONObject cu = lookup(c, num);
        if (cu == null) return;   // 강CRM 고객이 아니면 아무것도 안 함 (개인 전화)

        JSONObject log = baseLog(c, new Cust(cu), num, type, t0 > 0 ? t0 : now, dur);
        if ("missed".equals(type) || "noanswer".equals(type)) {
            log.put("result", "missed".equals(type) ? "부재중 (못 받음)" : "부재중");
            log.put("resultKey", "missed".equals(type) ? "missed_in" : "missed");
            save(c, log);
            if ("missed".equals(type)) Notifs.missed(c, log);
            flushQueue(c);
            return;
        }
        try {
            log.put("_last", LastCall.fetch(c, cu.optString("id"), log.optString("id")));   // 🕘 v3
        } catch (Exception ignore) {
            // 없어도 됨
        }
        Intent i = new Intent(c, ResultActivity.class)
                .putExtra("log", log.toString())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        Notifs.result(c, log);   // 창이 안 떠도 알림에서 열 수 있게 (저장하면 지움)
        try {
            c.startActivity(i);
        } catch (Throwable t) {
            Log.w("KC", "result activity", t);
        }
        if (dur > 0) RecBackup.start(c, log, t0 > 0 ? t0 : now - dur * 1000L, System.currentTimeMillis());   // 🎙 통화 녹음 백업
        flushQueue(c);
    }

    static JSONObject baseLog(Context c, Cust cu, String num, String type, long startedAt, long dur) throws Exception {
        JSONObject log = new JSONObject();
        log.put("id", Fmt.newId());
        log.put("customerId", cu.id());
        log.put("customerName", cu.name());
        log.put("phone", num);
        log.put("direction", type);
        log.put("startedAt", Fmt.iso(startedAt));
        log.put("durationSec", Long.valueOf(dur));
        log.put("result", "");
        log.put("resultKey", "");
        log.put("memo", "");
        log.put("nextKind", "");
        log.put("nextDate", "");
        log.put("uploader", Store.get(c, "email"));
        log.put("staff", Store.get(c, "staff"));
        log.put("managerName", cu.manager());
        log.put("managerEmail", Api.managerEmailFor(c, cu.manager()));
        log.put("applied", Boolean.FALSE);
        log.put("at", Fmt.iso(System.currentTimeMillis()));
        log.put("src", "android");
        log.put("appVer", appVer(c));
        log.put("_status", cu.s("salesStatus"));
        log.put("_line2", cu.line2());
        log.put("_memo", cu.memo());
        log.put("_line3", cu.line3());
        log.put("_facts", Facts.toJson(Facts.of(cu.d)).toString());   // 📋 v3 결과 창에도
        return log;
    }

    static String appVer(Context c) {
        try {
            return c.getPackageManager().getPackageInfo(c.getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** 올리기 (실패하면 이 폰에 모아 뒀다가 나중에) — 백그라운드에서 부르기 */
    static boolean save(Context c, JSONObject log) {
        boolean ok;
        try {
            Api.createCallLog(c, log);
            Store.queueRemove(c, log.optString("id"));
            ok = true;
        } catch (Exception e) {
            Log.w("KC", "save", e);
            Store.queueAdd(c, log);
            ok = false;
        }
        try {
            JSONObject r = new JSONObject();
            r.put("id", log.optString("id"));
            r.put("name", log.optString("customerName"));
            r.put("direction", log.optString("direction"));
            r.put("result", log.optString("result"));
            r.put("at", System.currentTimeMillis());
            r.put("ok", ok);
            r.put("phone", log.optString("phone"));          // v3 공유한 녹음을 붙일 통화 고르기용
            r.put("customerId", log.optString("customerId"));
            r.put("startedAt", log.optString("startedAt"));
            r.put("dur", log.optLong("durationSec", 0));
            Store.pushRecent(c, r);
        } catch (Exception ignore) {
            // 화면용이라 괜찮음
        }
        return ok;
    }

    /** 못 올린 기록 다시 올리기 */
    static int flushQueue(Context c) {
        JSONArray q = Store.arr(c, "queue");
        int sent = 0;
        for (int i = 0; i < q.length(); i++) {
            JSONObject log = q.optJSONObject(i);
            if (log == null) continue;
            try {
                Api.createCallLog(c, log);
                Store.queueRemove(c, log.optString("id"));
                sent++;
            } catch (Exception e) {
                break;   // 아직 인터넷이 안 됨
            }
        }
        RecBackup.flush(c);
        return sent;
    }
}
