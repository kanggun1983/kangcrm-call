package kr.kangcrm.call;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * 🎙 2단계: 통화 녹음 자동 백업
 *  · 갤럭시 '통화 자동 녹음'이 만든 파일(Recordings/Call)을 통화가 끝난 뒤 찾아서
 *  · 강CRM 업로드 창구(관리자 드라이브 · kind: rec)로 → 대표님 드라이브 '강CRM 녹음/월/고객'
 *  · 통화 기록(call_logs)에 recFileId를 붙임 (기록을 아직 안 올렸으면 올릴 때 같이)
 */
final class RecBackup {
    private RecBackup() {}

    static final ExecutorService REC_EX = Executors.newSingleThreadExecutor();
    static final AtomicInteger BUSY = new AtomicInteger(0);   // 올리는 동안은 서비스를 안 끔 (앱이 꺼지지 않게)
    static final long MAX_BYTES = 20L * 1024L * 1024L;

    static boolean on(Context c) { return !"0".equals(Store.get(c, "recOn")); }   // 기본 켜짐

    static boolean wifiOnly(Context c) { return "1".equals(Store.get(c, "recWifi")); }

    static String readPerm() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
    }

    static boolean canRead(Context c) {
        return c.checkSelfPermission(readPerm()) == PackageManager.PERMISSION_GRANTED;
    }

    static boolean onWifi(Context c) {
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            Network n = cm.getActiveNetwork();
            if (n == null) return false;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            return nc != null && (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET));
        } catch (Throwable t) {
            return false;
        }
    }

    static void status(Context c, String s) {
        Store.put(c, "recStatus", s);
        Store.putLong(c, "recStatusAt", System.currentTimeMillis());
    }

    /** v4 녹음 탭 · 통화 기록 줄에 보일 상태 (통화마다 · 최근 50개)
     *  find 찾는 중 · wait 와이파이 기다림 · retry 다시 올릴 것 · ok 올림 · nf 못 찾음 · gone 지워짐 · fail 그만둠 · big 너무 큼 · cfg 설정 필요 · secret 비밀번호 */
    static void status(Context c, JSONObject job, String state, String s) {
        status(c, s);
        logRec(c, job, state, s);
    }

    static synchronized void logRec(Context c, JSONObject job, String state, String msg) {
        if (job == null) return;
        String id = job.optString("id");
        JSONArray a = Store.arr(c, "recLog"), b = new JSONArray();
        JSONObject e = new JSONObject();
        try {
            for (int i = 0; i < a.length(); i++) {
                JSONObject x = a.optJSONObject(i);
                if (x != null && id.equals(x.optString("id"))) e = x;
            }
            e.put("id", id);
            e.put("name", job.optString("customerName"));
            e.put("t0", job.optLong("t0"));
            e.put("dur", job.optLong("dur", e.optLong("dur", 0)));
            e.put("state", state);
            if (job.optLong("size", 0) > 0) e.put("size", job.optLong("size"));
            e.put("msg", msg);
            e.put("upd", System.currentTimeMillis());
        } catch (Exception ignore) {
            return;
        }
        b.put(e);
        for (int i = 0; i < a.length() && b.length() < 50; i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !id.equals(x.optString("id"))) b.put(x);
        }
        Store.putArr(c, "recLog", b);
    }

    static JSONObject logOf(Context c, String id) {
        JSONArray a = Store.arr(c, "recLog");
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && id.equals(x.optString("id"))) return x;
        }
        return null;
    }

    /** 받은 · 건 통화가 끝나면 (강CRM 고객만) */
    static void start(final Context c, JSONObject log, long t0, long tEnd) {
        if (!on(c)) return;
        if (!canRead(c)) {
            status(c, "⬜ 녹음 파일 읽기 권한이 없어서 녹음을 못 올렸어요 (앱 ② 권한에서 허용)");
            return;
        }
        final JSONObject job = new JSONObject();
        try {
            job.put("id", log.optString("id"));
            job.put("customerId", log.optString("customerId"));
            job.put("customerName", log.optString("customerName"));
            job.put("phone", log.optString("phone"));
            job.put("t0", t0);
            job.put("tEnd", tEnd);
            job.put("dur", log.optLong("durationSec", 0));
            job.put("tries", 0);
        } catch (Exception e) {
            return;
        }
        queueAdd(c, job);   // 앱이 중간에 꺼져도 다음에 이어서
        logRec(c, job, "find", "녹음 파일 찾는 중");
        BUSY.incrementAndGet();
        REC_EX.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    runJob(c, job, 8);
                } finally {
                    BUSY.decrementAndGet();
                    CallService.doneIfIdle(c);
                }
            }
        });
    }

    /** 📤 v3 공유로 받은 녹음 (이미 이 앱 안에 복사해 둔 파일) → 바로 올리기 */
    static void startShared(final Context c, final JSONObject job) {
        queueAdd(c, job);
        BUSY.incrementAndGet();
        REC_EX.execute(new Runnable() {
            @Override
            public void run() {
                try {
                    runJob(c, job, 1);
                } finally {
                    BUSY.decrementAndGet();
                }
            }
        });
    }

    /** 📝 v3 통화 기록에 칸 붙이기 (기록이 아직 없으면 올릴 때 같이) */
    static void attach(final Context c, final String id, final JSONObject add) {
        REC_EX.execute(new Runnable() {
            @Override
            public void run() {
                mergeStash(c, id, add);
                status(c, tryPatch(c, id) ? "✅ 공유한 대본 글을 통화 기록에 붙였어요" : "⏳ 대본 글은 인터넷이 되면 · 통화 기록을 올릴 때 같이 붙여요");
            }
        });
    }

    static synchronized void mergeStash(Context c, String id, JSONObject add) {
        JSONObject cur;
        try {
            String st = Store.get(c, "rec:" + id);
            cur = st.isEmpty() ? new JSONObject() : new JSONObject(st);
            java.util.Iterator<String> it = add.keys();
            while (it.hasNext()) {
                String k = it.next();
                cur.put(k, add.opt(k));
            }
        } catch (Exception e) {
            cur = add;
        }
        Store.put(c, "rec:" + id, cur.toString());
    }

    /** 보관한 칸을 통화 기록에 붙여 보기 (기록이 아직 없으면 · 인터넷이 안 되면 나중에) */
    static boolean tryPatch(Context c, String id) {
        String st = Store.get(c, "rec:" + id);
        if (st.isEmpty()) {
            pendRemove(c, id);
            return true;
        }
        try {
            Api.patchCallLog(c, id, new JSONObject(st));
            Store.put(c, "rec:" + id, "");
            pendRemove(c, id);
            return true;
        } catch (Throwable t) {
            Log.w("KC", "patch later", t);
            pendAdd(c, id);
            return false;
        }
    }

    static synchronized void pendAdd(Context c, String id) {
        JSONArray a = Store.arr(c, "attachq");
        for (int i = 0; i < a.length(); i++) if (id.equals(a.optString(i))) return;
        a.put(id);
        while (a.length() > 100) a.remove(0);
        Store.putArr(c, "attachq", a);
    }

    static synchronized void pendRemove(Context c, String id) {
        JSONArray a = Store.arr(c, "attachq"), b = new JSONArray();
        for (int i = 0; i < a.length(); i++) if (!id.equals(a.optString(i))) b.put(a.optString(i));
        Store.putArr(c, "attachq", b);
    }

    /** false = 지금은 더 못 올림 (인터넷 · 와이파이) → 모아 둔 것 다시 올리기를 멈춤 */
    private static boolean runJob(Context c, JSONObject job, int findTries) {
        String id = job.optString("id");
        String who = job.optString("customerName");
        try {
            if (!job.has("uri")) {
                Found f = find(c, job.optLong("t0"), job.optLong("tEnd"), job.optString("phone"), findTries);
                if (f == null) {
                    queueRemove(c, id);
                    status(c, job, "nf", "⚠️ " + who + " 통화의 녹음 파일을 못 찾았어요 → 에이닷이면 녹음 화면 [공유] → '콜매니저' · 갤럭시 전화 앱이면 설정 → 통화 녹음 → '통화 자동 녹음' 켜기");
                    return true;
                }
                job.put("uri", f.uri.toString());
                job.put("mime", f.mime);
                job.put("size", f.size);
                job.put("fname", f.name);
                queueAdd(c, job);
            }
            if (wifiOnly(c) && !onWifi(c)) {
                status(c, job, "wait", "📶 와이파이에 연결되면 녹음을 올려요 (" + who + ")");
                return false;
            }
            upload(c, job);
            return true;
        } catch (FileNotFoundException e) {
            queueRemove(c, id);
            status(c, job, "gone", "⚠️ " + who + " 통화 녹음 파일이 지워져서 못 올렸어요");
            return true;
        } catch (Throwable t) {
            Log.w("KC", "rec", t);
            int n = job.optInt("tries", 0) + 1;
            if (n >= 8) {
                queueRemove(c, id);
                status(c, job, "fail", "⚠️ " + who + " 통화 녹음을 여러 번 못 올려서 그만뒀어요 (" + t.getClass().getSimpleName() + ")");
                return true;
            }
            try {
                job.put("tries", n);
            } catch (Exception ignore) {
                // 괜찮음
            }
            queueAdd(c, job);
            status(c, job, "retry", "⏳ 녹음 올리기 실패 · 나중에 다시 올려요 (" + t.getClass().getSimpleName() + ")");
            return false;
        }
    }

    static final class Found {
        Uri uri;
        String mime = "";
        long size;
        String name = "";
        String path = "";
        long added;
        int score;
    }

    // 📞 v3: 갤럭시 녹음(Call) · 에이닷 · T전화 · 익시오 등 · 번호가 이름에 있으면 제일 우선
    static final String[] CALL_WORDS = {"Call", "call", "CALL", "통화", "에이닷", "adot", "Adot", "A.", "TPhone", "tphone", "T전화", "ixi", "익시오"};
    static final String[] REC_WORDS = {"Record", "record", "녹음"};

    static int score(String path, String name, String last4) {
        String p = path == null ? "" : path, nm = name == null ? "" : name;
        if (!last4.isEmpty() && nm.replaceAll("[^0-9]", "").contains(last4)) return 3;
        for (String w : CALL_WORDS) if (p.contains(w) || nm.contains(w)) return 2;
        for (String w : REC_WORDS) if (p.contains(w) || nm.contains(w)) return 1;
        return 0;
    }

    /** 🔎 v3 최근 오디오 파일 목록 (녹음 앱이 어디에 저장하는지 확인용 · 점수 0 = 통화 녹음으로 안 봄) */
    static java.util.List<Found> recentAudio(Context c, int days, int max) {
        java.util.List<Found> out = new java.util.ArrayList<>();
        Uri u = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String pathCol = Build.VERSION.SDK_INT >= 29 ? MediaStore.MediaColumns.RELATIVE_PATH : "_data";
        String[] proj = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED, pathCol};
        long from = System.currentTimeMillis() / 1000L - days * 86400L;
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(u, proj, MediaStore.MediaColumns.DATE_ADDED + ">=?", new String[]{String.valueOf(from)}, MediaStore.MediaColumns.DATE_ADDED + " DESC");
            if (cur == null) return out;
            while (cur.moveToNext() && out.size() < max) {
                Found f = new Found();
                f.uri = ContentUris.withAppendedId(u, cur.getLong(0));
                f.name = cur.getString(1) == null ? "" : cur.getString(1);
                f.size = cur.getLong(2);
                f.mime = cur.getString(3) == null ? "" : cur.getString(3);
                f.added = cur.getLong(4);
                f.path = cur.getString(5) == null ? "" : cur.getString(5);
                f.score = score(f.path, f.name, "");
                out.add(f);
            }
        } catch (Throwable t) {
            Log.w("KC", "recentAudio", t);
        } finally {
            if (cur != null) cur.close();
        }
        return out;
    }

    /** 통화가 끝난 뒤 생긴 통화 녹음 파일 (다 쓸 때까지 기다림) */
    static Found find(Context c, long t0, long tEnd, String phone, int tries) throws InterruptedException {
        long base = t0 > 0 ? t0 : tEnd - 3600000L;
        long fromSec = base / 1000L - 20L;          // 이번 통화가 시작된 뒤 생긴 파일만
        long toSec = tEnd / 1000L + 600L;
        for (int attempt = 0; attempt < tries; attempt++) {
            Found f = query(c, fromSec, toSec, phone);
            if (f != null && f.size > 0) {
                Thread.sleep(1500);
                Found g = query(c, fromSec, toSec, phone);
                if (g != null && g.uri.equals(f.uri) && g.size == f.size) return g;
                continue;
            }
            if (attempt + 1 < tries) Thread.sleep(2500);
        }
        return null;
    }

    /** 최근 며칠 안의 통화 녹음 파일 (설정 확인용) */
    static Found latest(Context c, int days) {
        long now = System.currentTimeMillis() / 1000L;
        return query(c, now - days * 86400L, now + 60L, "");
    }

    private static Found query(Context c, long fromSec, long toSec, String phone) {
        Uri u = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        boolean rel = Build.VERSION.SDK_INT >= 29;
        String pathCol = rel ? MediaStore.MediaColumns.RELATIVE_PATH : "_data";
        String[] proj = {MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.MIME_TYPE, MediaStore.MediaColumns.DATE_ADDED, pathCol};
        String last4 = phone != null && phone.length() >= 4 ? phone.substring(phone.length() - 4) : "";
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(u, proj, MediaStore.MediaColumns.DATE_ADDED + ">=? AND " + MediaStore.MediaColumns.DATE_ADDED + "<=?",
                    new String[]{String.valueOf(fromSec), String.valueOf(toSec)}, MediaStore.MediaColumns.DATE_ADDED + " DESC");
            if (cur == null) return null;
            int n = 0;
            Found best = null;
            while (cur.moveToNext() && n++ < 30) {
                String nm = cur.getString(1) == null ? "" : cur.getString(1);
                String p = cur.getString(5) == null ? "" : cur.getString(5);
                int sc = score(p, nm, last4);
                if (sc <= 0 || (best != null && sc <= best.score)) continue;   // 같은 점수면 더 최근 것 (위에서부터)
                Found f = new Found();
                f.uri = ContentUris.withAppendedId(u, cur.getLong(0));
                f.name = nm;
                f.path = p;
                f.size = cur.getLong(2);
                String mime = cur.getString(3);
                f.mime = mime == null || mime.isEmpty() ? "audio/mp4" : mime;
                f.added = cur.getLong(4);
                f.score = sc;
                best = f;
            }
            return best;
        } catch (Throwable t) {
            Log.w("KC", "rec query", t);
            return null;
        } finally {
            if (cur != null) cur.close();
        }
    }

    private static byte[] readAll(Context c, Uri uri) throws Exception {
        InputStream in = c.getContentResolver().openInputStream(uri);
        if (in == null) throw new Exception("파일을 열 수 없어요");
        ByteArrayOutputStream bo = new ByteArrayOutputStream();
        byte[] buf = new byte[16384];
        int n;
        long total = 0;
        try {
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > MAX_BYTES) throw new Exception("too big");
                bo.write(buf, 0, n);
            }
        } finally {
            in.close();
        }
        return bo.toByteArray();
    }

    private static String safe(String s) {
        String t = s == null ? "" : s.replaceAll("[\\\\/:*?\"<>|]", "").trim();
        return t.isEmpty() ? "고객" : (t.length() > 20 ? t.substring(0, 20) : t);
    }

    // ── 🎙 v4.9 녹음 백업 설정 (강CRM V231 · 서류 백업과 따로) ──
    static final long CFG_KEEP_MS = 7L * 24L * 3600L * 1000L;   // 설정 때문에 못 올린 녹음은 7일 동안 기다렸다가 올림

    /** 녹음을 올릴 수 있나: "" = 올림 · "off" = 강CRM에서 녹음 백업 꺼짐 · "url" = 업로드 창구 주소 없음
     *  recMode: admin · off (V231) · 없으면 예전 규칙 (서류 백업이 관리자 드라이브면 올림) */
    static String cfgBlock(JSONObject cfg) {
        String mode = cfg == null ? "" : cfg.optString("recMode", "");
        boolean on = "admin".equals(mode) || (!"off".equals(mode) && "admin".equals(cfg == null ? "" : cfg.optString("driveMode", "")));
        if (!on) return "off";
        if (cfg.optString("driveScriptUrl", "").trim().isEmpty()) return "url";
        return "";
    }

    static String cfgMsg(String block) {
        return "url".equals(block)
                ? "⚠️ 녹음 업로드 창구 주소가 없어요 · 강CRM 설정 → 연결 관리 → 콜매니저 → 🎙 녹음 백업에서 넣으면 모아 둔 녹음도 올려요"
                : "⚠️ 녹음 백업이 꺼져 있어요 · 강CRM 설정 → 연결 관리 → 콜매니저 → 🎙 녹음 백업에서 '대표님 구글 드라이브'를 고르면 모아 둔 녹음도 올려요";
    }

    /** 업로드 창구로 올리고 통화 기록에 붙이기 */
    static void upload(Context c, JSONObject job) throws Exception {
        JSONObject cfg = Api.driveCfg(c);
        String url = cfg.optString("driveScriptUrl", "").trim();
        String secret = cfg.optString("driveSecret", "");
        String block = cfgBlock(cfg);
        if (!block.isEmpty()) {   // v4.9 버리지 않고 보관 → 강CRM에서 켜면 다음에 올림 (7일 지난 건 그만)
            status(c, job, "cfg", cfgMsg(block));
            long t0 = job.optLong("t0", 0);
            if (t0 > 0 && System.currentTimeMillis() - t0 > CFG_KEEP_MS) queueRemove(c, job.optString("id"));
            else queueAdd(c, job);
            return;
        }
        if (job.optLong("size") > MAX_BYTES) {
            status(c, job, "big", "⚠️ 녹음 파일이 너무 커서(20MB 넘음) 올리지 않았어요 (" + job.optString("customerName") + ")");
            queueRemove(c, job.optString("id"));
            return;
        }
        byte[] bytes = readAll(c, Uri.parse(job.optString("uri")));
        long size = bytes.length;
        long t0 = job.optLong("t0", System.currentTimeMillis());
        if (t0 <= 0) t0 = System.currentTimeMillis();
        String fname = job.optString("fname", "");
        int dot = fname.lastIndexOf('.');
        String ext = dot > 0 && fname.length() - dot <= 5 ? fname.substring(dot + 1) : "m4a";
        String cname = safe(job.optString("customerName"));
        String phone = job.optString("phone", "");
        String last4 = phone.length() >= 4 ? phone.substring(phone.length() - 4) : phone;
        String name = "통화_" + new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(new Date(t0)) + "_" + cname + "." + ext;
        JSONObject meta = new JSONObject();
        meta.put("secret", secret);
        meta.put("kind", "rec");
        meta.put("mime", job.optString("mime", "audio/mp4"));
        meta.put("name", name);
        meta.put("month", new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date(t0)));
        meta.put("customer", cname + "_" + last4);
        meta.put("uploader", Store.get(c, "email"));
        String m = meta.toString();   // {…} 끝에 data만 붙임 (큰 글자를 한 번만 만들게)
        String body = m.substring(0, m.length() - 1) + ",\"data\":\"" + Base64.encodeToString(bytes, Base64.NO_WRAP) + "\"}";
        bytes = null;
        JSONObject r = Api.request(c, "POST", url, body, "text/plain", null, 180000);
        if (!r.optBoolean("ok", false)) {
            String err = r.optString("error", "");
            if ("secret".equals(err)) {
                status(c, job, "secret", "⚠️ 업로드 비밀번호가 맞지 않아요 (강CRM 설정 → 서류 클라우드 백업)");
                queueRemove(c, job.optString("id"));
                return;
            }
            throw new Exception("upload " + err);
        }
        JSONObject rec = new JSONObject();
        rec.put("recFileId", r.optString("id"));
        rec.put("recUrl", r.optString("url"));
        rec.put("recName", name);
        rec.put("recSize", Long.valueOf(size));
        rec.put("recMime", job.optString("mime", "audio/mp4"));
        rec.put("recAt", Fmt.iso(System.currentTimeMillis()));
        String id = job.optString("id");
        mergeStash(c, id, rec);   // 통화 기록을 아직 안 올렸으면 올릴 때 같이
        tryPatch(c, id);          // 파일은 이미 올라갔으니 여기서 실패해도 다시 올리지 않음 (붙이기만 나중에)
        queueRemove(c, id);
        String up = job.optString("uri", "");
        if (up.startsWith("file://") && up.contains("/share_")) {   // 📤 v3 공유로 받아 둔 임시 파일
            try {
                new java.io.File(Uri.parse(up).getPath()).delete();
            } catch (Throwable ignore) {
                // 괜찮음
            }
        }
        try {
            job.put("size", size);
        } catch (Exception ignore) {
            // 괜찮음
        }
        status(c, job, "ok", "✅ " + job.optString("customerName") + " 통화 녹음을 대표님 드라이브에 올렸어요");
    }

    // ── 못 올린 녹음 (와이파이만 · 실패) ──
    static synchronized void queueAdd(Context c, JSONObject job) {
        JSONArray a = Store.arr(c, "recq");
        JSONArray b = new JSONArray();
        String id = job.optString("id");
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !id.equals(x.optString("id"))) b.put(x);
        }
        b.put(job);
        while (b.length() > 50) b.remove(0);
        Store.putArr(c, "recq", b);
    }

    static synchronized void queueRemove(Context c, String id) {
        JSONArray a = Store.arr(c, "recq");
        JSONArray b = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !id.equals(x.optString("id"))) b.put(x);
        }
        Store.putArr(c, "recq", b);
    }

    /** v4.9 예전 버전(v4.8 이하)이 설정 때문에 버린 녹음 (최근 7일 · 녹음 기록 상태 'cfg') → 한 번 다시 찾아서 올림 */
    static boolean needRecover(Context c) {
        if (Store.getLong(c, "recRecover49") > 0) return false;
        JSONArray lg = Store.arr(c, "recLog");
        for (int i = 0; i < lg.length(); i++) {
            JSONObject e = lg.optJSONObject(i);
            if (e != null && "cfg".equals(e.optString("state"))) return true;
        }
        return false;
    }

    static int recoverCfg(Context c) {
        JSONArray lg = Store.arr(c, "recLog"), recent = Store.arr(c, "recent"), q = Store.arr(c, "recq");
        long now = System.currentTimeMillis();
        int n = 0;
        for (int i = 0; i < lg.length(); i++) {
            JSONObject e = lg.optJSONObject(i);
            if (e == null || !"cfg".equals(e.optString("state")) || now - e.optLong("t0") > CFG_KEEP_MS) continue;
            String id = e.optString("id");
            boolean queued = false;
            for (int k = 0; k < q.length(); k++) { JSONObject x = q.optJSONObject(k); if (x != null && id.equals(x.optString("id"))) queued = true; }
            if (queued) continue;
            JSONObject r = null;
            for (int k = 0; k < recent.length(); k++) { JSONObject x = recent.optJSONObject(k); if (x != null && id.equals(x.optString("id"))) r = x; }
            if (r == null || r.optString("phone").isEmpty()) continue;
            long t0 = e.optLong("t0") > 0 ? e.optLong("t0") : Fmt.parseIso(r.optString("startedAt"), 0);
            long dur = r.optLong("dur", e.optLong("dur", 0));
            if (t0 <= 0 || dur <= 0) continue;
            try {
                JSONObject job = new JSONObject();
                job.put("id", id);
                job.put("customerId", r.optString("customerId"));
                job.put("customerName", r.optString("name", e.optString("name")));
                job.put("phone", r.optString("phone"));
                job.put("t0", t0);
                job.put("tEnd", t0 + dur * 1000L + 60000L);
                job.put("dur", dur);
                job.put("tries", 0);
                queueAdd(c, job);
                logRec(c, job, "find", "녹음 파일 다시 찾는 중");
                n++;
            } catch (Exception ignore) {
                // 그 통화는 빼고
            }
        }
        Store.putLong(c, "recRecover49", now);
        return n;
    }

    /** 모아 둔 녹음 다시 올리기 (통화 끝날 때 · 앱 열 때) */
    static void flush(final Context c) {
        if (Store.arr(c, "recq").length() == 0 && Store.arr(c, "attachq").length() == 0 && !needRecover(c)) return;
        REC_EX.execute(new Runnable() {
            @Override
            public void run() {
                JSONArray pa = Store.arr(c, "attachq");   // 붙이기만 남은 것
                for (int i = 0; i < pa.length(); i++) tryPatch(c, pa.optString(i));
                if (!on(c)) return;
                JSONArray q = Store.arr(c, "recq");
                if (q.length() > 0 || needRecover(c)) Api.cfgRefreshIfOld(c, 60L * 1000L);   // v4.9 강CRM에서 녹음 백업을 막 켰으면 바로 (1분마다 한 번)
                if (needRecover(c) && canRead(c) && cfgBlock(Api.cfgOrCached(c)).isEmpty()) {   // v4.9 예전에 설정 때문에 버린 녹음
                    recoverCfg(c);
                    q = Store.arr(c, "recq");
                }
                long now = System.currentTimeMillis();
                for (int i = 0; i < q.length(); i++) {
                    JSONObject job = q.optJSONObject(i);
                    if (job == null) continue;
                    if (!job.has("uri") && now - job.optLong("tEnd") < 180000L) continue;   // 방금 끝난 통화는 따로 올리는 중
                    if (!runJob(c, job, 1)) return;
                }
            }
        });
    }
}
