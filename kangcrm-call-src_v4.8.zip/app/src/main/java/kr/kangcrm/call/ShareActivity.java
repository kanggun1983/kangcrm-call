package kr.kangcrm.call;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 📤 v3 다른 앱(에이닷 · 녹음기 등)에서 [공유] → '콜매니저'
 *  · 녹음 파일 → 고른 통화에 붙여 대표님 드라이브로 (AI 요약 · ▶ 듣기)
 *  · 대본 글 → 고른 통화 기록에 'extText'로 (강CRM 녹음 화면에 보임 · AI 요약)
 *  · 번호가 글 · 파일 이름에 있으면 그 고객 통화를 맨 위에 ⭐
 */
public class ShareActivity extends Activity {
    private Uri stream;
    private String mime = "", fname = "", text = "", phone = "";
    private long size;
    private LinearLayout list;
    private TextView info;
    private boolean busy;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Intent i = getIntent();
        if (i != null && Intent.ACTION_SEND.equals(i.getAction())) {
            try {
                stream = i.getParcelableExtra(Intent.EXTRA_STREAM);
            } catch (Throwable t) {
                stream = null;
            }
            CharSequence t = i.getCharSequenceExtra(Intent.EXTRA_TEXT);
            text = t == null ? "" : t.toString().trim();
            String sub = i.getStringExtra(Intent.EXTRA_SUBJECT);
            mime = i.getType() == null ? "" : i.getType();
            if (stream != null) readMeta(stream);
            phone = findPhone((sub == null ? "" : sub) + " " + text + " " + fname);
        }
        build();
    }

    private void readMeta(Uri u) {
        Cursor cur = null;
        try {
            cur = getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE}, null, null, null);
            if (cur != null && cur.moveToFirst()) {
                fname = cur.getString(0) == null ? "" : cur.getString(0);
                size = cur.getLong(1);
            }
        } catch (Throwable t) {
            Log.w("KC", "share meta", t);
        } finally {
            if (cur != null) cur.close();
        }
        if (fname.isEmpty()) fname = "녹음.m4a";
        String t = getContentResolver().getType(u);
        if (t != null && !t.isEmpty()) mime = t;
    }

    static String findPhone(String s) {
        Matcher m = Pattern.compile("01[016789][\\s.-]?\\d{3,4}[\\s.-]?\\d{4}").matcher(s == null ? "" : s);
        return m.find() ? Fmt.digits(m.group()) : "";
    }

    private void build() {
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, Ui.dp(this, 20), p, Ui.dp(this, 24));
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        box.addView(Ui.text(this, "📤 강CRM 통화에 붙이기", 22, Ui.INK, true));
        StringBuilder got = new StringBuilder();
        if (stream != null) got.append("🎙 녹음 파일 ").append(fname).append(size > 0 ? String.format(java.util.Locale.US, " (%.1fMB)", size / 1048576.0) : "");
        if (!text.isEmpty()) got.append(got.length() > 0 ? "\n" : "").append("📝 글 ").append(text.length()).append("자");
        if (got.length() == 0) got.append("붙일 게 없어요 (녹음 파일이나 글을 공유해 주세요)");
        if (!phone.isEmpty()) got.append("\n📞 ").append(Fmt.phone(phone)).append(" (공유한 내용에서 찾음)");
        info = Ui.text(this, got.toString(), 14, Ui.GRAY, false);
        box.addView(info, Ui.full(this, 6));
        if (!Store.paired(this)) {
            box.addView(Ui.text(this, "먼저 강CRM과 연결해 주세요 (콜매니저 → 설정 → 강CRM 연결).", 15, Ui.RED, true), Ui.full(this, 14));
            setContentView(sv);
            return;
        }
        box.addView(Ui.text(this, "어느 통화에 붙일까요?", 16, Ui.INK, true), Ui.full(this, 16));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        box.addView(list);
        fillList();
        Button cancel = Ui.button(this, "취소", false);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        box.addView(cancel, Ui.full(this, 16));
        box.addView(Ui.text(this, "녹음은 대표님 드라이브 '강CRM 녹음'에 올라가고, 강CRM 고객카드 📞 통화에서 듣기 · 🤖 AI 요약이 돼요. 글은 그 통화의 '공유한 대본'으로 보여요.", 13, Ui.GRAY, false), Ui.full(this, 10));
        setContentView(sv);
    }

    /** 최근 강CRM 고객 통화 (이 폰) · 번호가 같으면 ⭐ 맨 위 · 그 번호 고객 '새 기록' */
    private void fillList() {
        list.removeAllViews();
        JSONArray a = Store.arr(this, "recent");
        boolean any = false;
        java.util.List<JSONObject> rows = new java.util.ArrayList<>();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !"missed".equals(o.optString("direction")) && !"noanswer".equals(o.optString("direction"))) rows.add(o);
        }
        if (!phone.isEmpty()) {   // 번호가 같은 통화를 위로
            java.util.List<JSONObject> hit = new java.util.ArrayList<>(), rest = new java.util.ArrayList<>();
            for (JSONObject o : rows) (phone.equals(o.optString("phone")) ? hit : rest).add(o);
            hit.addAll(rest);
            rows = hit;
        }
        for (final JSONObject o : rows) {
            any = true;
            boolean star = !phone.isEmpty() && phone.equals(o.optString("phone"));
            String d = o.optString("direction");
            String dur = Fmt.dur(o.optLong("dur", 0));
            String label = (star ? "⭐ " : "") + Fmt.hm(o.optLong("at")) + " · " + o.optString("name") + " · " + ("in".equals(d) ? "받은 전화" : "건 전화") + (dur.isEmpty() ? "" : " " + dur);
            Button bt = Ui.button(this, label, star);
            bt.setGravity(android.view.Gravity.START | android.view.Gravity.CENTER_VERTICAL);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    attachTo(o.optString("id"), o.optString("name"), o.optString("phone"), LastCall.ms(o.optString("startedAt")), false, null);
                }
            });
            list.addView(bt, Ui.full(this, 6));
        }
        if (!phone.isEmpty()) {
            Button nw = Ui.button(this, "➕ " + Fmt.phone(phone) + " 고객의 새 기록으로 붙이기", false);
            nw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    newRecord();
                }
            });
            list.addView(nw, Ui.full(this, 10));
        }
        if (!any && phone.isEmpty()) list.addView(Ui.text(this, "이 폰의 최근 강CRM 고객 통화가 없어요. 번호가 들어간 녹음 · 글을 공유하면 그 고객 새 기록으로 붙일 수 있어요.", 14, Ui.GRAY, false), Ui.full(this, 6));
    }

    /** 그 번호 고객을 찾아 '공유로 붙인 통화' 기록 하나 만들기 (연락 기록에는 다시 안 넣음) */
    private void newRecord() {
        if (busy) return;
        busy = true;
        info.setText("강CRM에서 " + Fmt.phone(phone) + " 고객 찾는 중…");
        final Context app = getApplicationContext();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                JSONObject log = null;
                String err = "";
                try {
                    JSONObject cu = Api.findCustomer(app, phone);
                    if (cu == null) err = "강CRM에 이 번호 고객이 없어요";
                    else {
                        long t0 = System.currentTimeMillis();
                        log = CallFlow.baseLog(app, new Cust(cu), phone, "out", t0, 0);
                        log.put("src", "share");
                        log.put("applied", Boolean.TRUE);   // 연락 기록에는 이미 있는 통화라 다시 안 넣음
                        log.put("appliedBy", "share");
                        log.put("result", "");
                    }
                } catch (Exception e) {
                    err = "인터넷을 확인해 주세요 (" + e.getClass().getSimpleName() + ")";
                }
                final JSONObject fl = log;
                final String fe = err;
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        busy = false;
                        if (fl == null) {
                            info.setText("❌ " + fe);
                            return;
                        }
                        attachTo(fl.optString("id"), fl.optString("customerName"), phone, System.currentTimeMillis(), true, fl);
                    }
                });
            }
        });
    }

    private void attachTo(final String id, final String name, final String ph, final long t0, final boolean isNew, final JSONObject newLog) {
        if (busy) return;
        busy = true;
        info.setText("붙이는 중…");
        final Context app = getApplicationContext();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                String msg;
                try {
                    File f = null;
                    if (stream != null) f = copyIn(stream);
                    if (isNew && newLog != null) {
                        if (f != null) {
                            long dur = durationSec(f);
                            if (dur > 0) newLog.put("durationSec", Long.valueOf(dur));
                        }
                        CallFlow.save(app, newLog);
                    }
                    if (!text.isEmpty()) {
                        JSONObject add = new JSONObject();
                        add.put("extText", text.length() > 12000 ? text.substring(0, 12000) : text);
                        add.put("extAt", Fmt.iso(System.currentTimeMillis()));
                        RecBackup.attach(app, id, add);
                    }
                    if (f != null) {
                        JSONObject job = new JSONObject();
                        job.put("id", id);
                        job.put("customerName", name);
                        job.put("phone", ph);
                        job.put("t0", t0 > 0 ? t0 : System.currentTimeMillis());
                        job.put("tEnd", System.currentTimeMillis());
                        job.put("uri", Uri.fromFile(f).toString());
                        job.put("mime", mime.startsWith("audio/") ? mime : "audio/mp4");
                        job.put("size", f.length());
                        job.put("fname", fname);
                        job.put("tries", 0);
                        RecBackup.startShared(app, job);
                    }
                    msg = "✅ " + name + " 통화에 붙였어요" + (stream != null ? " · 녹음은 올리는 중" : "");
                } catch (Exception e) {
                    Log.w("KC", "share attach", e);
                    msg = "❌ 붙이지 못했어요 (" + e.getClass().getSimpleName() + ")";
                }
                final String fm = msg;
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(app, fm, Toast.LENGTH_LONG).show();
                        finish();
                    }
                });
            }
        });
    }

    /** 공유받은 파일은 잠깐만 읽을 수 있어서 이 앱 안에 복사 (올린 뒤 지움) */
    private File copyIn(Uri u) throws Exception {
        if (size > RecBackup.MAX_BYTES) throw new Exception("20MB 넘음");
        int dot = fname.lastIndexOf('.');
        String ext = dot > 0 && fname.length() - dot <= 5 ? fname.substring(dot) : ".m4a";
        File out = new File(getCacheDir(), "share_" + System.currentTimeMillis() + ext);
        InputStream in = getContentResolver().openInputStream(u);
        if (in == null) throw new Exception("파일을 열 수 없어요");
        OutputStream os = new FileOutputStream(out);
        byte[] buf = new byte[16384];
        long total = 0;
        int n;
        try {
            while ((n = in.read(buf)) > 0) {
                total += n;
                if (total > RecBackup.MAX_BYTES) throw new Exception("20MB 넘음");
                os.write(buf, 0, n);
            }
        } finally {
            in.close();
            os.close();
        }
        return out;
    }

    static long durationSec(File f) {
        MediaMetadataRetriever r = new MediaMetadataRetriever();
        try {
            r.setDataSource(f.getAbsolutePath());
            String d = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            return d == null ? 0 : Long.parseLong(d) / 1000L;
        } catch (Throwable t) {
            return 0;
        } finally {
            try {
                r.release();
            } catch (Throwable ignore) {
                // 괜찮음
            }
        }
    }
}
