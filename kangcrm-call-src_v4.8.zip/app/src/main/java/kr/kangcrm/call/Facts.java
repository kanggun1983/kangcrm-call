package kr.kangcrm.call;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 📋 v3 팝업 · 결과 창에 보일 '폰 정보' (강CRM 고객카드와 같은 계산)
 *  개통일 · 몇 개월째 / 남은 할부 · 끝나는 달 / 이중할부 / 약정 종료 D-day / 결합 · 복지 / 인터넷 · TV 만료
 *  / 🔔 기변 시기 (약정 · 할부가 3개월 안에 끝남) / 🎂 생일 7일 안 / 📄 미비서류
 *  / v4.2: 약정 칸 · 📄 공통지원금 금액 · 🏷 유통망지원금 191일 · 💸 지금 바꾸면 (강CRM V225 위약금 공식)
 */
final class Facts {
    private Facts() {}

    static final int NORMAL = 0, WARN = 1, ALERT = 2;

    static final class Line {
        final String text;
        final int tone;

        Line(String text, int tone) {
            this.text = text;
            this.tone = tone;
        }
    }

    // ── 날짜 (기기 시간 · 자정 기준) ──
    static Calendar today() {
        Calendar t = Calendar.getInstance();
        t.set(Calendar.HOUR_OF_DAY, 0);
        t.set(Calendar.MINUTE, 0);
        t.set(Calendar.SECOND, 0);
        t.set(Calendar.MILLISECOND, 0);
        return t;
    }

    static Calendar parse(String ymd) {
        if (ymd == null) return null;
        Matcher m = Pattern.compile("^(\\d{4})-(\\d{2})-(\\d{2})").matcher(ymd.trim());
        if (!m.find()) return null;
        Calendar c = Calendar.getInstance();
        c.clear();
        c.set(Integer.parseInt(m.group(1)), Integer.parseInt(m.group(2)) - 1, Integer.parseInt(m.group(3)));
        return c;
    }

    static String dot(Calendar c) {
        return String.format(Locale.US, "%04d.%02d.%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH));
    }

    static String ym(Calendar c) {
        return String.format(Locale.US, "%04d.%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1);
    }

    static long daysBetween(Calendar a, Calendar b) {
        return Math.round((b.getTimeInMillis() - a.getTimeInMillis()) / 86400000.0);
    }

    /** 강CRM getMonthsPassedSince */
    static int monthsPassed(String ymd, Calendar now) {
        Calendar b = parse(ymd);
        if (b == null) return 0;
        int p = (now.get(Calendar.YEAR) - b.get(Calendar.YEAR)) * 12 + (now.get(Calendar.MONTH) - b.get(Calendar.MONTH));
        if (now.get(Calendar.DAY_OF_MONTH) < b.get(Calendar.DAY_OF_MONTH)) p--;
        return Math.max(0, p);
    }

    static Calendar addMonths(Calendar c, int n) {
        Calendar x = (Calendar) c.clone();
        x.add(Calendar.MONTH, n);
        return x;
    }

    /** 강CRM parseInstallmentMonths (완납 = 0 · 없으면 -1) */
    static int months(String s) {
        if (s == null) return -1;
        if (s.contains("완납") || s.contains("일시불")) return 0;
        Matcher m = Pattern.compile("\\d+").matcher(s);
        return m.find() ? Integer.parseInt(m.group()) : -1;
    }

    /** 강CRM parseKoreanAmount (만 · 천 단위 · 첫 숫자 덩어리) */
    static long amount(String str) {
        if (str == null) return -1;
        String s = str.replaceAll("\\s+", "");
        if (!s.matches(".*\\d.*")) return -1;
        Matcher man = Pattern.compile("([\\d,.]+)만(?:([\\d,]+)천|([\\d,]+))?").matcher(s);
        if (man.find()) {
            try {
                long a = Math.round(Double.parseDouble(man.group(1).replace(",", "")) * 10000);
                if (man.group(2) != null) a += Long.parseLong(man.group(2).replace(",", "")) * 1000;
                else if (man.group(3) != null) a += Long.parseLong(man.group(3).replace(",", ""));
                return a;
            } catch (NumberFormatException e) {
                return -1;
            }
        }
        Matcher f = Pattern.compile("\\d[\\d,]*").matcher(s);
        if (!f.find()) return -1;
        try {
            return Long.parseLong(f.group().replace(",", ""));
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    static String won(long v) {
        return new DecimalFormat("#,###").format(v) + "원";
    }

    /** 유통망지원금 유지일 (개통일 + 191일 · 강CRM V225 매장 규칙) */
    static final int DIST_KEEP_DAYS = 191;

    /** 강CRM wonMan (40만 · 12.8만 · 1만 미만은 원) */
    static String man(long n) {
        long a = Math.abs(n);
        if (a < 10000) return won(n);
        DecimalFormat f = new DecimalFormat(a >= 10000000 ? "#,###" : "#,##0.#");
        f.setRoundingMode(java.math.RoundingMode.HALF_UP);
        return (n < 0 ? "-" : "") + f.format(a / 10000.0) + "만";
    }

    /** 약정 개월: 약정 칸(무약정 = 0) → 할인 유형 글자 → 24 (강CRM changeNowInfo) */
    static int termOf(String termTxt, String dt) {
        String t = termTxt == null ? "" : termTxt;
        if (t.contains("무약정")) return 0;
        Matcher m = Pattern.compile("\\d+").matcher(t);
        if (m.find()) return Integer.parseInt(m.group());
        Matcher d = Pattern.compile("(\\d+)\\s*개월").matcher(dt == null ? "" : dt);
        if (d.find()) return Integer.parseInt(d.group(1));
        return 24;
    }

    /** 강CRM carrierKeepKey */
    static String carKey(String carrier) {
        String s = carrier == null ? "" : carrier.trim();
        if (s.equals("SKT")) return "SKT";
        if (s.equals("KT")) return "KT";
        if (s.equals("LG U+")) return "LGU";
        return "ETC";
    }

    /** 통신사 공식: free일 안이면 전액 · 그 뒤 금액 × 남은 일 ÷ (약정일 − free) · 10원 버림 */
    static long back(long amt, int free, long used, long rem, long total) {
        if (amt <= 0) return 0;
        if (used < free) return amt;
        if (rem > 0 && total > free) return Math.max(0, (long) Math.floor(amt * (double) rem / (total - free) / 10) * 10);
        return 0;
    }

    /** 월요금: 개통등록 월요금(planFee) → 고객카드 '월 요금' 글자 */
    static long feeOf(Cust c) {
        long p = amount(c.s("planFee"));
        if (p > 0) return p;
        String t = c.s("fee").replaceAll("\\s+", "").replaceFirst("^월", "");
        if (!t.matches("^[\\d,.]+(만([\\d,]+천?)?)?원?$")) return 0;
        return Math.max(0, amount(t));
    }

    static boolean meaningful(String v) {
        if (v == null) return false;
        String t = v.trim();
        return !t.isEmpty() && !t.equals("-") && !t.contains("해당없음") && !t.contains("미적용") && !t.equals("없음") && !t.equals("미정");
    }

    /** 강CRM getInstallmentBaseInfo → [기준일, 확실하지 않으면 "?"] */
    static String[] instBase(Cust c) {
        String b = c.s("installmentBaseDate");
        if (!b.isEmpty()) return new String[]{b, ""};
        String inst = c.s("installment"), rp = c.s("repPrincipal"), ri = c.s("repInstallment"), visit = c.s("visitDate"), act = c.s("activationDate");
        boolean report = !inst.isEmpty() && !(rp.isEmpty() && ri.isEmpty()) && !inst.contains("완납");
        if (report) {
            int slash = inst.indexOf('/');
            long ia = amount(slash >= 0 ? inst.substring(0, slash) : inst);
            int im = slash >= 0 ? months(inst.substring(slash + 1)) : -1;
            report = ia == amount(rp) && im == months(ri);
        }
        if (report && !visit.equals(act)) {
            if (!act.isEmpty() && act.compareTo(visit) > 0) return new String[]{act, ""};
            return new String[]{visit, "?"};
        }
        return new String[]{visit, ""};
    }

    static final class Inst {
        boolean done;
        long left = -1;
        int monthsLeft;
        Calendar end;
        boolean unsure;
        boolean valid;
    }

    /** 할부 한 줄 계산 (강CRM getDynamicInstallment) */
    static Inst inst(String s0, String base, boolean unsure, Calendar now) {
        Inst r = new Inst();
        String s = s0 == null ? "" : s0.trim();
        if (s.isEmpty() || s.equals("-") || s.contains("해당없음")) return r;
        r.valid = true;
        if (s.contains("완납") || s.contains("일시불")) {
            r.done = true;
            return r;
        }
        int slash = s.indexOf('/');
        if (slash < 0) {
            r.valid = false;
            return r;
        }
        int m = months(s.substring(slash + 1));
        if (m == 0) {
            r.done = true;
            return r;
        }
        if (m < 0) {
            r.valid = false;
            return r;
        }
        int passed = monthsPassed(base, now);
        int remain = m - passed;
        if (remain <= 0) {
            r.done = true;
            return r;
        }
        r.monthsLeft = remain;
        long amt = amount(s.substring(0, slash));
        if (amt > 0) r.left = (long) Math.floor((double) amt / m * remain);
        Calendar b = parse(base);
        if (b != null && !unsure) r.end = addMonths(b, m);
        r.unsure = unsure;
        return r;
    }

    static List<Line> of(JSONObject d) {
        return of(new Cust(d), today());
    }

    static List<Line> of(Cust c, Calendar now) {
        List<Line> out = new ArrayList<>();
        Calendar act = parse(c.s("activationDate"));
        Calendar latestEnd = null;
        boolean anyEnd = false, allDone = true;

        // 📅 개통
        if (act != null) {
            long days = daysBetween(act, now);
            long months = days > 0 ? (long) Math.floor(days / 30.416) : 0;
            String age = months >= 1 ? months + "개월째" : (days <= 0 ? "오늘 개통" : "개통 " + days + "일째");
            out.add(new Line("📅 개통 " + dot(act) + " · " + age, NORMAL));
        }

        // 💳 할부
        String[] base = instBase(c);
        Inst i1 = inst(c.s("installment"), base[0], !base[1].isEmpty(), now);
        if (i1.valid) {
            anyEnd = true;
            if (i1.done) {
                out.add(new Line("💳 할부 완납", NORMAL));
            } else {
                allDone = false;
                StringBuilder b = new StringBuilder("💳 할부 ");
                if (i1.left > 0) b.append("약 ").append(won(i1.left)).append(" · ");
                b.append(i1.monthsLeft).append("개월 남음");
                if (i1.end != null) b.append(" (").append(ym(i1.end)).append(" 끝)");
                if (i1.unsure) b.append(" · 기준일 확인");
                out.add(new Line(b.toString(), NORMAL));
                if (i1.end != null && (latestEnd == null || i1.end.after(latestEnd))) latestEnd = i1.end;
            }
        }
        String base2 = c.s("installment2BaseDate");
        if (base2.isEmpty()) base2 = base[0];
        Inst i2 = inst(c.s("installment2"), base2, false, now);
        if (i2.valid && !i2.done) {
            allDone = false;
            StringBuilder b = new StringBuilder("💳 이중할부 ");
            if (i2.left > 0) b.append("약 ").append(won(i2.left)).append(" · ");
            b.append(i2.monthsLeft).append("개월 남음");
            if (i2.end != null) b.append(" (").append(ym(i2.end)).append(" 끝)");
            out.add(new Line(b.toString(), NORMAL));
            if (i2.end != null && (latestEnd == null || i2.end.after(latestEnd))) latestEnd = i2.end;
        }

        // 📄 약정 (v4.2: 약정 개월 = 고객카드 약정 칸 → 할인 유형 글자 → 24개월 · 강CRM changeNowInfo와 같게)
        String dt = c.s("discountType");
        boolean pubMode = dt.contains("공시") || dt.contains("공통");
        boolean selMode = !pubMode && (dt.contains("선택") || dt.contains("선약"));
        int term = termOf(c.s("contractTerm"), dt);
        long pub = Math.max(0, amount(c.s("publicSupport"))), dist = Math.max(0, amount(c.s("distSupport")));
        long used = act != null ? Math.max(0, daysBetween(act, now)) : 0, total = 0, rem = 0;
        Calendar cEnd = null;
        String head = pubMode ? "📄 공통지원금" + (pub > 0 ? " " + man(pub) : "") : "📄 선택약정";
        if ((pubMode || selMode) && act != null && term > 0) {
            anyEnd = true;
            cEnd = addMonths(act, term);
            total = Math.max(1, daysBetween(act, cEnd));
            rem = Math.max(0, daysBetween(now, cEnd));
            if (rem > 0) {
                allDone = false;
                out.add(new Line(head + (pubMode ? " · " : " ") + term + "개월 · " + dot(cEnd) + " 끝 (D-" + rem + ")", NORMAL));
                if (latestEnd == null || cEnd.after(latestEnd)) latestEnd = cEnd;
            } else {
                out.add(new Line(head + " 끝남 (" + dot(cEnd) + ")", NORMAL));
            }
        } else if (pubMode || selMode) {
            if (act != null) anyEnd = true;   // 무약정
            out.add(new Line(head, NORMAL));
        } else if (dt.contains("해당없음") || dt.contains("무약정") || dt.contains("만료")) {
            anyEnd = true;
            out.add(new Line("📄 약정 없음", NORMAL));
        }

        // 🏷 유통망지원금 · 💸 지금 바꾸면 (통신 3사 공식 · 유통망 191일 · 강CRM V225와 같은 계산)
        if (dist > 0) {
            String t = "🏷 유통망지원금 " + man(dist);
            if (act != null && used < DIST_KEEP_DAYS) {
                Calendar k = (Calendar) act.clone();
                k.add(Calendar.DAY_OF_MONTH, DIST_KEEP_DAYS);
                t += " · " + dot(k) + "까지 유지 (" + DIST_KEEP_DAYS + "일)";
            }
            out.add(new Line(t, NORMAL));
        }
        if (act != null && rem > 0) {
            boolean big3 = !"ETC".equals(carKey(c.s("carrier")));
            int free = term <= 12 ? 90 : 180;
            long pubBack = pubMode && big3 ? back(pub, free, used, rem, total) : 0;
            long fee = feeOf(c), selGot = selMode && fee > 0 ? Math.round(fee * 0.25 * Math.min(used, total) / (365.0 / 12)) : 0;
            long selBack = selMode && big3 ? back(selGot, free, used, rem, total) : 0;
            long distBack = back(dist, DIST_KEEP_DAYS, used, rem, total);
            List<String> parts = new ArrayList<>(), unknown = new ArrayList<>();
            if (pubBack > 0) parts.add("공통 " + man(pubBack));
            if (selBack > 0) parts.add("선약 " + man(selBack));
            if (distBack > 0) parts.add("유통망 " + man(distBack));
            if (!big3 && (pubMode || selMode)) unknown.add(c.s("carrier").isEmpty() ? "통신사 칸이 비어 있어 통신사 조회" : "알뜰폰 위약금은 통신사 조회");
            else if (pubMode && pub <= 0) unknown.add("공통지원금 금액을 넣으면 계산돼요");
            else if (selMode && fee <= 0) unknown.add("월요금을 넣으면 할인반환금 계산돼요");
            if (!parts.isEmpty()) {
                long sum = pubBack + selBack + distBack;
                if (i1.valid && !i1.done && i1.left > 0) {
                    parts.add("할부 " + man(i1.left));
                    sum += i1.left;
                }
                out.add(new Line("💸 지금 바꾸면 약 " + man(sum) + " (" + String.join(" + ", parts) + ")" + (unknown.isEmpty() ? "" : " · " + unknown.get(0)), WARN));
            } else if (!unknown.isEmpty()) {
                out.add(new Line("💸 위약금: " + unknown.get(0), NORMAL));
            }
        }

        // 🔔 기변 시기 (약정 · 할부가 3개월 안에 끝남 · 다 끝남)
        if (act != null && anyEnd) {
            if (latestEnd != null) {
                long left = daysBetween(now, latestEnd);
                if (left <= 92) out.add(new Line("🔔 기변 시기 · 약정·할부 " + ym(latestEnd) + " 끝" + (left <= 0 ? "남" : ""), WARN));
            } else if (allDone) {
                out.add(new Line("🔔 기변 시기 · 약정·할부 다 끝남", WARN));
            }
        }

        // 👨‍👩‍👧 결합 · 복지 · 요금
        List<String> mix = new ArrayList<>();
        if (meaningful(c.s("combination"))) mix.add("결합 " + c.s("combination"));
        if (meaningful(c.s("welfare"))) mix.add("복지 " + c.s("welfare"));
        if (meaningful(c.s("fee"))) mix.add("월 " + c.s("fee"));
        if (!mix.isEmpty()) out.add(new Line("👨‍👩‍👧 " + String.join(" · ", mix), NORMAL));

        // 🏠 인터넷 · TV (36개월 만료)
        List<String> wired = new ArrayList<>();
        if (meaningful(c.s("internetProd"))) wired.add(c.s("internetProd"));
        if (meaningful(c.s("tvProd"))) wired.add(c.s("tvProd"));
        if (!wired.isEmpty()) {
            Calendar w = parse(c.s("wiredDate"));
            String t = "🏠 " + String.join("+", wired);
            int tone = NORMAL;
            if (w != null) {
                Calendar end = addMonths(w, 36);
                long left = daysBetween(now, end);
                t += left < 0 ? " · 만료됨" : " · 만료 " + dot(end) + " (D-" + left + ")";
                if (left <= 90) tone = WARN;
            }
            out.add(new Line(t, tone));
        }

        // 🎂 생일 7일 안
        int bd = birthdayIn(c.s("dob"), now);
        if (bd == 0) out.add(new Line("🎂 오늘 생일이에요!", WARN));
        else if (bd > 0 && bd <= 7) out.add(new Line("🎂 생일 D-" + bd, WARN));

        // 📄 미비서류
        String md = c.s("missingDocs");
        if (meaningful(md)) out.add(new Line("📄 미비서류: " + (md.length() > 40 ? md.substring(0, 40) + "…" : md), ALERT));
        return out;
    }

    /** 강CRM parseBirth + getDaysUntilBirthday (없으면 -1) */
    static int birthdayIn(String dob, Calendar now) {
        if (dob == null || dob.trim().isEmpty() || dob.trim().equals("-")) return -1;
        String digits = dob.split("\\(")[0].replaceAll("[^0-9]", "");
        int m, d;
        if (digits.length() == 8) {
            m = Integer.parseInt(digits.substring(4, 6));
            d = Integer.parseInt(digits.substring(6, 8));
        } else if (digits.length() == 6) {
            m = Integer.parseInt(digits.substring(2, 4));
            d = Integer.parseInt(digits.substring(4, 6));
        } else {
            return -1;
        }
        if (m < 1 || m > 12 || d < 1 || d > 31) return -1;
        Calendar next = on(now.get(Calendar.YEAR), m, d);
        if (next.before(now)) next = on(now.get(Calendar.YEAR) + 1, m, d);
        return (int) daysBetween(now, next);
    }

    private static Calendar on(int y, int m, int d) {
        Calendar x = Calendar.getInstance();
        x.clear();
        x.set(y, m - 1, 1);
        x.set(Calendar.DAY_OF_MONTH, Math.min(d, x.getActualMaximum(Calendar.DAY_OF_MONTH)));
        return x;
    }

    /** 결과 창으로 넘길 모양 ["1|🔔 기변 시기 …", …] */
    static JSONArray toJson(List<Line> lines) {
        JSONArray a = new JSONArray();
        for (Line l : lines) a.put(l.tone + "|" + l.text);
        return a;
    }

    static List<Line> fromJson(String s) {
        List<Line> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(s == null || s.isEmpty() ? "[]" : s);
            for (int i = 0; i < a.length(); i++) {
                String x = a.optString(i, "");
                int bar = x.indexOf('|');
                if (bar <= 0) continue;
                int tone;
                try {
                    tone = Integer.parseInt(x.substring(0, bar));
                } catch (NumberFormatException e) {
                    tone = NORMAL;
                }
                out.add(new Line(x.substring(bar + 1), tone));
            }
        } catch (Exception ignore) {
            // 없음
        }
        return out;
    }
}
