package kr.kangcrm.call;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

/** 전화를 끊으면 뜨는 '통화 결과' 창 → 강CRM 연락 기록 · 약속으로 */
public class ResultActivity extends Activity {
    // 강CRM의 '통화 결과'와 같은 버튼 (영업상태도 똑같이 바뀜)
    private static final String[] KEYS = {"done", "interest", "visit", "refuse"};
    private static final String[] RESULTS = {"통화 완료", "관심 있음", "방문약속", "거부"};
    private static final String[] ICONS = {"✅", "🙂", "🏪", "🙅"};
    // ✍️ v3 빠른 메모 (누르면 메모 칸에 붙음)
    private static final String[] QUICK = {"견적 문자 보냄", "가족과 상의", "재연락 요청", "방문 예정", "기변 문의", "요금 문의", "부재 · 문자 남김", "명함 보냄"};
    private static final String[] HINTS = {
            "영업상태는 그대로 두고 통화 기록만 남겨요.",
            "영업상태가 '가망고객'으로 바뀌어요.",
            "영업상태가 '방문약속'으로 바뀌어요. 날짜를 고르면 방문 약속으로 잡혀요.",
            "영업상태가 '고객거부'로 바뀌고 타겟 목록에서 빠져요."};

    private JSONObject log;
    private boolean test;
    private String result = "", resultKey = "";
    private TextView hint;
    private String nextDate = "";
    private EditText memo;
    private TextView dateBtn;
    private final List<Button> resultBtns = new ArrayList<>();
    private boolean saving;

    // ── 📵 v4.6 부재 재연락 (명함 문자) ──
    private static final String[] MISS_KEYS = {"done", "interest", "missed"};
    private static final String[] MISS_RESULTS = {"통화 완료", "관심 있음", "부재중"};
    private static final String[] MISS_BTNS = {"✅ 통화 완료", "🙂 관심 있음", "📵 부재"};
    private static final int ORANGE = Color.parseColor("#C2410C"), ORANGE_DARK = Color.parseColor("#7C2D12"), ORANGE_LINE = Color.parseColor("#FDBA74");
    private String missKey = "missed", missWhen = "", missLabel = "";
    private boolean missDeny;
    private long missBase;
    private JSONObject missCfg = new JSONObject();
    private EditText missPhrase;
    private TextView missInfo;
    private Button missSaveBtn;
    private LinearLayout missBox;
    private final List<Button> missResBtns = new ArrayList<>();
    private final List<Button> missReasonBtns = new ArrayList<>();
    private final List<String> missReasonLabels = new ArrayList<>();
    private final List<Button> missWhenBtns = new ArrayList<>();
    private long missAtMs;                 // ⏰ v4.7 직접 고른 시각
    private Button missCustomBtn;
    private boolean missAd = true, missAdToggle, missAdInit;   // 📢 v4.7 (광고) 표시

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        load(getIntent());
        build();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        load(intent);
        build();
    }

    private void load(Intent i) {
        test = i != null && i.getBooleanExtra("test", false);
        try {
            log = new JSONObject(i == null ? "{}" : i.getStringExtra("log"));
        } catch (Exception e) {
            log = new JSONObject();
        }
        result = "";
        resultKey = "";
        nextDate = "";
        saving = false;
        missKey = "missed";
        missWhen = "";
        missLabel = "";
        missAtMs = 0;
        missAdInit = false;
    }

    private void build() {
        resultBtns.clear();
        if (log.has("_miss")) {   // 📵 v4.6 건 전화를 안 받음 → 자동 재연락 고르기
            buildMiss();
            return;
        }
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.setFillViewport(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, Ui.dp(this, 24), p, Ui.dp(this, 24));
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        String dir = log.optString("direction");
        String head = "in".equals(dir) ? "📲 받은 전화" : "📞 건 전화";
        String dur = Fmt.dur(log.optLong("durationSec", 0));
        box.addView(Ui.text(this, head + (dur.isEmpty() ? "" : " · " + dur) + (test ? " · 시험" : ""), 15, Ui.INDIGO, true));

        box.addView(whoCard(), Ui.full(this, 10));

        box.addView(Ui.text(this, "통화 결과", 15, Ui.INK, true), Ui.full(this, 18));
        LinearLayout grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < 2; r++) {
            LinearLayout row = Ui.row(this);
            for (int k = 0; k < 2; k++) {
                final int idx = r * 2 + k;
                final Button bt = Ui.button(this, ICONS[idx] + " " + RESULTS[idx], false);
                bt.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        pick(idx);
                    }
                });
                resultBtns.add(bt);
                row.addView(bt, Ui.weight(this, k == 0 ? 0 : 8));
            }
            grid.addView(row, Ui.full(this, r == 0 ? 6 : 8));
        }
        box.addView(grid);
        hint = Ui.text(this, "결과를 고르면 강CRM 영업상태와 연락 기록에 바로 반영돼요.", 13, Ui.GRAY, false);
        box.addView(hint, Ui.full(this, 8));

        box.addView(Ui.text(this, "메모", 15, Ui.INK, true), Ui.full(this, 18));
        memo = new EditText(this);
        memo.setHint("예: 견적 보내드림 · 목요일 오전에 다시 연락");
        memo.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        memo.setMinLines(3);
        memo.setGravity(Gravity.TOP | Gravity.START);
        memo.setTextSize(16);
        memo.setTextColor(Ui.INK);
        memo.setBackground(Ui.round(Color.WHITE, Color.parseColor("#D1D5DB"), 12, this));
        int mp = Ui.dp(this, 12);
        memo.setPadding(mp, mp, mp, mp);
        box.addView(memo, Ui.full(this, 6));
        LinearLayout chips = new LinearLayout(this);   // ✍️ v3 빠른 메모
        chips.setOrientation(LinearLayout.VERTICAL);
        for (int r = 0; r < QUICK.length; r += 4) {
            LinearLayout row = Ui.row(this);
            for (int k = r; k < Math.min(r + 4, QUICK.length); k++) {
                final String q = QUICK[k];
                Button ch = Ui.button(this, q, false);
                ch.setTextSize(13);
                ch.setMinHeight(Ui.dp(this, 40));
                ch.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
                ch.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        String cur = memo.getText().toString().trim();
                        if (cur.contains(q)) return;
                        memo.setText(cur.isEmpty() ? q : cur + " · " + q);
                        memo.setSelection(memo.getText().length());
                    }
                });
                row.addView(ch, Ui.weight(this, k == r ? 0 : 6));
            }
            chips.addView(row, Ui.full(this, 6));
        }
        box.addView(chips);

        box.addView(Ui.text(this, "다음 연락일 (선택 · 방문약속이면 방문 날짜)", 15, Ui.INK, true), Ui.full(this, 18));
        dateBtn = Ui.button(this, "📅 날짜 고르기", false);
        dateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pickDate();
            }
        });
        box.addView(dateBtn, Ui.full(this, 6));

        Button save = Ui.button(this, "강CRM에 저장", true);
        save.setMinHeight(Ui.dp(this, 56));
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSave(false);
            }
        });
        box.addView(save, Ui.full(this, 24));

        Button skip = Ui.button(this, "결과 없이 기록만", false);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSave(true);
            }
        });
        box.addView(skip, Ui.full(this, 8));

        TextView note = Ui.text(this, "저장하면 강CRM 고객카드의 연락 기록에 들어가요. 날짜를 고르면 약속 달력에도 들어가요. 통화 기록은 👑 대표와 이 고객 담당자만 봐요.", 13, Ui.GRAY, false);
        box.addView(note, Ui.full(this, 14));

        setContentView(sv);
    }

    /** 고객 카드 (이름 · 번호 · 📋 개통 정보 · 메모 · 지난 통화) */
    private LinearLayout whoCard() {
        LinearLayout who = Ui.card(this);
        who.addView(Ui.text(this, log.optString("customerName", "고객"), 24, Ui.INK, true));
        who.addView(Ui.text(this, Fmt.phone(log.optString("phone")), 15, Ui.GRAY, false));
        String l2 = log.optString("_line2");
        if (!l2.isEmpty()) who.addView(Ui.text(this, l2, 15, Ui.INK, true));
        String l3 = log.optString("_line3");
        if (!l3.isEmpty()) who.addView(Ui.text(this, l3, 14, Ui.GRAY, false));
        for (Facts.Line f : Facts.fromJson(log.optString("_facts"))) {   // 📋 v3 개통 · 할부 · 약정 · 기변 시기
            int col = f.tone == Facts.ALERT ? Ui.RED : (f.tone == Facts.WARN ? Color.parseColor("#B45309") : Ui.INK);
            TextView ft = Ui.text(this, f.text, 14, col, f.tone != Facts.NORMAL);
            ft.setPadding(0, Ui.dp(this, 2), 0, 0);
            who.addView(ft);
        }
        String m0 = log.optString("_memo");
        if (!m0.isEmpty()) {
            TextView mt = Ui.text(this, "📝 " + m0, 14, Ui.GRAY, false);
            mt.setMaxLines(2);
            mt.setPadding(0, Ui.dp(this, 4), 0, 0);
            who.addView(mt);
        }
        String last = log.optString("_last");
        if (!last.isEmpty()) {   // 🕘 v3 지난 통화
            TextView lt = Ui.text(this, last, 14, Ui.INK, false);
            lt.setBackground(Ui.round(Color.parseColor("#EEF2FF"), 0, 10, this));
            int lp = Ui.dp(this, 10);
            lt.setPadding(lp, Ui.dp(this, 8), lp, Ui.dp(this, 8));
            who.addView(lt, Ui.full(this, 8));
        }
        return who;
    }

    private void pick(int idx) {
        result = RESULTS[idx];
        resultKey = KEYS[idx];
        if (hint != null) hint.setText(HINTS[idx]);
        for (int i = 0; i < resultBtns.size(); i++) {
            Button bt = resultBtns.get(i);
            boolean on = i == idx;
            bt.setTextColor(on ? Color.WHITE : Ui.INK);
            bt.setBackground(Ui.round(on ? Ui.INDIGO : Color.WHITE, on ? 0 : Color.parseColor("#D1D5DB"), 12, this));
        }
        if ("visit".equals(resultKey) && nextDate.isEmpty()) pickDate();
    }

    private void pickDate() {
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        DatePickerDialog d = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int y, int m, int day) {
                nextDate = String.format(Locale.US, "%04d-%02d-%02d", y, m + 1, day);
                dateBtn.setText("📅 " + Fmt.md(nextDate) + " · 바꾸려면 누르기");
            }
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH));
        d.show();
    }

    private void doSave(boolean skipResult) {
        if (saving) return;
        saving = true;
        try {
            String m = memo.getText().toString().trim();
            log.put("result", skipResult ? "" : result);
            log.put("resultKey", skipResult ? "" : resultKey);
            log.put("memo", skipResult ? "" : m);
            String kind = "";
            if (!skipResult && !nextDate.isEmpty()) kind = "visit".equals(resultKey) ? "visit" : "call";
            log.put("nextKind", kind);
            log.put("nextDate", kind.isEmpty() ? "" : nextDate);
            log.put("at", Fmt.iso(System.currentTimeMillis()));
        } catch (Exception e) {
            saving = false;
            Toast.makeText(this, "저장하지 못했어요", Toast.LENGTH_SHORT).show();
            return;
        }
        Notifs.cancelResult(this);
        if (test) {
            Toast.makeText(this, "시험이라 저장하지 않았어요 (" + (skipResult ? "결과 없음" : result) + ")", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        final JSONObject toSave = log;
        final android.content.Context app = getApplicationContext();
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                final boolean ok = CallFlow.save(app, toSave);
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(app, ok ? "강CRM에 저장했어요" : "인터넷이 안 돼서 나중에 올려요", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        finish();
    }


    // ═════ 📵 v4.6 부재 재연락: 건 전화를 안 받은 고객 → 연락한 이유 · 언제 보낼까요 ═════
    private void buildMiss() {
        missCustomBtn = null;
        missInfo = null;
        missPhrase = null;
        missSaveBtn = null;
        missBox = null;
        missResBtns.clear();
        missReasonBtns.clear();
        missReasonLabels.clear();
        missWhenBtns.clear();
        JSONObject m = log.optJSONObject("_miss");
        if (m == null) m = new JSONObject();
        missCfg = m.optJSONObject("cfg") == null ? new JSONObject() : m.optJSONObject("cfg");
        missDeny = m.optBoolean("deny", false);
        missBase = Fmt.parseIso(log.optString("startedAt"), System.currentTimeMillis());
        if (missWhen.isEmpty()) missWhen = m.optString("when", Miss.defWhen(missCfg, missBase));
        if ("e19".equals(missWhen) && !Miss.eveningOk(missBase)) missWhen = "m10";
        missAdToggle = Miss.adToggle(missCfg);
        if (!missAdInit) {
            missAd = Miss.adDefault(missCfg);
            missAdInit = true;
        }
        List<String> reasons = Miss.reasons(missCfg);
        String[] sug = Miss.suggest(Facts.fromJson(log.optString("_facts")), reasons);
        if (missLabel.isEmpty()) missLabel = sug[0];

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        sv.setFillViewport(true);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        box.setPadding(p, Ui.dp(this, 24), p, Ui.dp(this, 24));
        sv.addView(box, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        box.addView(Ui.text(this, "📞 건 전화 · 연결 안 됨" + (test ? " · 시험" : ""), 15, Ui.RED, true));
        box.addView(whoCard(), Ui.full(this, 10));

        box.addView(Ui.text(this, "통화 결과", 15, Ui.INK, true), Ui.full(this, 16));
        LinearLayout rr = Ui.row(this);
        for (int k = 0; k < MISS_KEYS.length; k++) {
            final int idx = k;
            Button bt = Ui.button(this, MISS_BTNS[k], false);
            bt.setTextSize(14);
            bt.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    missKey = MISS_KEYS[idx];
                    missPaint();
                }
            });
            missResBtns.add(bt);
            rr.addView(bt, Ui.weight(this, k == 0 ? 0 : 6));
        }
        box.addView(rr, Ui.full(this, 6));

        missBox = new LinearLayout(this);
        missBox.setOrientation(LinearLayout.VERTICAL);
        missBox.setBackground(Ui.round(Color.WHITE, ORANGE_LINE, 16, this));
        int bp = Ui.dp(this, 14);
        missBox.setPadding(bp, bp, bp, bp);
        missBox.addView(Ui.text(this, "🔁 자동 재연락 (명함 문자)", 16, ORANGE_DARK, true));
        if (missDeny) {
            missBox.addView(Ui.text(this, "이 고객은 광고 수신 거부 (또는 연락 원치 않음) 고객이라 문자가 안 가요. 부재로만 저장돼요.", 14, Ui.RED, true), Ui.full(this, 6));
        } else {
            missBox.addView(Ui.text(this, "연락한 이유", 13, Ui.GRAY, true), Ui.full(this, 10));
            List<String> chips = new ArrayList<>(reasons);
            chips.add("✏️ 직접 입력");
            for (int r = 0; r < chips.size(); r += 3) {
                LinearLayout row = Ui.row(this);
                for (int k = r; k < Math.min(r + 3, chips.size()); k++) {
                    final String lab = chips.get(k);
                    final boolean custom = k == chips.size() - 1;
                    Button ch = Ui.button(this, lab, false);
                    ch.setTextSize(13);
                    ch.setMinHeight(Ui.dp(this, 40));
                    ch.setPadding(Ui.dp(this, 4), 0, Ui.dp(this, 4), 0);
                    ch.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            missLabel = custom ? "" : lab;
                            missPhrase.setText(custom ? "" : Miss.phrase(lab));
                            missPhrase.setSelection(missPhrase.getText().length());
                            if (custom) missPhrase.requestFocus();
                            missPaint();
                        }
                    });
                    if (!custom) {
                        missReasonBtns.add(ch);
                        missReasonLabels.add(lab);
                    }
                    row.addView(ch, Ui.weight(this, k == r ? 0 : 6));
                }
                for (int k = Math.min(r + 3, chips.size()); k < r + 3; k++) row.addView(new View(this), Ui.weight(this, 6));   // 마지막 줄 칸 맞추기
                missBox.addView(row, Ui.full(this, 6));
            }
            if (!sug[1].isEmpty()) missBox.addView(Ui.text(this, sug[1], 12, Ui.GRAY, false), Ui.full(this, 6));

            missBox.addView(Ui.text(this, "문자에 들어갈 말 (고칠 수 있어요)", 13, Ui.GRAY, true), Ui.full(this, 12));
            missPhrase = new EditText(this);
            missPhrase.setHint("비우면 '" + Miss.DEFAULT_PHRASE + "'");
            missPhrase.setSingleLine(true);
            missPhrase.setInputType(InputType.TYPE_CLASS_TEXT);
            missPhrase.setTextSize(16);
            missPhrase.setTextColor(Ui.INK);
            missPhrase.setBackground(Ui.round(Color.WHITE, Color.parseColor("#D1D5DB"), 10, this));
            int pp = Ui.dp(this, 10);
            missPhrase.setPadding(pp, pp, pp, pp);
            missPhrase.setText(Miss.phrase(missLabel));
            missBox.addView(missPhrase, Ui.full(this, 4));

            missBox.addView(Ui.text(this, "언제 보낼까요", 13, Ui.GRAY, true), Ui.full(this, 12));
            boolean eve = Miss.eveningOk(missBase);
            for (int r = 0; r < 2; r++) {
                LinearLayout row = Ui.row(this);
                for (int k = 0; k < 2; k++) {
                    final int idx = r * 2 + k;
                    final boolean off = "e19".equals(Miss.WHEN_CODES[idx]) && !eve;
                    Button wb = Ui.button(this, Miss.WHEN_LABELS[idx] + (off ? " (지남)" : ""), false);
                    wb.setTextSize(14);
                    wb.setMinHeight(Ui.dp(this, 44));
                    wb.setEnabled(!off);
                    if (off) wb.setAlpha(0.45f);
                    wb.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            if (off) return;
                            missWhen = Miss.WHEN_CODES[idx];
                            missPaint();
                        }
                    });
                    missWhenBtns.add(wb);
                    row.addView(wb, Ui.weight(this, k == 0 ? 0 : 6));
                }
                missBox.addView(row, Ui.full(this, r == 0 ? 4 : 6));
            }
            missCustomBtn = Ui.button(this, "⏰ 직접 입력 (날짜 · 시간)", false);   // v4.7
            missCustomBtn.setTextSize(14);
            missCustomBtn.setMinHeight(Ui.dp(this, 44));
            missCustomBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    pickCustom();
                }
            });
            missBox.addView(missCustomBtn, Ui.full(this, 6));
            missInfo = Ui.text(this, "", 13, Ui.GREEN, true);
            missBox.addView(missInfo, Ui.full(this, 8));
            missBox.addView(Ui.text(this, "✓ 광고성 수신동의 고객에게만 · 고객 전용 명함 링크가 같이 가요", 12, Ui.GREEN, false), Ui.full(this, 4));
            if (missAdToggle) {   // 📢 v4.7 강CRM 설정에서 '문자마다'를 허용했을 때만
                LinearLayout ar = Ui.row(this);
                ar.setMinimumHeight(Ui.dp(this, 52));
                LinearLayout tx = new LinearLayout(this);
                tx.setOrientation(LinearLayout.VERTICAL);
                tx.addView(Ui.text(this, "📢 (광고) 표시", 15, Ui.INK, true));
                tx.addView(Ui.text(this, "기변 · 이벤트 같은 영업 문자는 켜 두세요 · 꺼도 수신거부 안내는 붙어요", 12, Ui.GRAY, false));
                ar.addView(tx, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                Switch sw = new Switch(this);
                sw.setChecked(missAd);
                sw.setContentDescription("(광고) 표시");
                sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                    @Override
                    public void onCheckedChanged(CompoundButton b, boolean on) {
                        missAd = on;
                    }
                });
                ar.addView(sw);
                missBox.addView(ar, Ui.full(this, 6));
            } else {
                missBox.addView(Ui.text(this, "📢 (광고) 표시: " + (missAd ? "붙여요" : "안 붙여요") + " (강CRM 매장 설정)", 12, Ui.GRAY, false), Ui.full(this, 4));
            }
            TextView pv = Ui.text(this, "보낼 문자 미리 보기 ›", 14, Ui.INDIGO, true);
            pv.setMinHeight(Ui.dp(this, 40));
            pv.setGravity(Gravity.CENTER_VERTICAL);
            pv.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    missPreview();
                }
            });
            missBox.addView(pv, Ui.full(this, 4));
        }
        box.addView(missBox, Ui.full(this, 12));

        box.addView(Ui.text(this, "메모 (선택)", 15, Ui.INK, true), Ui.full(this, 16));
        memo = new EditText(this);
        memo.setHint("예: 저녁에 다시 걸기");
        memo.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE | InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        memo.setMinLines(2);
        memo.setGravity(Gravity.TOP | Gravity.START);
        memo.setTextSize(16);
        memo.setTextColor(Ui.INK);
        memo.setBackground(Ui.round(Color.WHITE, Color.parseColor("#D1D5DB"), 12, this));
        int mp = Ui.dp(this, 12);
        memo.setPadding(mp, mp, mp, mp);
        box.addView(memo, Ui.full(this, 6));

        missSaveBtn = Ui.button(this, "강CRM에 저장", true);
        missSaveBtn.setMinHeight(Ui.dp(this, 56));
        missSaveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMiss(false);
            }
        });
        box.addView(missSaveBtn, Ui.full(this, 20));
        Button skip = Ui.button(this, "고르지 않고 닫기 (강CRM 기본 설정대로)", false);
        skip.setTextSize(14);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMiss(true);
            }
        });
        box.addView(skip, Ui.full(this, 8));
        box.addView(Ui.text(this, "고객이 명함에서 [지금 통화] · [편한 시간] · [연락 원치 않아요]를 누르면 강CRM에 들어오고 담당자 폰에 알림이 가요. 10분 안에 저장하지 않으면 부재로 저장되고, 재연락은 강CRM 기본 설정대로 해요.", 13, Ui.GRAY, false), Ui.full(this, 14));

        setContentView(sv);
        missPaint();
    }

    /** 고른 것 색칠 · 안내 글 · 저장 버튼 글자 */
    private void missPaint() {
        for (int i = 0; i < missResBtns.size(); i++) {
            boolean on = MISS_KEYS[i].equals(missKey);
            Button bt = missResBtns.get(i);
            int fill = on ? ("missed".equals(MISS_KEYS[i]) ? Color.parseColor("#FFF7ED") : Ui.INDIGO) : Color.WHITE;
            bt.setTextColor(on ? ("missed".equals(MISS_KEYS[i]) ? ORANGE_DARK : Color.WHITE) : Ui.INK);
            bt.setBackground(Ui.round(fill, on ? ("missed".equals(MISS_KEYS[i]) ? ORANGE : 0) : Color.parseColor("#D1D5DB"), 12, this));
        }
        boolean missed = "missed".equals(missKey);
        if (missBox != null) missBox.setVisibility(missed ? View.VISIBLE : View.GONE);
        for (int i = 0; i < missReasonBtns.size(); i++) {
            boolean on = missReasonLabels.get(i).equals(missLabel);
            Button bt = missReasonBtns.get(i);
            bt.setTextColor(on ? Color.WHITE : Ui.INK);
            bt.setBackground(Ui.round(on ? Ui.INDIGO : Color.WHITE, on ? 0 : Color.parseColor("#D1D5DB"), 20, this));
        }
        for (int i = 0; i < missWhenBtns.size(); i++) {
            boolean on = Miss.WHEN_CODES[i].equals(missWhen);
            Button bt = missWhenBtns.get(i);
            bt.setTextColor(on ? Color.parseColor("#3730A3") : Ui.INK);
            bt.setBackground(Ui.round(on ? Color.parseColor("#EEF2FF") : Color.WHITE, on ? Ui.INDIGO : Color.parseColor("#D1D5DB"), 10, this));
        }
        long now = System.currentTimeMillis();
        if (missCustomBtn != null) {
            boolean on = "at".equals(missWhen) && missAtMs > 0;
            missCustomBtn.setText(on ? "⏰ " + Miss.whenText(missAtMs, now) + " · 바꾸려면 누르기" : "⏰ 직접 입력 (날짜 · 시간)");
            missCustomBtn.setTextColor(on ? Color.parseColor("#3730A3") : Ui.INK);
            missCustomBtn.setBackground(Ui.round(on ? Color.parseColor("#EEF2FF") : Color.WHITE, on ? Ui.INDIGO : Color.parseColor("#D1D5DB"), 10, this));
        }
        if (missInfo != null) {
            long at = Miss.sendAt(missWhen, missBase, missAtMs);
            boolean moved = ("h2".equals(missWhen) && at != missBase + 2L * 3600L * 1000L) || ("at".equals(missWhen) && at != missAtMs);
            missInfo.setTextColor(at > 0 ? Ui.GREEN : Ui.GRAY);
            missInfo.setText(at > 0 ? "📤 " + Miss.whenText(at, now) + "에 매장 폰으로 보내요" + (moved ? " (저녁 9시~아침 8시엔 안 보내서 아침 9시에)" : "")
                    : "문자를 보내지 않아요 · 부재로만 저장");
        }
        if (missSaveBtn != null) missSaveBtn.setText(!missed ? "강CRM에 저장" : (missDeny ? "강CRM에 저장 · 부재" : Miss.saveLabel(missWhen, missBase, now, missAtMs)));
    }

    private void missPreview() {
        String ph = missPhrase == null ? "" : missPhrase.getText().toString();
        String txt = Miss.preview(missCfg, log.optString("customerName"), log.optString("managerName"), ph, missAd);
        new AlertDialog.Builder(this)
                .setTitle("보낼 문자 미리 보기")
                .setMessage(txt + "\n\n※ 실제 문자는 강CRM이 만들어요 (링크 자리에 고객 전용 명함 주소)")
                .setPositiveButton("닫기", null)
                .show();
    }

    /** ⏰ v4.7 직접 입력: 달력(오늘 ~ 7일 뒤) → 시계 */
    private void pickCustom() {
        final long now = System.currentTimeMillis();
        Calendar init = Calendar.getInstance();
        if (missAtMs > now) init.setTimeInMillis(missAtMs);
        DatePickerDialog d = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, final int y, final int m, final int day) {
                Calendar t0 = Calendar.getInstance();
                if (missAtMs > 0) t0.setTimeInMillis(missAtMs);
                else {
                    t0.add(Calendar.HOUR_OF_DAY, 1);
                    t0.set(Calendar.MINUTE, 0);
                }
                new TimePickerDialog(ResultActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker tv, int h, int mi) {
                        long at = Miss.atOf(y, m, day, h, mi);
                        String err = Miss.customErr(at, System.currentTimeMillis());
                        if (!err.isEmpty()) {
                            Toast.makeText(ResultActivity.this, err, Toast.LENGTH_LONG).show();
                            return;
                        }
                        missAtMs = at;
                        missWhen = "at";
                        missPaint();
                    }
                }, t0.get(Calendar.HOUR_OF_DAY), t0.get(Calendar.MINUTE), false).show();
            }
        }, init.get(Calendar.YEAR), init.get(Calendar.MONTH), init.get(Calendar.DAY_OF_MONTH));
        d.getDatePicker().setMinDate(Miss.dayStart(now));
        d.getDatePicker().setMaxDate(Miss.customMax(now));
        d.show();
    }

    /** 저장: skip = 고르지 않고 닫기 (부재 · 재연락은 강CRM 기본 설정대로) */
    private void saveMiss(boolean skip) {
        if (saving) return;
        saving = true;
        try {
            boolean missed = skip || "missed".equals(missKey);
            int idx = 2;
            for (int i = 0; i < MISS_KEYS.length; i++) if (MISS_KEYS[i].equals(missKey)) idx = i;
            log.put("result", missed ? "부재중" : MISS_RESULTS[idx]);
            log.put("resultKey", missed ? "missed" : MISS_KEYS[idx]);
            log.put("memo", memo == null ? "" : memo.getText().toString().trim());
            log.put("nextKind", "");
            log.put("nextDate", "");
            log.remove("missWhen");
            log.remove("missReason");
            log.remove("missAt");
            log.remove("missAd");
            if (missed && !skip && !missDeny) {
                String w = missWhen.isEmpty() ? "none" : missWhen;
                if ("at".equals(w) && missAtMs <= 0) w = "none";
                log.put("missWhen", w);
                if ("at".equals(w)) log.put("missAt", Long.valueOf(missAtMs));   // ⏰ v4.7 직접 고른 시각
                String ph = missPhrase == null ? "" : missPhrase.getText().toString().replaceAll("\\s+", " ").trim();
                log.put("missReason", "none".equals(w) ? "" : (ph.length() > 40 ? ph.substring(0, 40) : ph));
                if (missAdToggle && !"none".equals(w)) log.put("missAd", Boolean.valueOf(missAd));   // 📢 v4.7 문자마다 (광고) 표시
            }
            log.put("at", Fmt.iso(System.currentTimeMillis()));
        } catch (Exception e) {
            saving = false;
            Toast.makeText(this, "저장하지 못했어요", Toast.LENGTH_SHORT).show();
            return;
        }
        Notifs.cancelResult(this);
        if (test) {
            Toast.makeText(this, "시험이라 저장하지 않았어요 (" + log.optString("result") + (log.has("missWhen") ? " · " + log.optString("missWhen") : "") + (log.has("missAt") ? " " + Miss.whenText(log.optLong("missAt"), System.currentTimeMillis()) : "") + (log.has("missAd") ? (log.optBoolean("missAd") ? " · (광고)" : " · 광고 표시 끔") : "") + ")", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        final android.content.Context app = getApplicationContext();
        if (!CallFlow.takeMiss(app, log.optString("id"))) {   // 10분이 지나 이미 부재로 올라감
            Toast.makeText(app, "10분이 지나 부재로 먼저 저장됐어요 · 재연락은 강CRM 기본 설정대로 해요", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        final JSONObject toSave = log;
        CallFlow.EX.execute(new Runnable() {
            @Override
            public void run() {
                final boolean ok = CallFlow.save(app, toSave);
                CallFlow.H.post(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(app, ok ? "강CRM에 저장했어요" : "인터넷이 안 돼서 나중에 올려요", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        finish();
    }

    @Override
    public void onBackPressed() {
        if (log != null && log.has("_miss")) {
            saveMiss(true);   // 📵 뒤로 가면 부재로 (재연락은 기본 설정대로)
            return;
        }
        doSave(true);   // 뒤로 가도 통화한 건 기록 (결과 없이)
    }
}
