package kr.kangcrm.call;

import android.app.KeyguardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.widget.Toast;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** 전화 받는 화면 위에 뜨는 강CRM 고객 카드 (끌어서 옮기기 · ✕로 닫기) */
final class Overlay {
    private Overlay() {}

    private static final Handler H = new Handler(Looper.getMainLooper());
    private static View shown;
    private static WindowManager shownWm;
    private static Runnable autoHide;
    private static TextView lastView;   // 🕘 v3 지난 통화 (나중에 채움)
    private static String shownId = "";

    static boolean can(Context c) {
        return Settings.canDrawOverlays(c);
    }

    static void show(final Context ctx, final Cust cu, final String number, final String kind, final long autoHideMs) {
        final Context c = ctx.getApplicationContext();
        H.post(new Runnable() {
            @Override
            public void run() {
                try {
                    showNow(c, cu, number, kind, autoHideMs);
                } catch (Throwable t) {
                    Log.w("KC", "overlay", t);
                }
            }
        });
    }

    static void hide() {
        H.post(new Runnable() {
            @Override
            public void run() {
                hideNow();
            }
        });
    }

    private static void hideNow() {
        if (autoHide != null) {
            H.removeCallbacks(autoHide);
            autoHide = null;
        }
        if (shown != null && shownWm != null) {
            try {
                shownWm.removeView(shown);
            } catch (Throwable ignore) {
                // 이미 사라짐
            }
        }
        shown = null;
        shownWm = null;
        lastView = null;
        shownId = "";
        tagView = null;
        nameView = null;
        chipView = null;
    }

    /** 🕘 지난 통화 한 줄을 지금 떠 있는 카드에 (같은 고객일 때만) */
    static void setLast(final String custId, final String text) {
        H.post(new Runnable() {
            @Override
            public void run() {
                if (lastView == null || text == null || text.isEmpty() || !custId.equals(shownId)) return;
                lastView.setText(text);
                lastView.setVisibility(View.VISIBLE);
            }
        });
    }

    // ── 🔗 v4.4 강CRM 카드 ──
    private static TextView tagView, nameView, chipView;
    private static boolean ringingNow, shownTest;

    /** 벨 울리는 중이면 흐리게 '받으면 강CRM 카드' · 받으면 진하게 */
    private static void applyChip() {
        if (chipView == null) return;
        chipView.setAlpha(ringingNow ? 0.45f : 1f);
        chipView.setText(ringingNow ? "받으면 강CRM 카드" : "강CRM 카드 ›");
        if (nameView != null) {
            int f = nameView.getPaintFlags();
            nameView.setPaintFlags(ringingNow ? (f & ~Paint.UNDERLINE_TEXT_FLAG) : (f | Paint.UNDERLINE_TEXT_FLAG));
        }
    }

    /** 전화를 받았을 때 (CallFlow) → 카드 머리글 '통화 중' · 강CRM 카드 누를 수 있게 */
    static void setAnswered() {
        H.post(new Runnable() {
            @Override
            public void run() {
                if (shown == null) return;
                ringingNow = false;
                if (tagView != null) tagView.setText("📞 강CRM 고객 · 통화 중");
                applyChip();
            }
        });
    }

    /** 벨 울리는 중인지 (눌렀을 때 다시 확인 · 시험 카드는 언제나 열림) */
    static boolean ringingFor(boolean test, String st) {
        return !test && "RINGING".equals(st);
    }

    private static void openCrm(Context c, String custId) {
        if (ringingFor(shownTest, Store.get(c, "st"))) {
            Toast.makeText(c, "전화를 받은 뒤에 열 수 있어요", Toast.LENGTH_SHORT).show();
            return;
        }
        String u = MainActivity.crmUrl(c, custId);
        if (u.isEmpty()) {
            Toast.makeText(c, "강CRM 주소를 아직 몰라요 · 대표님 폰에서 강CRM(V224 이상)을 한 번 열거나 [이 폰을 콜매니저와 연결]을 다시 눌러 주세요", Toast.LENGTH_LONG).show();
            return;
        }
        if (!Links.open(c, u)) {   // 🔗 v4.5 설치된 강CRM 웹앱 → 없으면 브라우저
            Toast.makeText(c, "강CRM을 열 수 없어요", Toast.LENGTH_SHORT).show();
            return;
        }
        try {
            KeyguardManager km = (KeyguardManager) c.getSystemService(Context.KEYGUARD_SERVICE);
            if (km != null && km.isKeyguardLocked()) Toast.makeText(c, "잠금을 풀면 강CRM 고객카드가 보여요", Toast.LENGTH_LONG).show();
        } catch (Exception ignore) {
            // 안내만
        }
        hideNow();
    }

    static int toneColor(int tone) {
        return tone == Facts.ALERT ? Color.parseColor("#FCA5A5") : (tone == Facts.WARN ? Color.parseColor("#FDE68A") : Color.parseColor("#E0E7FF"));
    }

    private static void showNow(final Context c, Cust cu, String number, String kind, long autoHideMs) {
        if (!can(c)) return;
        hideNow();
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        if (wm == null) return;

        final FrameLayout root = new FrameLayout(c);
        int side = Ui.dp(c, 12);
        root.setPadding(side, 0, side, 0);

        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(Ui.round(Color.parseColor("#1E1B4B"), Color.parseColor("#4338CA"), 20, c));
        int p = Ui.dp(c, 16);
        card.setPadding(p, Ui.dp(c, 12), p, p);
        card.setElevation(Ui.dp(c, 8));

        LinearLayout head = Ui.row(c);
        TextView tag = Ui.text(c, "📞 강CRM 고객 · " + kind, 13, Color.parseColor("#C7D2FE"), true);
        head.addView(tag, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        TextView close = Ui.text(c, "✕", 20, Color.parseColor("#C7D2FE"), true);
        close.setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 4), 0);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hideNow();
            }
        });
        head.addView(close);
        card.addView(head);

        // 🔗 v4.4 이름 · [강CRM 카드 ›] → 크롬에서 강CRM 고객카드 (벨 울릴 땐 못 누름 · 받으면 풀림)
        final String custId = cu.id();
        shownTest = "시험".equals(kind);
        ringingNow = !shownTest && "RINGING".equals(Store.get(c, "st"));
        LinearLayout nameRow = Ui.row(c);
        nameRow.setPadding(0, Ui.dp(c, 4), 0, Ui.dp(c, 2));
        TextView name = Ui.text(c, cu.name(), 24, Color.WHITE, true);
        TextView chip = Ui.text(c, "강CRM 카드 ›", 13, Color.WHITE, true);
        chip.setGravity(Gravity.CENTER);
        chip.setMinHeight(Ui.dp(c, 40));
        chip.setPadding(Ui.dp(c, 12), Ui.dp(c, 6), Ui.dp(c, 12), Ui.dp(c, 6));
        chip.setBackground(Ui.round(Color.parseColor("#4F46E5"), 0, 20, c));
        View.OnClickListener open = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCrm(c, custId);
            }
        };
        name.setOnClickListener(open);
        chip.setOnClickListener(open);
        chip.setContentDescription(cu.name() + " 강CRM 고객카드 열기");
        nameRow.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        clp.leftMargin = Ui.dp(c, 8);
        nameRow.addView(chip, clp);
        card.addView(nameRow);
        tagView = tag;
        nameView = name;
        chipView = chip;
        applyChip();
        String l2 = cu.line2();
        if (!l2.isEmpty()) card.addView(Ui.text(c, l2, 15, Color.parseColor("#E0E7FF"), true));
        String l3 = cu.line3();
        if (!l3.isEmpty()) card.addView(Ui.text(c, l3, 14, Color.parseColor("#C7D2FE"), false));
        for (Facts.Line f : Facts.of(cu.d)) {   // 📋 v3 개통 · 할부 · 약정 · 기변 시기 · 생일 · 미비서류
            TextView ft = Ui.text(c, f.text, 13, toneColor(f.tone), f.tone != Facts.NORMAL);
            ft.setPadding(0, Ui.dp(c, 1), 0, 0);
            card.addView(ft);
        }
        String l4 = cu.line4();
        if (!l4.isEmpty()) card.addView(Ui.text(c, l4, 14, Color.parseColor("#FDE68A"), false));
        TextView last = Ui.text(c, "", 13, Color.parseColor("#E0E7FF"), false);
        last.setMaxLines(3);
        last.setBackground(Ui.round(Color.parseColor("#27235E"), 0, 10, c));
        last.setPadding(Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6));
        last.setVisibility(View.GONE);
        card.addView(last, Ui.full(c, 6));
        // 📝 v4.4 메모: 기타 메모 3줄까지 + OB · 상담 메모 첫 줄
        String memo = cu.memoFull(), ob = cu.memoOb();
        if (!memo.isEmpty() || !ob.isEmpty()) {
            LinearLayout mb = new LinearLayout(c);
            mb.setOrientation(LinearLayout.VERTICAL);
            mb.setBackground(Ui.round(Color.parseColor("#312E81"), 0, 10, c));
            mb.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
            if (!memo.isEmpty()) {
                TextView m = Ui.text(c, "📝 " + memo, 14, Color.WHITE, false);
                m.setMaxLines(3);
                m.setEllipsize(android.text.TextUtils.TruncateAt.END);
                mb.addView(m);
            }
            if (!ob.isEmpty()) {
                TextView o = Ui.text(c, "🗒 " + ob, 13, Color.parseColor("#E0E7FF"), false);
                o.setMaxLines(2);
                o.setEllipsize(android.text.TextUtils.TruncateAt.END);
                if (!memo.isEmpty()) o.setPadding(0, Ui.dp(c, 4), 0, 0);
                mb.addView(o);
            }
            card.addView(mb, Ui.full(c, 8));
        }
        root.addView(card, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        long savedY = Store.getLong(c, "ovY");
        lp.y = savedY > 0 ? (int) savedY : Ui.dp(c, 150);

        card.setOnTouchListener(new View.OnTouchListener() {
            float downY;
            int startY;

            @Override
            public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downY = e.getRawY();
                        startY = lp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.y = Math.max(0, startY + Math.round(e.getRawY() - downY));
                        try {
                            wm.updateViewLayout(root, lp);
                        } catch (Throwable ignore) {
                            // 닫힘
                        }
                        return true;
                    case MotionEvent.ACTION_UP:
                        Store.putLong(c, "ovY", lp.y);
                        return true;
                    default:
                        return false;
                }
            }
        });

        wm.addView(root, lp);
        shown = root;
        shownWm = wm;
        lastView = last;
        shownId = cu.id();
        if (autoHideMs > 0) {
            autoHide = new Runnable() {
                @Override
                public void run() {
                    hideNow();
                }
            };
            H.postDelayed(autoHide, autoHideMs);
        }
    }
}
