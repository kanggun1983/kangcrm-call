package kr.kangcrm.call;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** 강CRM 고객 한 명 (팝업 · 결과 창에 보일 줄) */
final class Cust {
    final JSONObject d;

    Cust(JSONObject d) {
        this.d = d == null ? new JSONObject() : d;
    }

    String s(String k) {
        Object o = d.opt(k);
        if (o == null || o == JSONObject.NULL) return "";
        return String.valueOf(o).trim();
    }

    String id() { return s("id"); }

    String name() {
        String n = s("name");
        return n.isEmpty() ? "이름 없음" : n;
    }

    String manager() { return s("manager"); }

    private static String join(String sep, String... parts) {
        List<String> out = new ArrayList<>();
        for (String p : parts) if (p != null && !p.trim().isEmpty()) out.add(p.trim());
        return String.join(sep, out);
    }

    /** 담당 임호규 · 판매성공 */
    String line2() {
        String m = manager();
        return join(" · ", m.isEmpty() ? "" : "담당 " + m, s("salesStatus"));
    }

    /** 갤럭시 S26 · 5G 프리미어 · LG U+ */
    String line3() {
        return join(" · ", s("device"), s("plan"), s("carrier"));
    }

    /** 최근 연락 10/20 · 다음 약속 방문 10/28 */
    String line4() {
        String lc = s("lastContactDate");
        return join(" · ", lc.isEmpty() ? "" : "최근 연락 " + Fmt.md(lc), nextPromise());
    }

    /** 메모 첫 줄 */
    String memo() {
        for (String k : new String[]{"memo", "obMemo", "prospectMemo"}) {
            String v = s(k);
            if (v.isEmpty()) continue;
            for (String line : v.split("\n")) {
                String t = line.trim();
                if (!t.isEmpty()) return t.length() > 70 ? t.substring(0, 70) + "…" : t;
            }
        }
        return "";
    }

    /** v4.4 팝업 메모: 강CRM '기타 메모' 전체 (줄은 · 로 이어서 · 140자까지) */
    String memoFull() {
        return squash(s("memo"), 140);
    }

    /** v4.4 팝업 메모 둘째: OB 메모 · 상담 메모 첫 줄 (기타 메모와 같으면 빈칸) */
    String memoOb() {
        for (String k : new String[]{"obMemo", "prospectMemo"}) {
            String v = s(k);
            if (v.isEmpty() || v.equals("-")) continue;
            for (String line : v.split("\n")) {
                String t = line.trim();
                if (t.isEmpty() || t.equals("-")) continue;
                if (t.length() > 80) t = t.substring(0, 80) + "…";
                return memoFull().startsWith(t) ? "" : t;
            }
        }
        return "";
    }

    static String squash(String v, int max) {
        if (v == null) return "";
        List<String> out = new ArrayList<>();
        for (String line : v.split("\n")) {
            String t = line.trim();
            if (!t.isEmpty() && !t.equals("-")) out.add(t);
        }
        String j = String.join(" · ", out);
        return j.length() > max ? j.substring(0, max) + "…" : j;
    }

    private static final Pattern PROM = Pattern.compile("^prom([A-Za-z0-9]+)Date$");

    static String promLabel(String k) {
        if (k.startsWith("Addon")) return "부가";
        switch (k) {
            case "Plan": return "요금제";
            case "Card": return "카드";
            case "Acc": return "악세";
            case "Visit": return "방문";
            case "Ins": return "보험";
            case "Call": return "연락";
            default: return "약속";
        }
    }

    String nextPromise() {
        String today = Fmt.ymd(System.currentTimeMillis());
        String best = "", bestKey = "";
        Iterator<String> it = d.keys();
        while (it.hasNext()) {
            String k = it.next();
            Matcher m = PROM.matcher(k);
            if (!m.matches()) continue;
            String v = s(k);
            if (v.length() < 10 || v.compareTo(today) < 0) continue;
            if (d.optBoolean("prom" + m.group(1) + "Chk", false)) continue;
            if (best.isEmpty() || v.compareTo(best) < 0) {
                best = v;
                bestKey = m.group(1);
            }
        }
        if (best.isEmpty()) return "";
        String when = best.substring(0, 10).equals(today) ? "오늘" : Fmt.md(best.substring(0, 10));
        return String.format(Locale.KOREA, "다음 약속 %s %s", promLabel(bestKey), when);
    }
}
