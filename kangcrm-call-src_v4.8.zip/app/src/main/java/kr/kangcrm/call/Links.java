package kr.kangcrm.call;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;

import java.util.ArrayList;
import java.util.List;

/**
 * 🔗 v4.5 강CRM 카드 열기
 *  폰에 '앱 설치'로 깐 강CRM 웹앱(크롬 WebAPK · org.chromium.webapk.…)이 이 주소를 열 수 있으면 그 웹앱으로,
 *  없으면(바로가기 · 삼성 인터넷 · 안 깐 폰) 지금처럼 브라우저로.
 */
final class Links {
    private Links() {}

    static Intent view(String url) {
        return new Intent(Intent.ACTION_VIEW, Uri.parse(url))
                .addCategory(Intent.CATEGORY_BROWSABLE)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
    }

    /** 이 주소를 여는 앱 이름들 가운데 설치된 웹앱 (크롬 WebAPK 먼저) · 없으면 "" */
    static String pickWebApp(List<String> pkgs) {
        String other = "";
        if (pkgs == null) return other;
        for (String p : pkgs) {
            if (p == null) continue;
            if (p.startsWith("org.chromium.webapk.")) return p;
            if (other.isEmpty() && p.contains("webapk")) other = p;
        }
        return other;
    }

    static String webAppFor(Context c, Intent i) {
        try {
            List<ResolveInfo> l = c.getPackageManager().queryIntentActivities(i, PackageManager.MATCH_ALL);
            List<String> pkgs = new ArrayList<>();
            if (l != null) {
                for (ResolveInfo r : l) {
                    if (r != null && r.activityInfo != null) pkgs.add(r.activityInfo.packageName);
                }
            }
            return pickWebApp(pkgs);
        } catch (Throwable t) {
            return "";
        }
    }

    /** 강CRM 주소 열기 → 웹앱 · 안 되면 브라우저 · 둘 다 안 되면 false */
    static boolean open(Context c, String url) {
        Intent i = view(url);
        String pkg = webAppFor(c, i);
        if (!pkg.isEmpty()) {
            try {
                c.startActivity(new Intent(i).setPackage(pkg));
                return true;
            } catch (Throwable t) {
                // 웹앱이 안 열리면 브라우저로
            }
        }
        try {
            c.startActivity(i);
            return true;
        } catch (Throwable t) {
            return false;
        }
    }
}
