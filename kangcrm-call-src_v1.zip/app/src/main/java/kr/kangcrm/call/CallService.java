package kr.kangcrm.call;

import android.app.Notification;
import android.app.Service;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

/** 통화하는 동안만 켜지는 서비스 (카드를 띄우고, 끊기면 결과 창까지 맡음 → 끝나면 스스로 꺼짐) */
public class CallService extends Service {
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent in, int flags, int startId) {
        Notification n = Notifs.running(this);
        try {
            if (Build.VERSION.SDK_INT >= 34) startForeground(Notifs.ID_RUN, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            else startForeground(Notifs.ID_RUN, n);
        } catch (Throwable t) {
            Log.w("KC", "startForeground", t);
        }
        String state = in == null ? null : in.getStringExtra("state");
        String num = in == null ? null : in.getStringExtra("num");
        if (state == null || state.isEmpty()) {
            finish();
            return START_NOT_STICKY;
        }
        CallFlow.onState(getApplicationContext(), state, num == null ? "" : num, new Runnable() {
            @Override
            public void run() {
                if (CallFlow.idle(getApplicationContext())) finish();
            }
        });
        return START_NOT_STICKY;
    }

    private void finish() {
        try {
            stopForeground(STOP_FOREGROUND_REMOVE);
        } catch (Throwable ignore) {
            // 괜찮음
        }
        stopSelf();
    }
}
