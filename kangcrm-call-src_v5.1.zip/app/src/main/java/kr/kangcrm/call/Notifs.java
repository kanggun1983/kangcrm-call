package kr.kangcrm.call;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** 알림 (통화 확인 중 · 결과 남기기 · 부재중 · 🔒 v5.0 잠금 화면에서 전화 온 고객) */
final class Notifs {
    private Notifs() {}

    static final int ID_RUN = 1, ID_RESULT = 2, ID_MISSED = 3, ID_CARD = 4;

    static NotificationManager nm(Context c) {
        return (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
    }

    static void ensure(Context c) {
        NotificationManager n = nm(c);
        if (n == null) return;
        if (n.getNotificationChannel("run") == null) {
            NotificationChannel a = new NotificationChannel("run", "통화 확인 중", NotificationManager.IMPORTANCE_MIN);
            a.setShowBadge(false);
            n.createNotificationChannel(a);
        }
        if (n.getNotificationChannel("call") == null) {
            NotificationChannel b = new NotificationChannel("call", "통화 결과 · 부재중", NotificationManager.IMPORTANCE_HIGH);
            n.createNotificationChannel(b);
        }
        if (n.getNotificationChannel("card") == null) {   // 🔒 v5.0 잠금 화면: 소리 · 진동 없이 (벨소리를 가리지 않게) 위에 잠깐 뜸
            NotificationChannel k = new NotificationChannel("card", "전화 온 고객 (잠금 화면)", NotificationManager.IMPORTANCE_HIGH);
            k.setDescription("폰이 잠겨 있을 때 전화 온 강CRM 고객의 이름 · 담당 · 상태를 보여줘요");
            k.setSound(null, null);
            k.enableVibration(false);
            k.setShowBadge(false);
            k.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            n.createNotificationChannel(k);
        }
    }

    // ── 🔒 v5.0 폰이 잠겨 있을 때 전화 온 고객 (잠금 화면 위에는 카드가 못 떠서 알림으로) ──

    /** 잠금 화면 알림을 쓸지 (폰 설정 → 전화 팝업 → 잠금 화면 · 기본 켜짐) */
    static boolean lockOn(Context c) {
        return !"off".equals(Store.get(c, "lockNotif"));
    }

    private static String join(String sep, String... parts) {
        List<String> out = new ArrayList<>();
        for (String p : parts) if (p != null && !p.trim().isEmpty()) out.add(p.trim());
        return String.join(sep, out);
    }

    /** 제목 · 한 줄 · 펼친 글 (메모는 잠금 화면에 안 보이게 뺌 · 잠금을 풀면 카드에) */
    static String[] cardText(Cust cu) {
        String m = cu.manager();
        String title = "📞 " + cu.name() + (m.isEmpty() ? "" : " · 담당 " + m);
        String line = join(" · ", cu.s("salesStatus"), cu.line3());
        String l4 = cu.line4();
        String text = !line.isEmpty() ? line : (!l4.isEmpty() ? l4 : "강CRM 고객");
        String big = text + (!l4.isEmpty() && !l4.equals(text) ? "\n" + l4 : "") + "\n🔓 잠금을 풀면 강CRM 카드(메모 · 지난 통화)가 보여요";
        return new String[]{title, text, big};
    }

    /** 전화 온 고객 알림 (고쳐 그려도 소리 없음 · 끊기면 지움 · 끊김 신호를 놓쳐도 10분 뒤 사라짐 · 시험은 timeoutMs) */
    static void card(Context c, Cust cu, long timeoutMs) {
        NotificationManager n = nm(c);
        if (n == null) return;
        ensure(c);
        String[] t = cardText(cu);
        Notification nf = new Notification.Builder(c, "card")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle(t[0])
                .setContentText(t[1])
                .setStyle(new Notification.BigTextStyle().bigText(t[2]))
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOnlyAlertOnce(true)
                .setTimeoutAfter(timeoutMs > 0 ? timeoutMs : 10L * 60L * 1000L)
                .build();
        n.notify(ID_CARD, nf);
    }

    static void cancelCard(Context c) {
        try {
            NotificationManager n = nm(c);
            if (n != null) n.cancel(ID_CARD);
        } catch (Throwable ignore) {
            // 알림 없음
        }
    }

    static Notification running(Context c) {
        ensure(c);
        return new Notification.Builder(c, "run")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle("콜매니저")
                .setContentText("통화를 확인하고 있어요")
                .setOngoing(true)
                .build();
    }

    static void result(Context c, JSONObject log) {
        ensure(c);
        NotificationManager n = nm(c);
        if (n == null) return;
        Intent i = new Intent(c, ResultActivity.class)
                .putExtra("log", log.toString())
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(c, ID_RESULT, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification nf = new Notification.Builder(c, "call")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle((log.has("_miss") ? "📵 연결 안 됨 · " : "📞 통화 결과 남기기 · ") + log.optString("customerName"))
                .setContentText(log.has("_miss") ? "눌러서 연락한 이유 · 문자 보낼 때를 골라요 (10분 지나면 기본 설정대로)" : "눌러서 결과 · 메모 · 다음 약속을 남겨요")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        n.notify(ID_RESULT, nf);
    }

    static void cancelResult(Context c) {
        NotificationManager n = nm(c);
        if (n != null) n.cancel(ID_RESULT);
    }

    static void missed(Context c, JSONObject log) {
        ensure(c);
        NotificationManager n = nm(c);
        if (n == null) return;
        Intent dial = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + log.optString("phone")))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        PendingIntent pi = PendingIntent.getActivity(c, ID_MISSED, dial, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        boolean noAnswer = "noanswer".equals(log.optString("direction"));
        Notification nf = new Notification.Builder(c, "call")
                .setSmallIcon(R.drawable.ic_stat)
                .setContentTitle((noAnswer ? "📞 안 받음 · " : "📵 부재중 · ") + log.optString("customerName"))
                .setContentText("강CRM 연락 기록에 남겼어요 · 누르면 다시 걸기")
                .setContentIntent(pi)
                .setAutoCancel(true)
                .build();
        n.notify(ID_MISSED, nf);
    }
}
