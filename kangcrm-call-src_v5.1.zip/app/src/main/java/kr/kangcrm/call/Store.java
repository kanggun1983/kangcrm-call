package kr.kangcrm.call;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

/** 이 폰에만 저장하는 값 (연결 정보 · 통화 상태 · 못 올린 기록) */
final class Store {
    private Store() {}

    static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("kc", Context.MODE_PRIVATE);
    }

    static String get(Context c, String k) {
        String v = p(c).getString(k, "");
        return v == null ? "" : v;
    }

    static void put(Context c, String k, String v) {
        p(c).edit().putString(k, v == null ? "" : v).apply();
    }

    static long getLong(Context c, String k) {
        return p(c).getLong(k, 0L);
    }

    static void putLong(Context c, String k, long v) {
        p(c).edit().putLong(k, v).apply();
    }

    static boolean paired(Context c) {
        return !get(c, "rt").isEmpty() && !get(c, "key").isEmpty() && !get(c, "pid").isEmpty();
    }

    static void unpair(Context c) {
        p(c).edit()
                .remove("rt").remove("key").remove("pid").remove("origin")
                .remove("email").remove("staff").remove("idt").remove("idexp")
                .remove("sbe").remove("sbeAt").remove("href")
                .apply();
        CustCache.clear(c);   // 📇 v5.0 기억한 고객도 (다른 매장에 연결할 수 있으니)
    }

    static synchronized JSONArray arr(Context c, String k) {
        try {
            return new JSONArray(p(c).getString(k, "[]"));
        } catch (Exception e) {
            return new JSONArray();
        }
    }

    static synchronized void putArr(Context c, String k, JSONArray a) {
        p(c).edit().putString(k, a.toString()).apply();
    }

    /** 최근 통화 (이 폰 화면용 · v4 통화 기록 탭 · 100개) */
    static synchronized void pushRecent(Context c, JSONObject o) {
        JSONArray a = arr(c, "recent");
        JSONArray b = new JSONArray();
        b.put(o);
        String id = o.optString("id");
        for (int i = 0; i < a.length() && b.length() < 100; i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !id.equals(x.optString("id"))) b.put(x);
        }
        putArr(c, "recent", b);
    }

    /** 못 올린 통화 기록 (인터넷이 안 될 때) */
    static synchronized void queueAdd(Context c, JSONObject o) {
        JSONArray a = arr(c, "queue");
        JSONArray b = new JSONArray();
        String id = o.optString("id");
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !id.equals(x.optString("id"))) b.put(x);
        }
        b.put(o);
        while (b.length() > 100) b.remove(0);
        putArr(c, "queue", b);
    }

    static synchronized void queueRemove(Context c, String id) {
        JSONArray a = arr(c, "queue");
        JSONArray b = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject x = a.optJSONObject(i);
            if (x != null && !id.equals(x.optString("id"))) b.put(x);
        }
        putArr(c, "queue", b);
    }
}
