package kr.kangcrm.call;

import android.util.Base64;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;

/**
 * 🔗 v5.1 강CRM 연결 링크 (kangcrmcall://pair?d=…) 읽기
 *  · 우리 매장 강CRM(Firebase 프로젝트 phoneplace-db · kanggun1983.github.io)에서 만든 링크만 받아요
 *  · 예전엔 아무 링크나 누르면 바로 그 링크 계정으로 연결이 바뀌어서, 누가 가짜 연결 링크를 보내면 통화 번호·녹음이 그쪽으로 갈 수 있었음
 */
final class PairLink {
    static final String PID = "phoneplace-db";
    static final String ORIGIN = "https://kanggun1983.github.io";

    static final class Bad extends Exception {
        final boolean foreign;   // true = 다른 곳에서 만든 링크 (무시)

        Bad(String m, boolean foreign) {
            super(m);
            this.foreign = foreign;
        }
    }

    final String rt, key, pid, origin, href, email, staff;

    private PairLink(String rt, String key, String pid, String origin, String href, String email, String staff) {
        this.rt = rt;
        this.key = key;
        this.pid = pid;
        this.origin = origin;
        this.href = href;
        this.email = email;
        this.staff = staff;
    }

    static PairLink parse(String d) throws Bad {
        if (d == null || d.isEmpty()) throw new Bad("no data", false);
        JSONObject j;
        try {
            j = new JSONObject(new String(Base64.decode(d, Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING), StandardCharsets.UTF_8));
        } catch (Exception e) {
            throw new Bad("read", false);
        }
        String rt = j.optString("rt"), key = j.optString("key"), pid = j.optString("pid");
        if (rt.isEmpty() || key.isEmpty() || pid.isEmpty()) throw new Bad("missing", false);
        if (!PID.equals(pid)) throw new Bad("pid", true);
        String origin = j.optString("origin"), href = j.optString("href");
        if (!origin.isEmpty() && !ORIGIN.equals(origin)) throw new Bad("origin", true);
        if (!href.isEmpty() && !href.startsWith(ORIGIN + "/")) throw new Bad("href", true);
        return new PairLink(rt, key, pid, origin, href, j.optString("email"), j.optString("staff"));
    }

    /** 이미 다른 계정과 연결돼 있으면 바꾸기 전에 물어봐요 */
    boolean needsConfirm(String curRt) {
        return curRt != null && !curRt.isEmpty();
    }

    /** Firebase 로그인 표(JWT)에 들어 있는 이메일 */
    static String emailOf(String jwt) {
        try {
            String[] p = String.valueOf(jwt).split("\\.");
            if (p.length < 2) return "";
            return new JSONObject(new String(Base64.decode(p[1], Base64.URL_SAFE | Base64.NO_WRAP | Base64.NO_PADDING), StandardCharsets.UTF_8)).optString("email", "").toLowerCase();
        } catch (Exception e) {
            return "";
        }
    }

    String who() {
        return (email.isEmpty() ? "(이메일 없음)" : email) + (staff.isEmpty() ? "" : " (" + staff + ")");
    }
}
