package kr.kangcrm.call;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

/**
 * 📇 v5.0 이 폰에 기억한 강CRM 고객 (전화가 오면 인터넷을 기다리지 않고 카드부터 띄움)
 *  · 인터넷으로 확인한 고객만 · 최근 300명 · 30일 (그 뒤엔 다시 확인)
 *  · 카드에 쓰는 글자만 (연락 기록 · 안내서 목록 같은 긴 것은 빼고)
 *  · 강CRM에서 지운 고객(인터넷에서 없다고 함)은 바로 지움 · 연결을 끊으면 다 지움
 */
final class CustCache {
    private CustCache() {}

    static final int MAX = 300;
    static final long KEEP_MS = 30L * 24L * 3600L * 1000L;
    static final int LONG_TEXT = 600;   // 이보다 긴 글: 메모는 잘라서 · 나머지는 뺌 (사진 · 서명 같은 것)
    private static final String KEY = "custMap5";
    private static final String[] MEMO_KEYS = {"memo", "obMemo", "prospectMemo"};

    private static SharedPreferences p(Context c) {
        return c.getApplicationContext().getSharedPreferences("kc_cust", Context.MODE_PRIVATE);
    }

    private static JSONObject map(Context c) {
        try {
            String s = p(c).getString(KEY, "");
            return s == null || s.isEmpty() ? new JSONObject() : new JSONObject(s);
        } catch (Exception e) {
            return new JSONObject();
        }
    }

    private static void save(Context c, JSONObject m) {
        p(c).edit().putString(KEY, m.toString()).apply();
    }

    private static boolean isMemo(String k) {
        for (String m : MEMO_KEYS) if (m.equals(k)) return true;
        return false;
    }

    /** 카드에 쓰는 글자만 남기기 (목록 · 묶음 · 빈칸 · 긴 글 빼고) */
    static JSONObject slim(JSONObject cu) {
        JSONObject o = new JSONObject();
        if (cu == null) return o;
        Iterator<String> it = cu.keys();
        while (it.hasNext()) {
            String k = it.next();
            Object v = cu.opt(k);
            if (v == null || v == JSONObject.NULL || v instanceof JSONArray || v instanceof JSONObject) continue;
            if (v instanceof String) {
                String s = (String) v;
                if (s.isEmpty()) continue;
                if (s.length() > LONG_TEXT) {
                    if (!isMemo(k)) continue;
                    v = s.substring(0, LONG_TEXT);
                }
            }
            try {
                o.put(k, v);
            } catch (Exception ignore) {
                // 숫자가 아닌 값 등
            }
        }
        return o;
    }

    /** 바뀐 게 있는지 (칸 순서는 상관없이) */
    static String canon(JSONObject o) {
        if (o == null) return "";
        List<String> keys = new ArrayList<>();
        Iterator<String> it = o.keys();
        while (it.hasNext()) keys.add(it.next());
        Collections.sort(keys);
        StringBuilder b = new StringBuilder();
        for (String k : keys) b.append(k).append('=').append(String.valueOf(o.opt(k))).append('\n');
        return b.toString();
    }

    /** 기억한 것(hit)과 방금 받은 것(cu)이 카드로 보면 같은지 */
    static boolean same(JSONObject hit, JSONObject cu) {
        if (hit == null || cu == null) return hit == cu;
        try {
            return canon(new JSONObject(slim(hit).toString())).equals(canon(new JSONObject(slim(cu).toString())));
        } catch (Exception e) {
            return false;
        }
    }

    /** 기억한 고객 (없거나 30일 넘었으면 null) */
    static synchronized JSONObject get(Context c, String num) {
        return get(c, num, System.currentTimeMillis());
    }

    static synchronized JSONObject get(Context c, String num, long now) {
        if (num == null || num.length() < 9) return null;
        JSONObject m = map(c);
        JSONObject e = m.optJSONObject(num);
        if (e == null) return null;
        if (now - e.optLong("t") > KEEP_MS) {
            m.remove(num);
            save(c, m);
            return null;
        }
        return e.optJSONObject("d");
    }

    /** 인터넷으로 확인한 고객 기억 (오래된 것부터 300명 넘으면 뺌) */
    static synchronized void put(Context c, String num, JSONObject cu) {
        put(c, num, cu, System.currentTimeMillis());
    }

    static synchronized void put(Context c, String num, JSONObject cu, long now) {
        if (num == null || num.length() < 9 || cu == null) return;
        JSONObject m = map(c);
        try {
            m.put(num, new JSONObject().put("t", now).put("d", slim(cu)));
            while (m.length() > MAX) {
                String old = null;
                long oldT = Long.MAX_VALUE;
                Iterator<String> it = m.keys();
                while (it.hasNext()) {
                    String k = it.next();
                    JSONObject e = m.optJSONObject(k);
                    long t = e == null ? 0 : e.optLong("t");
                    if (t < oldT) {
                        oldT = t;
                        old = k;
                    }
                }
                if (old == null) break;
                m.remove(old);
            }
            save(c, m);
        } catch (Exception ignore) {
            // 기억 못 해도 카드는 인터넷으로
        }
    }

    /** 강CRM에 없는 번호 (지운 고객 · 번호 바뀜) */
    static synchronized void drop(Context c, String num) {
        JSONObject m = map(c);
        if (m.remove(num) != null) save(c, m);
    }

    static synchronized int size(Context c) {
        return map(c).length();
    }

    static synchronized void clear(Context c) {
        p(c).edit().remove(KEY).apply();
    }
}
